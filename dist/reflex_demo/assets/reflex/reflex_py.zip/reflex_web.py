"""Browser entry point: the training-profile ReflexAPI, called the way
multi_cached_reflex_runtime does for a measured event.

Construction mirrors cached_reflex_runtime.CachedReflexRuntime with the
handoff cached_reflex config: profile hard_support_hand_local, w_retreat=0,
w_body=0.3, max/waist joint delta 1 rad, stance disabled.  The call mirrors
measured_reflex_velocity_kwargs: measured qpos as qRef/qpos0, qvel0 with zero
root linear velocity and root-local angular velocity, projected gravity = -z.
"""
from __future__ import annotations

import time
from dataclasses import replace

import mujoco
import numpy as np

from reflex_api import ReflexAPI

LEG_PREFIXES = ("left_hip_", "right_hip_", "left_knee", "right_knee", "left_ankle_",
                "right_ankle_", "left_foot", "right_foot")
_api = None


def is_leg(name: str) -> bool:
    return name.startswith(LEG_PREFIXES)


def publish_reflex_result(api, result, qpos0, body, point_local, normal):
    """Verbatim body of tasks/tracking/reflex_delivery.publish_reflex_result
    (training commit bf07ab7) for lower_body_reflex_enabled=False; that module
    imports torch, so it cannot be imported here."""
    if not result.success:
        return result
    model = api._core.model
    addresses = np.asarray(api.joint_qpos_addresses)
    legs = np.asarray([is_leg(name) for name in api.joint_names])
    target = result.qpos1.copy()
    target[addresses[legs]] = qpos0[addresses[legs]]
    data = getattr(api, "_leg_publication_data", None)
    if data is None:
        data = mujoco.MjData(model)
        api._leg_publication_data = data
    body_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, body)
    if body_id < 1:
        raise ValueError(f"unknown reflex publication body {body!r}")
    mass = np.asarray(api._core._effective_body_mass(list(result.stance_body_ids)))
    direction = np.asarray(normal, dtype=float)
    direction = direction / np.linalg.norm(direction)

    def contact_relative(qpos):
        data.qpos[:] = qpos
        mujoco.mj_kinematics(model, data)
        com = (mass[:, None] * data.xipos).sum(axis=0) / mass.sum()
        point = data.xpos[body_id] + data.xmat[body_id].reshape(3, 3) @ point_local
        return point - com

    start = contact_relative(qpos0)
    distance = float(direction @ (contact_relative(target) - start))
    return replace(result, qpos1=target, retreat_distance=distance,
                   success=bool(np.isfinite(distance) and distance > 0.0),
                   message=result.message + "; publication: leg delta removed, local retreat remeasured")


def init() -> dict:
    global _api
    start = time.perf_counter()
    _api = ReflexAPI(profile="hard_support_hand_local", w_retreat=0.0, w_body=0.3,
                     max_joint_delta=1.0, waist_max_joint_delta=1.0, stance_enabled=False)
    return {"joint_names": list(_api.joint_names), "nq": int(_api.nq), "nv": int(_api.nv),
            "init_ms": (time.perf_counter() - start) * 1e3}


def solve(root_pos, root_quat, joint_pos, root_ang_vel_world, joint_vel, body, point_local, normal_world):
    """Joint arrays are in ReflexAPI joint order; point_local is in the struck body's frame
    (as training shares contact_point_local between PhysX and ReflexAPI).
    Returns the leg-filtered joint delta."""
    api = _api
    start = time.perf_counter()
    qaddr = np.asarray(api.joint_qpos_addresses)
    daddr = np.asarray(api.joint_dof_addresses)
    qpos = np.zeros(api.nq)
    qpos[:3] = root_pos
    qpos[3:7] = np.asarray(root_quat, dtype=np.float64) / np.linalg.norm(root_quat)
    qpos[qaddr] = joint_pos
    # zero_root_linear_qvel: world omega -> root-local, joint rates in API order.
    w, xyz = qpos[3], qpos[4:7]
    omega = np.asarray(root_ang_vel_world, dtype=np.float64)
    cross = np.cross(xyz, omega)
    qvel = np.zeros(api.nv)
    qvel[3:6] = omega - 2.0 * w * cross + 2.0 * np.cross(xyz, cross)
    qvel[daddr] = joint_vel
    normal = np.asarray(normal_world, dtype=np.float64)
    normal = normal / np.linalg.norm(normal)
    point_local = np.asarray(point_local, dtype=np.float64)
    result = api.call_reflex(qpos, qpos, body, point_local, normal, qvel0=qvel,
                             velocity_qpos0=qpos.copy(), projected_gravity=np.array([0.0, 0.0, -1.0]))
    result = publish_reflex_result(api, result, qpos, body, point_local, normal)
    ok = bool(result.success and np.all(np.isfinite(result.qpos1)))
    delta = (result.qpos1[qaddr] - qpos[qaddr]) if ok else np.zeros(len(qaddr))
    return {"delta": delta.tolist(), "success": ok, "retreat_m": float(result.retreat_distance),
            "point_local": point_local.tolist(), "solver_ms": float(result.compute_time_ms),
            "total_ms": (time.perf_counter() - start) * 1e3, "message": str(result.message)}


def _api_ref():
    """The initialised ReflexAPI (parity tests call it directly)."""
    return _api
