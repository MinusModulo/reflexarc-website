"""Browser stub: ReflexAPI imports scipy only for the SLSQP / L-BFGS-B paths,
which the hard-support profiles never take."""
