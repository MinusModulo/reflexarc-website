"""See scipy/__init__.py."""


def minimize(*args, **kwargs):
    raise NotImplementedError("scipy.optimize.minimize is not shipped in the browser build")
