from __future__ import annotations

import time
from dataclasses import dataclass

import mujoco
import numpy as np
from proxsuite import proxqp

from .collision import CollisionModel
from .model import ASSET_PATH, load_model, stance_body_ids


W_RETREAT = 1.0
W_BODY = 0.3
W_JOINT = 0.01
LOWER_BODY_AND_WAIST_JOINT_WEIGHT = 0.15
LOWER_BODY_AND_WAIST_JOINT_NAMES = frozenset(
    {
        "waist_yaw_joint",
        "waist_roll_joint",
        "waist_pitch_joint",
        "left_hip_pitch_joint",
        "left_hip_roll_joint",
        "left_hip_yaw_joint",
        "right_hip_pitch_joint",
        "right_hip_roll_joint",
        "right_hip_yaw_joint",
        "left_knee_joint",
        "right_knee_joint",
        "left_ankle_pitch_joint",
        "left_ankle_roll_joint",
        "right_ankle_pitch_joint",
        "right_ankle_roll_joint",
    }
)
STANCE_EXTRA_MASS_TOTAL = 0.0
COLLISION_SAFE_MARGIN = 0.01
JOINT_LIMIT_MARGIN = 0.03
MAX_JOINT_DELTA = 0.3
WAIST_MAX_JOINT_DELTA = 0.4
LINEARIZED_DAMPING = 1.0e-5
PROXQP_EPS_ABS = 1.0e-8
PROXQP_EPS_REL = 1.0e-8
PROXQP_MAX_ITER = 20


@dataclass(frozen=True)
class ReflexResult:
    qpos1: np.ndarray
    root_translation_world: np.ndarray
    root_rotation_body: np.ndarray
    root_quat_wxyz: np.ndarray
    compute_time_ms: float
    success: bool
    message: str
    retreat_distance: float
    num_iterations: int
    proxqp_solve_time_ms: float
    stance_body_ids: tuple[int, ...]
    momentum_connection_residual: float
    max_linear_constraint_violation: float


@dataclass(frozen=True)
class ReflexComposition:
    qpos: np.ndarray
    root_translation_world: np.ndarray
    root_rotation_body: np.ndarray
    momentum_connection_residual: float
    weighted_com_error: float


class ReflexCore:
    def __init__(
        self,
        *,
        w_body: float = W_BODY,
        max_joint_delta: float = MAX_JOINT_DELTA,
        waist_max_joint_delta: float = WAIST_MAX_JOINT_DELTA,
        stance_enabled: bool = False,
    ) -> None:
        for name, value in (
            ("w_body", w_body),
            ("max_joint_delta", max_joint_delta),
            ("waist_max_joint_delta", waist_max_joint_delta),
        ):
            if not np.isfinite(value) or value < 0.0:
                raise ValueError(f"{name} must be finite and nonnegative")
        if not isinstance(stance_enabled, bool):
            raise TypeError("stance_enabled must be a bool")
        self.w_body = float(w_body)
        self.max_joint_delta = float(max_joint_delta)
        self.waist_max_joint_delta = float(waist_max_joint_delta)
        self.stance_enabled = stance_enabled
        self.model = load_model()
        self.data = mujoco.MjData(self.model)
        self.reference_data = mujoco.MjData(self.model)
        self.collision = CollisionModel(self.model, ASSET_PATH)
        self.robot_body_ids = np.arange(1, self.model.nbody, dtype=np.int32)
        self.joint_ids = [
            joint_id
            for joint_id in range(self.model.njnt)
            if self.model.jnt_type[joint_id] != mujoco.mjtJoint.mjJNT_FREE
        ]
        self.joint_qpos_addr = np.asarray(
            [self.model.jnt_qposadr[joint_id] for joint_id in self.joint_ids], dtype=np.int32
        )
        self.joint_dof_addr = np.asarray(
            [self.model.jnt_dofadr[joint_id] for joint_id in self.joint_ids], dtype=np.int32
        )
        free_joint_ids = [
            joint_id
            for joint_id in range(self.model.njnt)
            if self.model.jnt_type[joint_id] == mujoco.mjtJoint.mjJNT_FREE
        ]
        if len(free_joint_ids) != 1:
            raise ValueError("The standalone reflex API requires exactly one free joint")
        self.root_qpos_addr = int(self.model.jnt_qposadr[free_joint_ids[0]])
        self.root_dof_addr = int(self.model.jnt_dofadr[free_joint_ids[0]])
        self.joint_names = [
            mujoco.mj_id2name(self.model, mujoco.mjtObj.mjOBJ_JOINT, joint_id) or str(joint_id)
            for joint_id in self.joint_ids
        ]
        self.waist_joint_indices = np.asarray(
            [index for index, name in enumerate(self.joint_names) if name.startswith("waist_")],
            dtype=np.int32,
        )
        regularized_joint_indices = np.asarray(
            [
                index
                for index, name in enumerate(self.joint_names)
                if name in LOWER_BODY_AND_WAIST_JOINT_NAMES
            ],
            dtype=np.int32,
        )
        if regularized_joint_indices.size != len(LOWER_BODY_AND_WAIST_JOINT_NAMES):
            missing = sorted(LOWER_BODY_AND_WAIST_JOINT_NAMES - set(self.joint_names))
            raise ValueError(f"Reflex model is missing regularized joints: {missing}")
        self.joint_regularization_weights = np.full(len(self.joint_ids), W_JOINT, dtype=np.float64)
        self.joint_regularization_weights[regularized_joint_indices] = (
            LOWER_BODY_AND_WAIST_JOINT_WEIGHT
        )

    def body_com_local(self, body: str | int) -> np.ndarray:
        body_id = self._body_id(body)
        return self.model.body_ipos[body_id].copy()

    def contact_point_local(
        self,
        qpos: np.ndarray,
        contact_body: str | int,
        contact_point_world: np.ndarray,
    ) -> np.ndarray:
        qpos = self._validate_qpos(qpos, "qpos")
        point_world = self._validate_vector3(contact_point_world, "contact_point_world")
        body_id = self._body_id(contact_body)
        self._set_qpos(qpos)
        body_rotation = self.data.xmat[body_id].reshape(3, 3)
        return body_rotation.T @ (point_world - self.data.xpos[body_id])

    def surface_contact_point_local(
        self,
        qpos: np.ndarray,
        contact_body: str | int,
        retreat_normal_world: np.ndarray,
    ) -> np.ndarray:
        qpos = self._validate_qpos(qpos, "qpos")
        normal = self._validate_vector3(retreat_normal_world, "retreat_normal_world")
        normal_norm = float(np.linalg.norm(normal))
        if normal_norm < 1.0e-9:
            raise ValueError("retreat_normal_world must be nonzero")
        normal /= normal_norm
        body_id = self._body_id(contact_body)
        self._set_qpos(qpos)

        geom_ids = np.flatnonzero(self.model.geom_bodyid == body_id)
        if geom_ids.size == 0:
            raise ValueError(f"Contact body {contact_body!r} has no collision geometry")
        struck_direction = -normal
        body_com = self.data.xipos[body_id]
        extent = max(
            float(np.linalg.norm(self.data.geom_xpos[geom_id] - body_com))
            + max(float(self.model.geom_rbound[geom_id]), 0.0)
            for geom_id in geom_ids
        )
        ray_origin = body_com + struck_direction * (extent + 0.05)
        ray_direction = -struck_direction
        best_distance = float("inf")
        for geom_id in geom_ids:
            distance = mujoco.mju_rayGeom(
                self.data.geom_xpos[geom_id],
                self.data.geom_xmat[geom_id],
                self.model.geom_size[geom_id],
                ray_origin,
                ray_direction,
                int(self.model.geom_type[geom_id]),
                None,
            )
            if 0.0 <= distance < best_distance:
                best_distance = float(distance)
        if not np.isfinite(best_distance):
            raise RuntimeError(f"Could not raycast contact geometry for body {contact_body!r}")
        point_world = ray_origin + best_distance * ray_direction
        return self.contact_point_local(qpos, body_id, point_world)

    def detect_stance(self, qref: np.ndarray) -> tuple[int, ...]:
        qref = self._validate_qpos(qref, "qref")
        if not self.stance_enabled:
            return ()
        return tuple(stance_body_ids(self.model, self.reference_data, qref))

    def compose_reflex(
        self,
        qbase: np.ndarray,
        dq_joint: np.ndarray,
        stance_body_ids_value: tuple[int, ...] | list[int],
    ) -> ReflexComposition:
        """Apply a supplied joint delta while preserving momentum and weighted CoM."""

        qbase = self._validate_qpos(qbase, "qbase")
        dq_joint = np.asarray(dq_joint, dtype=np.float64)
        if dq_joint.shape != (len(self.joint_ids),):
            raise ValueError(f"dq_joint must have shape {(len(self.joint_ids),)}, got {dq_joint.shape}")
        if not np.all(np.isfinite(dq_joint)):
            raise ValueError("dq_joint must be finite")
        stance_ids = (
            [int(body_id) for body_id in stance_body_ids_value]
            if self.stance_enabled
            else []
        )
        if any(body_id <= 0 or body_id >= self.model.nbody for body_id in stance_ids):
            raise ValueError("stance_body_ids contains an invalid body ID")

        self._set_qpos(qbase)
        effective_mass = self._effective_body_mass(stance_ids)
        weighted_com_0 = self._weighted_com(effective_mass)
        _, momentum_connection, connection_residual = self._reduced_generalized_inertia(stance_ids)

        q0_joint = qbase[self.joint_qpos_addr]
        lower, upper = self._compose_joint_bounds()
        q_joint_target = np.clip(q0_joint + dq_joint, lower, upper)
        applied_delta = q_joint_target - q0_joint
        base_delta = momentum_connection @ applied_delta

        qpos = qbase.copy()
        qpos[self.joint_qpos_addr] = q_joint_target
        tangent = np.zeros(self.model.nv, dtype=np.float64)
        tangent[self.root_dof_addr + 3 : self.root_dof_addr + 6] = base_delta[3:]
        mujoco.mj_integratePos(self.model, qpos, tangent, 1.0)

        self._set_qpos(qpos)
        translation = weighted_com_0 - self._weighted_com(effective_mass)
        qpos[self.root_qpos_addr : self.root_qpos_addr + 3] += translation
        self._set_qpos(qpos)
        weighted_com_error = float(np.linalg.norm(self._weighted_com(effective_mass) - weighted_com_0))
        return ReflexComposition(
            qpos=qpos,
            root_translation_world=qpos[self.root_qpos_addr : self.root_qpos_addr + 3]
            - qbase[self.root_qpos_addr : self.root_qpos_addr + 3],
            root_rotation_body=base_delta[3:].copy(),
            momentum_connection_residual=connection_residual,
            weighted_com_error=weighted_com_error,
        )

    def solve(
        self,
        qref: np.ndarray,
        qpos0: np.ndarray,
        contact_body: str | int,
        contact_point_local: np.ndarray,
        retreat_normal_world: np.ndarray,
    ) -> ReflexResult:
        start = time.perf_counter()
        qref = self._validate_qpos(qref, "qref")
        qpos0_input = self._validate_qpos(qpos0, "qpos0")
        qpos0 = qpos0_input.copy()
        contact_point_local = self._validate_vector3(contact_point_local, "contact_point_local")
        normal = self._validate_vector3(retreat_normal_world, "retreat_normal_world")
        normal_norm = float(np.linalg.norm(normal))
        if normal_norm < 1.0e-9:
            raise ValueError("retreat_normal_world must be nonzero")
        normal /= normal_norm
        contact_body_id = self._body_id(contact_body)

        stance_ids = list(self.detect_stance(qref))
        effective_mass = self._effective_body_mass(stance_ids)
        q0_joint = qpos0[self.joint_qpos_addr].copy()
        self._set_qpos(qpos0)
        weighted_com_0 = self._weighted_com(effective_mass)
        contact_tilde_0 = self._contact_point_world(contact_body_id, contact_point_local) - weighted_com_0

        lower, upper = self._joint_bounds(q0_joint)

        (
            q_joint_target,
            base_delta,
            optimizer_success,
            message,
            num_iterations,
            proxqp_solve_time_ms,
            connection_residual,
            max_linear_violation,
        ) = self._solve_qp(
            qpos0=qpos0,
            q0_joint=q0_joint,
            contact_body_id=contact_body_id,
            contact_point_local=contact_point_local,
            retreat_normal=normal,
            effective_mass=effective_mass,
            stance_body_ids_value=stance_ids,
            lower=lower,
            upper=upper,
        )

        qpos1 = qpos0.copy()
        qpos1[self.joint_qpos_addr] = q_joint_target
        tangent = np.zeros(self.model.nv, dtype=np.float64)
        tangent[self.root_dof_addr + 3 : self.root_dof_addr + 6] = base_delta[3:]
        mujoco.mj_integratePos(self.model, qpos1, tangent, 1.0)

        self._set_qpos(qpos1)
        translation = weighted_com_0 - self._weighted_com(effective_mass)
        qpos1[self.root_qpos_addr : self.root_qpos_addr + 3] += translation
        self._set_qpos(qpos1)

        contact_tilde_1 = self._contact_point_world(contact_body_id, contact_point_local) - self._weighted_com(
            effective_mass
        )
        retreat_distance = float(normal @ (contact_tilde_1 - contact_tilde_0))
        success = bool(optimizer_success and retreat_distance > 0.0)
        if optimizer_success and not success:
            message = "optimizer converged but contact point did not retreat along the requested normal"

        compute_time_ms = (time.perf_counter() - start) * 1000.0
        return ReflexResult(
            qpos1=qpos1,
            root_translation_world=qpos1[self.root_qpos_addr : self.root_qpos_addr + 3]
            - qpos0_input[self.root_qpos_addr : self.root_qpos_addr + 3],
            root_rotation_body=base_delta[3:].copy(),
            root_quat_wxyz=qpos1[self.root_qpos_addr + 3 : self.root_qpos_addr + 7].copy(),
            compute_time_ms=compute_time_ms,
            success=success,
            message=message,
            retreat_distance=retreat_distance,
            num_iterations=num_iterations,
            proxqp_solve_time_ms=proxqp_solve_time_ms,
            stance_body_ids=tuple(stance_ids),
            momentum_connection_residual=connection_residual,
            max_linear_constraint_violation=max_linear_violation,
        )

    def _solve_qp(
        self,
        qpos0: np.ndarray,
        q0_joint: np.ndarray,
        contact_body_id: int,
        contact_point_local: np.ndarray,
        retreat_normal: np.ndarray,
        effective_mass: np.ndarray,
        stance_body_ids_value: list[int],
        lower: np.ndarray,
        upper: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray, bool, str, int, float, float, float]:
        body_com_jacobians_full = self._body_com_jacobians_full()
        reduced_inertia, momentum_connection, connection_residual = self._reduced_generalized_inertia(
            stance_body_ids_value
        )
        regularizer = np.diag(self.joint_regularization_weights)
        regularizer += 0.5 * self.w_body * reduced_inertia
        regularizer += LINEARIZED_DAMPING * np.eye(len(self.joint_ids))

        j_wcom_full = self._weighted_com_jacobian_from_cache(body_com_jacobians_full, effective_mass)
        j_contact_full = self._point_jacobian_full(contact_body_id, contact_point_local)
        j_contact_tilde_full = j_contact_full - j_wcom_full
        base = np.arange(self.root_dof_addr, self.root_dof_addr + 6)
        j_contact_tilde = (
            j_contact_tilde_full[:, base] @ momentum_connection
            + j_contact_tilde_full[:, self.joint_dof_addr]
        )
        linear_term = W_RETREAT * (j_contact_tilde.T @ retreat_normal)

        collision_jacobian, collision_lower = self._linearized_collision_constraints(qpos0)
        delta, success, message, iterations, solve_time_ms, max_linear_violation = self._solve_proxqp(
            regularizer=regularizer,
            linear_term=linear_term,
            lower=lower - q0_joint,
            upper=upper - q0_joint,
            collision_jacobian=collision_jacobian,
            collision_lower=collision_lower,
        )
        q_joint_target = np.clip(q0_joint + delta, lower, upper)
        base_delta = momentum_connection @ (q_joint_target - q0_joint)
        return (
            q_joint_target,
            base_delta,
            success,
            f"linearized_qp/proxqp: {message}",
            iterations,
            solve_time_ms,
            connection_residual,
            max_linear_violation,
        )

    def _linearized_collision_constraints(self, qpos0: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        distances = self.collision.pair_distances(qpos0)
        jacobian = np.empty((len(distances), len(self.joint_ids)), dtype=np.float64)
        lower = np.empty(len(distances), dtype=np.float64)
        for row, distance in enumerate(distances):
            normal = distance.point_a - distance.point_b
            norm = float(np.linalg.norm(normal))
            if norm < 1.0e-8:
                normal = self.data.xipos[distance.body_a] - self.data.xipos[distance.body_b]
                norm = float(np.linalg.norm(normal))
            if norm < 1.0e-8:
                raise RuntimeError(f"Degenerate collision normal for pair {distance.pair_index}")
            normal /= norm
            if distance.distance < 0.0:
                normal *= -1.0
            jacobian[row] = normal @ (
                self._point_jacobian_world(distance.body_a, distance.point_a)
                - self._point_jacobian_world(distance.body_b, distance.point_b)
            )
            target = (
                COLLISION_SAFE_MARGIN
                if distance.distance >= 0.0
                else distance.distance - COLLISION_SAFE_MARGIN
            )
            lower[row] = target - distance.distance
        return jacobian, lower

    def _solve_proxqp(
        self,
        regularizer: np.ndarray,
        linear_term: np.ndarray,
        lower: np.ndarray,
        upper: np.ndarray,
        collision_jacobian: np.ndarray,
        collision_lower: np.ndarray,
    ) -> tuple[np.ndarray, bool, str, int, float, float]:
        n = linear_term.shape[0]
        hessian = np.ascontiguousarray(2.0 * regularizer, dtype=np.float64)
        hessian = 0.5 * (hessian + hessian.T)
        gradient = np.ascontiguousarray(-linear_term, dtype=np.float64)
        constraint_matrix = np.ascontiguousarray(
            np.vstack((collision_jacobian, np.eye(n, dtype=np.float64))), dtype=np.float64
        )
        constraint_lower = np.ascontiguousarray(np.concatenate((collision_lower, lower)), dtype=np.float64)
        constraint_upper = np.ascontiguousarray(
            np.concatenate((np.full(collision_lower.shape, np.inf), upper)), dtype=np.float64
        )

        start = time.perf_counter()
        result = proxqp.dense.solve(
            hessian,
            gradient,
            None,
            None,
            constraint_matrix,
            constraint_lower,
            constraint_upper,
            eps_abs=PROXQP_EPS_ABS,
            eps_rel=PROXQP_EPS_REL,
            max_iter=PROXQP_MAX_ITER,
        )
        solve_time_ms = (time.perf_counter() - start) * 1000.0
        delta = np.asarray(result.x, dtype=np.float64)
        finite = bool(delta.shape == (n,) and np.all(np.isfinite(delta)))
        if not finite:
            delta = np.zeros(n, dtype=np.float64)
        values = constraint_matrix @ delta
        lower_violation = float(np.max(np.maximum(constraint_lower - values, 0.0)))
        finite_upper = np.isfinite(constraint_upper)
        upper_violation = float(
            np.max(np.maximum(values[finite_upper] - constraint_upper[finite_upper], 0.0))
        )
        max_linear_violation = max(lower_violation, upper_violation)
        status = str(result.info.status)
        success = bool(
            finite
            and status.endswith("PROXQP_SOLVED")
            and max_linear_violation <= max(10.0 * PROXQP_EPS_ABS, 1.0e-7)
        )
        if not success:
            delta = np.zeros(n, dtype=np.float64)
        message = status if success else f"{status}, max linear violation {max_linear_violation:.3e}"
        return delta, success, message, int(result.info.iter), solve_time_ms, max_linear_violation

    def _set_qpos(self, qpos: np.ndarray) -> None:
        self.data.qpos[:] = qpos
        self.data.qvel[:] = 0.0
        mujoco.mj_forward(self.model, self.data)

    def _validate_qpos(self, value: np.ndarray, name: str) -> np.ndarray:
        array = np.asarray(value, dtype=np.float64)
        if array.shape != (self.model.nq,):
            raise ValueError(f"{name} must have shape {(self.model.nq,)}, got {array.shape}")
        if not np.all(np.isfinite(array)):
            raise ValueError(f"{name} must be finite")
        return array.copy()

    @staticmethod
    def _validate_vector3(value: np.ndarray, name: str) -> np.ndarray:
        array = np.asarray(value, dtype=np.float64)
        if array.shape != (3,):
            raise ValueError(f"{name} must have shape (3,), got {array.shape}")
        if not np.all(np.isfinite(array)):
            raise ValueError(f"{name} must be finite")
        return array.copy()

    def _body_id(self, body: str | int) -> int:
        if isinstance(body, str):
            body_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_BODY, body)
            if body_id < 0:
                raise KeyError(f"Unknown contact body {body!r}")
            return int(body_id)
        body_id = int(body)
        if body_id <= 0 or body_id >= self.model.nbody:
            raise ValueError(f"Invalid body ID {body_id}")
        return body_id

    def _contact_point_world(self, body_id: int, point_local: np.ndarray) -> np.ndarray:
        return self.data.xpos[body_id] + self.data.xmat[body_id].reshape(3, 3) @ point_local

    def _point_jacobian_full(self, body_id: int, point_local: np.ndarray) -> np.ndarray:
        point_world = self._contact_point_world(body_id, point_local)
        jacobian = np.zeros((3, self.model.nv), dtype=np.float64)
        mujoco.mj_jac(self.model, self.data, jacobian, None, point_world, body_id)
        return jacobian

    def _point_jacobian_world(self, body_id: int, point_world: np.ndarray) -> np.ndarray:
        jacobian = np.zeros((3, self.model.nv), dtype=np.float64)
        mujoco.mj_jac(self.model, self.data, jacobian, None, point_world, body_id)
        return jacobian[:, self.joint_dof_addr]

    def _body_com_jacobians_full(self) -> np.ndarray:
        jacobians = np.zeros((self.model.nbody, 3, self.model.nv), dtype=np.float64)
        jacobian = np.zeros((3, self.model.nv), dtype=np.float64)
        for body_id in self.robot_body_ids:
            jacobian.fill(0.0)
            mujoco.mj_jacBodyCom(self.model, self.data, jacobian, None, int(body_id))
            jacobians[body_id] = jacobian
        return jacobians

    def _weighted_com_jacobian_from_cache(
        self, body_jacobians: np.ndarray, effective_mass: np.ndarray
    ) -> np.ndarray:
        masses = effective_mass[self.robot_body_ids]
        return np.sum(body_jacobians[self.robot_body_ids] * masses[:, None, None], axis=0) / float(
            np.sum(masses)
        )

    def _reduced_generalized_inertia(
        self, stance_body_ids_value: list[int]
    ) -> tuple[np.ndarray, np.ndarray, float]:
        inertia = np.empty((self.model.nv, self.model.nv), dtype=np.float64)
        mujoco.mj_fullM(self.model, self.data, inertia)
        if stance_body_ids_value:
            virtual_mass = STANCE_EXTRA_MASS_TOTAL / len(stance_body_ids_value)
            for body_id in stance_body_ids_value:
                jacp = np.zeros((3, self.model.nv), dtype=np.float64)
                jacr = np.zeros((3, self.model.nv), dtype=np.float64)
                mujoco.mj_jacBodyCom(self.model, self.data, jacp, jacr, body_id)
                inertia += virtual_mass * (jacp.T @ jacp)
                body_mass = self.model.body_mass[body_id]
                if body_mass > 0.0:
                    rotation = self.data.ximat[body_id].reshape(3, 3)
                    rotational = rotation @ np.diag(
                        self.model.body_inertia[body_id] * virtual_mass / body_mass
                    ) @ rotation.T
                    inertia += jacr.T @ rotational @ jacr

        base = np.arange(self.root_dof_addr, self.root_dof_addr + 6)
        a = inertia[np.ix_(base, base)]
        b = inertia[np.ix_(base, self.joint_dof_addr)]
        c = inertia[np.ix_(self.joint_dof_addr, self.joint_dof_addr)]
        solve_a_b = np.linalg.solve(a, b)
        connection = -solve_a_b
        reduced = c - b.T @ solve_a_b
        residual = float(np.max(np.abs(a @ connection + b), initial=0.0))
        return 0.5 * (reduced + reduced.T), connection, residual

    def _effective_body_mass(self, stance_ids: list[int]) -> np.ndarray:
        effective_mass = self.model.body_mass.copy()
        if stance_ids:
            extra_mass = STANCE_EXTRA_MASS_TOTAL / len(stance_ids)
            for body_id in stance_ids:
                effective_mass[body_id] += extra_mass
        return effective_mass

    def _weighted_com(self, effective_mass: np.ndarray) -> np.ndarray:
        masses = effective_mass[self.robot_body_ids]
        return np.sum(self.data.xipos[self.robot_body_ids] * masses[:, None], axis=0) / float(np.sum(masses))

    def _joint_bounds(self, q0_joint: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        lower, upper = self._inset_joint_bounds()
        # qpos0 is measured state.  Preserve an already-outside measurement,
        # keep zero delta feasible, and only allow the target to move inward.
        lower = np.minimum(lower, q0_joint)
        upper = np.maximum(upper, q0_joint)
        lower = np.maximum(lower, q0_joint - self.max_joint_delta)
        upper = np.minimum(upper, q0_joint + self.max_joint_delta)
        lower[self.waist_joint_indices] = np.maximum(
            lower[self.waist_joint_indices],
            q0_joint[self.waist_joint_indices] - self.waist_max_joint_delta,
        )
        upper[self.waist_joint_indices] = np.minimum(
            upper[self.waist_joint_indices],
            q0_joint[self.waist_joint_indices] + self.waist_max_joint_delta,
        )
        invalid = lower > upper
        if np.any(invalid):
            names = [self.joint_names[index] for index in np.flatnonzero(invalid)]
            raise RuntimeError(f"invalid reflex joint bounds for: {', '.join(names)}")
        return lower, upper

    def _absolute_joint_bounds(self) -> tuple[np.ndarray, np.ndarray]:
        q0_joint = np.zeros(len(self.joint_ids), dtype=np.float64)
        lower = np.full_like(q0_joint, -np.inf, dtype=np.float64)
        upper = np.full_like(q0_joint, np.inf, dtype=np.float64)
        for index, joint_id in enumerate(self.joint_ids):
            if self.model.jnt_limited[joint_id]:
                joint_lower, joint_upper = self.model.jnt_range[joint_id]
                lower[index] = joint_lower
                upper[index] = joint_upper
        return lower, upper

    def _inset_joint_bounds(self) -> tuple[np.ndarray, np.ndarray]:
        lower, upper = self._absolute_joint_bounds()
        finite = np.isfinite(lower) & np.isfinite(upper)
        inset = finite & (upper - lower > 2.0 * JOINT_LIMIT_MARGIN)
        lower[inset] += JOINT_LIMIT_MARGIN
        upper[inset] -= JOINT_LIMIT_MARGIN
        return lower, upper

    def _compose_joint_bounds(self) -> tuple[np.ndarray, np.ndarray]:
        """Return the absolute target bounds used by the production Torch composer."""

        return self._inset_joint_bounds()
