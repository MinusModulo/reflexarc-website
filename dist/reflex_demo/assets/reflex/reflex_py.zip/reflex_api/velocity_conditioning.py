"""One scalar amplitude selection before the shared three-QP guided solve."""
from __future__ import annotations

from dataclasses import replace
import time
from typing import TYPE_CHECKING

import mujoco
import numpy as np

if TYPE_CHECKING:
    from .hard_support import HardSupportCore

VELOCITY_GAIN_SECONDS = .12
VELOCITY_MAX_EXTRA_M = .30
VELOCITY_REST_DISTANCE_CAP_M = .25
ROOT_LINEAR_VELOCITY_POLICY = "zero"


def velocity_retreat_distance(fixed_distance: float, normal: np.ndarray, velocity: np.ndarray):
    """World-axis normal and velocity estimate with root linear velocity omitted."""
    incoming = max(0., -float(normal @ velocity))
    rest = min(fixed_distance, VELOCITY_REST_DISTANCE_CAP_M)
    return rest + min(VELOCITY_GAIN_SECONDS * incoming, VELOCITY_MAX_EXTRA_M), rest, incoming


class VelocityConditioner:
    """Per-instance FK/J workspace; no model compilation or extra QP round."""

    def __init__(self, model: mujoco.MjModel):
        self.model = model
        self.data = mujoco.MjData(model)
        self.jacobian = np.zeros((3, model.nv))

    def solve(self, core: HardSupportCore, *, qvel0: np.ndarray,
              velocity_qpos0: np.ndarray | None = None, **kwargs):
        start = time.perf_counter()
        qvel = np.asarray(qvel0, dtype=np.float64)
        if qvel.shape != (self.model.nv,) or not np.all(np.isfinite(qvel)):
            raise ValueError(f"qvel0 must contain {self.model.nv} finite MuJoCo generalized velocities")
        # Root translation is unavailable on the robot. Keep angular/joint
        # velocities and the caller's array intact; this does not lock root pose.
        qvel = qvel.copy()
        qvel[core.root_dof_addr:core.root_dof_addr + 3] = 0.
        qpos = core._validate_qpos(kwargs["qpos0"], "qpos0")
        if velocity_qpos0 is not None:
            qpos = core._validate_qpos(velocity_qpos0, "velocity_qpos0")
        point = core._validate_vector3(kwargs["contact_point_local"], "contact_point_local")
        normal = core._validate_vector3(kwargs["retreat_normal_world"], "retreat_normal_world")
        norm = float(np.linalg.norm(normal))
        if norm < 1e-9:
            raise ValueError("retreat_normal_world must be nonzero")
        normal /= norm
        body_id = core._body_id(kwargs["contact_body"])
        old_table = core._contact_retreat_configs
        config = old_table.get(body_id, core.optimizer.config)
        if config.preferred_retreat_distance is None or config.w_retreat_shortfall <= 0:
            raise ValueError("Velocity conditioning requires an active soft retreat preference")
        self.data.qpos[:] = qpos
        mujoco.mj_fwdPosition(self.model, self.data)
        contact = self.data.xpos[body_id] + self.data.xmat[body_id].reshape(3, 3) @ point
        mujoco.mj_jac(self.model, self.data, self.jacobian, None, contact, body_id)
        velocity = self.jacobian @ qvel
        if not np.all(np.isfinite(velocity)):
            raise ValueError("qvel0 produced a non-finite contact velocity")
        distance, rest, incoming = velocity_retreat_distance(config.preferred_retreat_distance, normal, velocity)
        core._contact_retreat_configs = {body_id: replace(config, preferred_retreat_distance=distance)}
        try:
            result = core.solve(**kwargs)
        finally:
            core._contact_retreat_configs = old_table
        core.last_target_result.info["velocity_condition"] = dict(
            enabled=True, contact_velocity_world_mps=velocity.tolist(), incoming_speed_mps=incoming,
            fixed_distance_m=config.preferred_retreat_distance, rest_distance_m=rest,
            preferred_distance_m=distance, gain_seconds=VELOCITY_GAIN_SECONDS,
            max_extra_m=VELOCITY_MAX_EXTRA_M,
            root_linear_velocity_policy=ROOT_LINEAR_VELOCITY_POLICY,
        )
        return replace(result, compute_time_ms=(time.perf_counter() - start) * 1000.)
