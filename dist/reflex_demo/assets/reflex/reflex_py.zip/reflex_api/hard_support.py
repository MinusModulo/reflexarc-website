"""Runtime adapter for the accepted strong hard-support planner."""

from __future__ import annotations

import time
from dataclasses import replace

import mujoco
import numpy as np

from .core import ReflexResult
from .config import RETREAT_REFERENCE_CONTACT_RELATIVE_TO_PHYSICAL_COM, ReflexConfig
from .model import ASSET_PATH
from .profiles import (
    HARD_SUPPORT_MAX_JOINT_DELTA,
    HARD_SUPPORT_W_RETREAT,
    HARD_SUPPORT_WAIST_MAX_JOINT_DELTA,
    HARD_SUPPORT_W_BODY,
    hard_support_config,
)
from .weighted_com_target_optimizer import ReflexTargetResult, WeightedCoMReflexOptimizer


class HardSupportCore:
    """One-thread stateful hard-support runtime.

    Model compilation and collision-proxy compilation happen at construction
    time and are deliberately excluded from per-call latency.
    """

    def __init__(
        self,
        model: mujoco.MjModel,
        *,
        w_retreat: float = HARD_SUPPORT_W_RETREAT,
        retreat_reference_frame: str = (
            RETREAT_REFERENCE_CONTACT_RELATIVE_TO_PHYSICAL_COM
        ),
        w_body: float = HARD_SUPPORT_W_BODY,
        max_joint_delta: float = HARD_SUPPORT_MAX_JOINT_DELTA,
        waist_max_joint_delta: float = HARD_SUPPORT_WAIST_MAX_JOINT_DELTA,
        config: ReflexConfig | None = None,
    ) -> None:
        self.model = model
        self.data = mujoco.MjData(model)
        self.config = config if config is not None else hard_support_config(
            model,
            w_retreat=w_retreat,
            retreat_reference_frame=retreat_reference_frame,
            w_body=w_body,
            max_joint_delta=max_joint_delta,
            waist_max_joint_delta=waist_max_joint_delta,
        )
        self.optimizer = WeightedCoMReflexOptimizer(
            model,
            self.config,
            collision_model_path=ASSET_PATH,
            require_compiled_collision=True,
        )
        self._model_gravity_magnitude = float(
            np.linalg.norm(np.asarray(model.opt.gravity, dtype=np.float64))
        )
        if self._model_gravity_magnitude < 1.0e-9:
            raise ValueError(
                "The standalone hard-support profile requires non-zero model gravity"
            )
        self.last_target_result: ReflexTargetResult | None = None
        free_joint_ids = [
            joint_id
            for joint_id in range(model.njnt)
            if model.jnt_type[joint_id] == mujoco.mjtJoint.mjJNT_FREE
        ]
        if len(free_joint_ids) != 1:
            raise ValueError("The standalone hard-support profile requires one free joint")
        self.root_qpos_addr = int(model.jnt_qposadr[free_joint_ids[0]])
        self.root_dof_addr = int(model.jnt_dofadr[free_joint_ids[0]])
        # Scalar-only event configs share the same compiled optimizer/model.
        self._contact_retreat_configs = {
            self._body_id(body): replace(self.config, preferred_retreat_distance=distance)
            for body, distance in self.config.hard_support_contact_retreat_distances.items()
        }

    def solve(
        self,
        *,
        qref: np.ndarray,
        qpos0: np.ndarray,
        contact_body: str | int,
        contact_point_local: np.ndarray,
        retreat_normal_world: np.ndarray,
        down_direction_world: np.ndarray | None,
    ) -> ReflexResult:
        call_start = time.perf_counter()
        # qRef remains part of the stable API and is shape/finite validated,
        # but the hard-support event is measured and solved from qpos0.
        self._validate_qpos(qref, "qRef")
        qpos = self._validate_qpos(qpos0, "qpos0")
        point = self._validate_vector3(contact_point_local, "contact_point_local")
        normal = self._validate_vector3(retreat_normal_world, "retreat_normal_world")
        normal_norm = float(np.linalg.norm(normal))
        if normal_norm < 1.0e-9:
            raise ValueError("retreat_normal_world must be nonzero")
        normal /= normal_norm
        body_id = self._body_id(contact_body)
        down = self._resolve_down_direction(down_direction_world)

        # ``projected_gravity`` is a direction-only public input.  Preserve the
        # bundled robot model's gravity magnitude while using that direction in
        # every MuJoCo forward/RNE call made by this event, including the
        # q0-frozen static-support effort model.  The model object is shared by
        # the initialized API, so restore its exact prior value even when the
        # optimizer raises.  Calls without an explicit vector never rewrite the
        # model option, preserving the historical default path bit-for-bit.
        override_gravity = down_direction_world is not None
        previous_gravity: np.ndarray | None = None
        if override_gravity:
            previous_gravity = np.asarray(
                self.model.opt.gravity, dtype=np.float64
            ).copy()
        previous_config = self.optimizer.config
        try:
            self.optimizer.config = self._contact_retreat_configs.get(body_id, previous_config)
            if override_gravity:
                self.model.opt.gravity[:] = self._model_gravity_magnitude * down
            result = self.optimizer.solve(
                self.data,
                qpos,
                body_id,
                point,
                normal,
                [],
                down_direction_world=down,
            )
            self.last_target_result = result
            qpos1 = np.asarray(result.qpos_target, dtype=np.float64).copy()
            tangent = np.empty(self.model.nv, dtype=np.float64)
            mujoco.mj_differentiatePos(self.model, tangent, 1.0, qpos, qpos1)
            root_translation = (
                qpos1[self.root_qpos_addr : self.root_qpos_addr + 3]
                - qpos[self.root_qpos_addr : self.root_qpos_addr + 3]
            )
            info = result.info
            proxqp_time = sum(
                float(
                    info.get(
                        f"hard_support_round_{index}_proxqp_solve_time_ms", 0.0
                    )
                )
                for index in range(1, self.config.hard_support_qp_rounds + 1)
            )
            max_linear_violation = max(
                float(info.get("hard_collision_linear_max_violation", 0.0)),
                float(info.get("equality_linear_max_violation", 0.0)),
            )
            stance_residual = max(
                float(info.get("stance_point_displacement", 0.0)),
                float(info.get("stance_frame_rotation", 0.0)),
            )
            return ReflexResult(
                qpos1=qpos1,
                root_translation_world=root_translation.copy(),
                root_rotation_body=tangent[
                    self.root_dof_addr + 3 : self.root_dof_addr + 6
                ].copy(),
                root_quat_wxyz=qpos1[
                    self.root_qpos_addr + 3 : self.root_qpos_addr + 7
                ].copy(),
                compute_time_ms=(time.perf_counter() - call_start) * 1000.0,
                success=bool(result.success),
                message=f"hard_support: {result.message}",
                retreat_distance=float(result.retreat_distance),
                num_iterations=int(result.num_iterations),
                proxqp_solve_time_ms=proxqp_time,
                stance_body_ids=result.stance_body_ids,
                # Retain the legacy field for result-schema compatibility.  In
                # hard-support mode it reports the final attached-frame
                # residual, not a virtual momentum-connection residual.
                momentum_connection_residual=stance_residual,
                max_linear_constraint_violation=max_linear_violation,
            )
        finally:
            self.optimizer.config = previous_config
            if previous_gravity is not None:
                self.model.opt.gravity[:] = previous_gravity

    def _resolve_down_direction(self, value: np.ndarray | None) -> np.ndarray:
        down = (
            np.asarray(self.model.opt.gravity, dtype=np.float64).copy()
            if value is None
            else self._validate_vector3(value, "down_direction_world")
        )
        norm = float(np.linalg.norm(down))
        if norm < 1.0e-9:
            if value is not None:
                raise ValueError("down direction must be non-zero")
            raise ValueError(
                "down_direction_world is required when model gravity is zero"
            )
        return down / norm

    def _body_id(self, body: str | int) -> int:
        if isinstance(body, str):
            body_id = mujoco.mj_name2id(
                self.model, mujoco.mjtObj.mjOBJ_BODY, body
            )
            if body_id < 0:
                raise KeyError(f"Unknown contact body {body!r}")
            return int(body_id)
        body_id = int(body)
        if body_id <= 0 or body_id >= self.model.nbody:
            raise ValueError(f"Invalid body ID {body_id}")
        return body_id

    def _validate_qpos(self, value: np.ndarray, name: str) -> np.ndarray:
        array = np.asarray(value, dtype=np.float64)
        if array.shape != (self.model.nq,):
            raise ValueError(f"{name} must have shape {(self.model.nq,)}, got {array.shape}")
        if not np.all(np.isfinite(array)):
            raise ValueError(f"{name} must be finite")
        return array.copy()

    @staticmethod
    def _validate_vector3(value: np.ndarray, name: str) -> np.ndarray:
        array = np.asarray(value, dtype=np.float64)
        if array.shape != (3,):
            raise ValueError(f"{name} must have shape (3,), got {array.shape}")
        if not np.all(np.isfinite(array)):
            raise ValueError(f"{name} must be finite")
        return array.copy()
