"""Named standalone ReflexAPI solver profiles.

Profiles freeze a scientific contract rather than exposing every research
ablation through the runtime API.  The default profile is the accepted strong
hard-support planner used by the source visualizer.
"""

from __future__ import annotations

from dataclasses import replace

import mujoco

from .config import (
    REFLEX_MODE_HARD_SUPPORT,
    RETREAT_REFERENCE_CONTACT_RELATIVE_TO_PHYSICAL_COM,
    ReflexConfig,
)


PROFILE_HARD_SUPPORT = "hard_support"
PROFILE_HARD_SUPPORT_HAND_LOCAL = "hard_support_hand_local"
PROFILE_VIRTUAL_MASS_MOMENTUM = "virtual_mass_momentum"
PROFILES = (PROFILE_HARD_SUPPORT, PROFILE_VIRTUAL_MASS_MOMENTUM, PROFILE_HARD_SUPPORT_HAND_LOCAL)

# Public constants freeze the accepted hard-support defaults for callers that
# need to record or validate the resolved ReflexAPI contract without copying
# numeric literals.
HARD_SUPPORT_W_BODY = 0.3
HARD_SUPPORT_W_RETREAT = 1.0
HARD_SUPPORT_MAX_JOINT_DELTA = 1.0
HARD_SUPPORT_WAIST_MAX_JOINT_DELTA = 1.0


def normalize_profile(profile: str) -> str:
    value = str(profile).strip().lower().replace("-", "_")
    aliases = {
        "hard_supporting": PROFILE_HARD_SUPPORT,
        "legacy": PROFILE_VIRTUAL_MASS_MOMENTUM,
        "legacy_virtual_mass_momentum": PROFILE_VIRTUAL_MASS_MOMENTUM,
    }
    value = aliases.get(value, value)
    if value not in PROFILES:
        raise ValueError(f"Unknown ReflexAPI profile {profile!r}; expected one of {PROFILES}")
    return value


def actuated_joint_names(model: mujoco.MjModel) -> tuple[str, ...]:
    names: list[str] = []
    for joint_id in range(model.njnt):
        if model.jnt_type[joint_id] == mujoco.mjtJoint.mjJNT_FREE:
            continue
        name = mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_JOINT, joint_id)
        if name is None:
            raise ValueError(f"Actuated joint {joint_id} has no name")
        names.append(name)
    return tuple(names)


def hard_support_config(
    model: mujoco.MjModel,
    *,
    w_retreat: float = HARD_SUPPORT_W_RETREAT,
    retreat_reference_frame: str = (
        RETREAT_REFERENCE_CONTACT_RELATIVE_TO_PHYSICAL_COM
    ),
    w_body: float = HARD_SUPPORT_W_BODY,
    max_joint_delta: float = HARD_SUPPORT_MAX_JOINT_DELTA,
    waist_max_joint_delta: float = HARD_SUPPORT_WAIST_MAX_JOINT_DELTA,
) -> ReflexConfig:
    """Return the accepted strong hard-support runtime contract."""

    return ReflexConfig(
        reflex_mode=REFLEX_MODE_HARD_SUPPORT,
        w_retreat=float(w_retreat),
        hard_support_retreat_reference_frame=str(retreat_reference_frame),
        w_body=float(w_body),
        w_joint=0.1,
        w_world_com=0.0,
        w_static_support_effort=0.0,
        joint_regularization={name: 0.1 for name in actuated_joint_names(model)},
        collision_safe_margin=0.01,
        joint_limit_margin=0.03,
        max_joint_delta=float(max_joint_delta),
        waist_max_joint_delta=float(waist_max_joint_delta),
        stance_height_tolerance=0.05,
        hard_support_qp_rounds=3,
        hard_support_joint_trust_region=0.4,
        hard_support_stance_projection_iterations=2,
        hard_support_joint_hit_restoration_enabled=False,
        hard_support_balance_constraint_enabled=False,
        hard_support_collision_constraints_enabled=True,
        hard_support_stance_constraints_enabled=True,
        hard_support_free_world_com_z_body_energy=True,
        collect_diagnostics=False,
    )


def hard_support_hand_local_config(
    model: mujoco.MjModel,
    *,
    w_body: float = HARD_SUPPORT_W_BODY,
    max_joint_delta: float = HARD_SUPPORT_MAX_JOINT_DELTA,
    waist_max_joint_delta: float = HARD_SUPPORT_WAIST_MAX_JOINT_DELTA,
) -> ReflexConfig:
    """Reviewed guided profile; pass qvel0 for incoming-speed conditioning.

    Hand contacts prefer the struck arm: shoulder .03, elbow zero additional
    joint L2, wrist .3, other joints .1. Nonhand contacts use uniform .03.
    Vendor body inertia still penalizes every joint's physical motion.
    No motion/frame-specific rule, geometric seed, or additional QP stage.
    """
    names = actuated_joint_names(model)
    event_weights = {}
    for side in ("left", "right"):
        weights = {name: .1 for name in names}
        weights.update({f"{side}_shoulder_{axis}_joint": .03
                        for axis in ("pitch", "roll", "yaw")})
        weights.update({f"{side}_wrist_{axis}_joint": .3
                        for axis in ("roll", "pitch", "yaw")})
        weights[f"{side}_elbow_joint"] = 0.
        event_weights[f"{side}_wrist_yaw_link"] = weights
    distances = {name: .15 for name in ("pelvis", "waist_yaw_link", "waist_roll_link", "torso_link")}
    distances.update({
        f"{side}_{part}_link": .35
        for side in ("left", "right")
        for part in ("shoulder_pitch", "shoulder_roll", "shoulder_yaw", "elbow",
                     "wrist_roll", "wrist_pitch", "wrist_yaw")
    })
    return replace(
        hard_support_config(model, w_body=w_body, max_joint_delta=max_joint_delta,
                            waist_max_joint_delta=waist_max_joint_delta),
        w_retreat=0.0,
        preferred_retreat_distance=.25,
        w_retreat_shortfall=5.0,
        w_world_retreat_cone=10.0,
        world_retreat_cone_ratio=.9,
        w_joint=.03,
        joint_regularization={name: .03 for name in names},
        hard_support_contact_joint_regularization=event_weights,
        hard_support_contact_retreat_distances=distances,
        hard_support_batched_collision_assembly=True,
    )
