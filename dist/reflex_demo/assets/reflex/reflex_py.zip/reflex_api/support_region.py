"""Frozen static support regions for experimental hard-support reflexes.

The planner has no measured generalized velocity or contact-force decision
variables.  This module therefore implements only a configuration-level
static balance contract: keep the physical whole-body CoM from moving farther
out of the support polygon that existed at the event's measured ``qpos0``.

All support geometry and required margins are frozen once per reflex event.
Only the physical CoM and its Jacobian are recomputed in later SQP rounds.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

import mujoco
import numpy as np

from .stance_points import ResolvedStancePoint, normalize_down_direction


SUPPORT_GEOMETRY_TOLERANCE_M = 1.0e-9
SUPPORT_AREA_TOLERANCE_M2 = 1.0e-10

# These are the four pre-existing truth-holder marker centres in
# reflex_api/assets/g1_reflex.xml.  A selected toe or heel activates the full
# footprint of that foot; the marker geometry itself is not a contact model.
FOOT_SUPPORT_VERTICES_LOCAL: dict[
    str,
    tuple[tuple[float, float, float], ...],
] = {
    "left_ankle_roll_link": (
        (-0.05, 0.025, -0.03),
        (-0.05, -0.025, -0.03),
        (0.12, 0.03, -0.03),
        (0.12, -0.03, -0.03),
    ),
    "right_ankle_roll_link": (
        (-0.05, 0.025, -0.03),
        (-0.05, -0.025, -0.03),
        (0.12, 0.03, -0.03),
        (0.12, -0.03, -0.03),
    ),
}


def _readonly_float_array(value: np.ndarray, shape: tuple[int, ...]) -> np.ndarray:
    array = np.asarray(value, dtype=np.float64).copy()
    if array.shape != shape or not np.all(np.isfinite(array)):
        raise ValueError(f"Expected a finite array with shape {shape}, got {array.shape}")
    array.setflags(write=False)
    return array


@dataclass(frozen=True)
class FrozenSupportRegion:
    """One event-local support polygon and its edge-wise CoM requirements.

    ``plane_basis_world`` has two orthonormal columns spanning the plane
    perpendicular to gravity.  ``edge_normals_2d`` are outward unit normals,
    so every hull edge is represented as ``a @ x <= b`` and its signed inside
    margin is ``b - a @ x``.
    """

    down_direction_world: np.ndarray
    plane_basis_world: np.ndarray
    support_vertices_world: np.ndarray
    hull_vertices_2d: np.ndarray
    edge_normals_2d: np.ndarray
    edge_offsets_2d: np.ndarray
    reference_margins: np.ndarray
    required_margins: np.ndarray
    safety_margin_m: float
    build_time_ms: float

    def __post_init__(self) -> None:
        vertex_count = int(np.asarray(self.support_vertices_world).shape[0])
        hull_count = int(np.asarray(self.hull_vertices_2d).shape[0])
        edge_count = int(np.asarray(self.edge_normals_2d).shape[0])
        if vertex_count < 3 or hull_count < 3 or edge_count != hull_count:
            raise ValueError("A support region requires a non-degenerate polygon")
        if not np.isfinite(self.safety_margin_m) or self.safety_margin_m < 0.0:
            raise ValueError("safety_margin_m must be finite and non-negative")
        if not np.isfinite(self.build_time_ms) or self.build_time_ms < 0.0:
            raise ValueError("build_time_ms must be finite and non-negative")
        object.__setattr__(
            self,
            "down_direction_world",
            _readonly_float_array(self.down_direction_world, (3,)),
        )
        object.__setattr__(
            self,
            "plane_basis_world",
            _readonly_float_array(self.plane_basis_world, (3, 2)),
        )
        object.__setattr__(
            self,
            "support_vertices_world",
            _readonly_float_array(self.support_vertices_world, (vertex_count, 3)),
        )
        object.__setattr__(
            self,
            "hull_vertices_2d",
            _readonly_float_array(self.hull_vertices_2d, (hull_count, 2)),
        )
        object.__setattr__(
            self,
            "edge_normals_2d",
            _readonly_float_array(self.edge_normals_2d, (edge_count, 2)),
        )
        object.__setattr__(
            self,
            "edge_offsets_2d",
            _readonly_float_array(self.edge_offsets_2d, (edge_count,)),
        )
        object.__setattr__(
            self,
            "reference_margins",
            _readonly_float_array(self.reference_margins, (edge_count,)),
        )
        object.__setattr__(
            self,
            "required_margins",
            _readonly_float_array(self.required_margins, (edge_count,)),
        )

    @property
    def vertex_count(self) -> int:
        return int(self.support_vertices_world.shape[0])

    @property
    def edge_count(self) -> int:
        return int(self.edge_normals_2d.shape[0])

    def project_world_points(self, points_world: np.ndarray) -> np.ndarray:
        points = np.asarray(points_world, dtype=np.float64)
        if points.shape[-1:] != (3,) or not np.all(np.isfinite(points)):
            raise ValueError("World points must be finite with trailing shape (3,)")
        return points @ self.plane_basis_world

    def margins(self, physical_com_world: np.ndarray) -> np.ndarray:
        com = np.asarray(physical_com_world, dtype=np.float64)
        if com.shape != (3,) or not np.all(np.isfinite(com)):
            raise ValueError("physical_com_world must be a finite 3-vector")
        com_2d = self.plane_basis_world.T @ com
        return self.edge_offsets_2d - self.edge_normals_2d @ com_2d

    def linearized_constraints(
        self,
        physical_com_world: np.ndarray,
        physical_com_jacobian_world: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Return rows ``A dz >= lower`` and current exact edge margins."""

        jacobian = np.asarray(physical_com_jacobian_world, dtype=np.float64)
        if jacobian.ndim != 2 or jacobian.shape[0] != 3:
            raise ValueError("physical_com_jacobian_world must have shape (3, n)")
        if not np.all(np.isfinite(jacobian)):
            raise ValueError("physical_com_jacobian_world must be finite")
        current_margins = self.margins(physical_com_world)
        plane_jacobian = self.plane_basis_world.T @ jacobian
        rows = -(self.edge_normals_2d @ plane_jacobian)
        lower = self.required_margins - current_margins
        return rows, lower, current_margins

    def max_violation(self, physical_com_world: np.ndarray) -> float:
        return float(
            np.max(
                np.maximum(
                    self.required_margins - self.margins(physical_com_world),
                    0.0,
                ),
                initial=0.0,
            )
        )


def gravity_plane_basis(down_direction_world: np.ndarray) -> np.ndarray:
    """Return a deterministic orthonormal basis normal to gravity."""

    down = normalize_down_direction(down_direction_world)
    axes = np.eye(3, dtype=np.float64)
    seed = axes[int(np.argmin(np.abs(axes @ down)))]
    first = seed - float(seed @ down) * down
    first /= np.linalg.norm(first)
    second = np.cross(down, first)
    second /= np.linalg.norm(second)
    basis = np.column_stack((first, second))
    if not np.allclose(basis.T @ basis, np.eye(2), atol=1.0e-12, rtol=0.0):
        raise RuntimeError("Failed to construct an orthonormal gravity-plane basis")
    return basis


def convex_hull_2d(points_2d: np.ndarray) -> np.ndarray:
    """Return the counter-clockwise convex hull without repeated endpoint."""

    points = np.asarray(points_2d, dtype=np.float64)
    if points.ndim != 2 or points.shape[1] != 2 or not np.all(np.isfinite(points)):
        raise ValueError("points_2d must be a finite (N, 2) array")
    ordered = points[np.lexsort((points[:, 1], points[:, 0]))]
    unique: list[np.ndarray] = []
    for point in ordered:
        if not unique or np.linalg.norm(point - unique[-1]) > SUPPORT_GEOMETRY_TOLERANCE_M:
            unique.append(point.copy())
    if len(unique) < 3:
        raise ValueError("Selected stance geometry has fewer than three unique planar points")

    def cross(origin: np.ndarray, first: np.ndarray, second: np.ndarray) -> float:
        a = first - origin
        b = second - origin
        return float(a[0] * b[1] - a[1] * b[0])

    lower: list[np.ndarray] = []
    for point in unique:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], point) <= SUPPORT_AREA_TOLERANCE_M2:
            lower.pop()
        lower.append(point)
    upper: list[np.ndarray] = []
    for point in reversed(unique):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], point) <= SUPPORT_AREA_TOLERANCE_M2:
            upper.pop()
        upper.append(point)
    hull = np.asarray(lower[:-1] + upper[:-1], dtype=np.float64)
    if hull.shape[0] < 3:
        raise ValueError("Selected stance geometry is collinear in the gravity plane")
    next_hull = np.roll(hull, -1, axis=0)
    signed_area = 0.5 * float(
        np.sum(hull[:, 0] * next_hull[:, 1] - hull[:, 1] * next_hull[:, 0])
    )
    if signed_area <= SUPPORT_AREA_TOLERANCE_M2:
        raise ValueError("Selected stance geometry has a degenerate support area")
    return hull


def polygon_halfspaces_ccw(hull_vertices_2d: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Convert a counter-clockwise polygon to outward unit halfspaces."""

    hull = np.asarray(hull_vertices_2d, dtype=np.float64)
    if hull.ndim != 2 or hull.shape[0] < 3 or hull.shape[1] != 2:
        raise ValueError("hull_vertices_2d must have shape (N>=3, 2)")
    edges = np.roll(hull, -1, axis=0) - hull
    lengths = np.linalg.norm(edges, axis=1)
    if np.any(lengths <= SUPPORT_GEOMETRY_TOLERANCE_M):
        raise ValueError("Support hull contains a zero-length edge")
    outward = np.column_stack((edges[:, 1], -edges[:, 0])) / lengths[:, None]
    offsets = np.sum(outward * hull, axis=1)
    return outward, offsets


def selected_support_vertices_world(
    data: mujoco.MjData,
    selected_stance_points: tuple[ResolvedStancePoint, ...],
) -> np.ndarray:
    """Expand selected feet to footprints and keep other points literally."""

    vertices: list[np.ndarray] = []
    expanded_feet: set[str] = set()
    for point in selected_stance_points:
        foot_vertices = FOOT_SUPPORT_VERTICES_LOCAL.get(point.body_name)
        if foot_vertices is not None:
            if point.body_name in expanded_feet:
                continue
            expanded_feet.add(point.body_name)
            body_rotation = data.xmat[point.body_id].reshape(3, 3)
            body_position = data.xpos[point.body_id]
            for local_vertex in foot_vertices:
                vertices.append(
                    body_position
                    + body_rotation @ np.asarray(local_vertex, dtype=np.float64)
                )
        else:
            body_rotation = data.xmat[point.body_id].reshape(3, 3)
            vertices.append(
                data.xpos[point.body_id]
                + body_rotation @ point.local_position
            )
    if not vertices:
        raise ValueError("Cannot build a support region without selected stance points")
    return np.asarray(vertices, dtype=np.float64)


def build_frozen_support_region(
    data: mujoco.MjData,
    selected_stance_points: tuple[ResolvedStancePoint, ...],
    down_direction_world: np.ndarray,
    physical_com_world: np.ndarray,
    *,
    safety_margin_m: float,
) -> FrozenSupportRegion:
    """Build the immutable event-local support polygon and margin contract."""

    build_start = time.perf_counter()
    if not np.isfinite(safety_margin_m) or safety_margin_m < 0.0:
        raise ValueError("safety_margin_m must be finite and non-negative")
    down = normalize_down_direction(down_direction_world)
    basis = gravity_plane_basis(down)
    vertices_world = selected_support_vertices_world(data, selected_stance_points)
    hull = convex_hull_2d(vertices_world @ basis)
    normals, offsets = polygon_halfspaces_ccw(hull)
    com = np.asarray(physical_com_world, dtype=np.float64)
    if com.shape != (3,) or not np.all(np.isfinite(com)):
        raise ValueError("physical_com_world must be a finite 3-vector")
    reference_margins = offsets - normals @ (basis.T @ com)
    required_margins = np.minimum(reference_margins, float(safety_margin_m))
    return FrozenSupportRegion(
        down_direction_world=down,
        plane_basis_world=basis,
        support_vertices_world=vertices_world,
        hull_vertices_2d=hull,
        edge_normals_2d=normals,
        edge_offsets_2d=offsets,
        reference_margins=reference_margins,
        required_margins=required_margins,
        safety_margin_m=float(safety_margin_m),
        build_time_ms=(time.perf_counter() - build_start) * 1000.0,
    )
