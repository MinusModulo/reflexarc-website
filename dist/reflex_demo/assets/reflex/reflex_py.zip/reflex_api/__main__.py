"""Run the standalone CLI without re-executing the imported adapter module."""
from .call_reflex import main


if __name__ == "__main__":
    main()
