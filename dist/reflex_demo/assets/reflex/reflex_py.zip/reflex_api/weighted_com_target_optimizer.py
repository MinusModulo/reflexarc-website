from __future__ import annotations

import math
import os
import time
from dataclasses import dataclass, field, replace
from pathlib import Path

import mujoco
import numpy as np
from scipy.optimize import minimize

from .config import (
    ANGULAR_REGULARIZATION_CENTROIDAL_ANGULAR_VELOCITY,
    ANGULAR_REGULARIZATION_CENTROIDAL_MOMENTUM,
    ANGULAR_REGULARIZATION_CENTROIDAL_ROTATIONAL_ENERGY,
    ANGULAR_REGULARIZATION_MODES,
    ANGULAR_REGULARIZATION_NONE,
    ANGULAR_REGULARIZATION_TORSO_ANGULAR_VELOCITY,
    HARD_SUPPORT_BODY_ENERGY_FULL,
    HARD_SUPPORT_BODY_ENERGY_MODES,
    HARD_SUPPORT_BODY_ENERGY_NONE,
    HARD_SUPPORT_BODY_ENERGY_TRANSLATIONAL,
    REFLEX_MODE_HARD_SUPPORT,
    REFLEX_MODE_HARD_SUPPORT_MIN_IMPULSE,
    REFLEX_MODE_VIRTUAL_MASS_MOMENTUM,
    REFLEX_MODES,
    RETREAT_REFERENCE_CONTACT_RELATIVE_TO_PHYSICAL_COM,
    RETREAT_REFERENCE_CONTACT_WORLD,
    RETREAT_REFERENCE_FRAMES,
    ReflexConfig,
)
from .self_collision import PrimitiveSelfCollisionModel
from .retreat_cone import retreat_cone_model
from .stance_points import (
    ResolvedStancePoint,
    resolve_candidate_stance_points,
    select_stance_points,
)
from .support_region import FrozenSupportRegion, build_frozen_support_region


STATIC_SUPPORT_CONTACT_FORCE_REGULARIZATION = 1.0e-6
STATIC_SUPPORT_FINITE_DIFFERENCE_STEP = 1.0e-5
RESTORATION_STANCE_POSITION_TOLERANCE_M = 1.0e-3
RESTORATION_STANCE_ROTATION_TOLERANCE_RAD = math.radians(0.5)
RESTORATION_RETREAT_DRIFT_TOLERANCE_M = 2.0e-3
RESTORATION_COLLISION_VIOLATION_TOLERANCE_M = 1.0e-3
RESTORATION_JOINT_LIMIT_TOLERANCE_RAD = 1.0e-9
# Two SQP rounds leave millimetre-scale second-order CoM residuals even when
# every linear inequality is satisfied to numerical precision.  Keep the
# exact nonlinear fail-closed gate, but reserve it for errors larger than the
# approved 5 mm physical tolerance.
SUPPORT_REGION_VALIDATION_TOLERANCE_M = 5.0e-3


@dataclass(frozen=True)
class ReflexTargetResult:
    qpos_target: np.ndarray
    success: bool
    retreat_distance: float
    tangent_displacement: float
    body_displacement_cost: float
    joint_delta_norm: float
    max_joint_delta: float
    stance_foot_displacement: float
    min_self_collision_distance: float
    solve_time_ms: float
    num_iterations: int
    message: str
    stance_body_ids: tuple[int, ...] = ()
    info: dict[str, float | int | bool | str] = field(default_factory=dict)


@dataclass(frozen=True)
class HardSupportQPSolverReplay:
    """Immutable solver output used to materialize a deferred round report."""

    variable: np.ndarray
    success: bool
    message: str
    num_iterations: int
    solver_info: dict[str, float | int | bool | str]
    inequality_duals: np.ndarray


@dataclass(frozen=True)
class HardSupportRoundReplayInputs:
    """Round-local state needed to rebuild reports without re-solving."""

    current_qpos: np.ndarray
    accumulated_delta: np.ndarray
    correction_lower: np.ndarray
    correction_upper: np.ndarray
    collision_target_distances: dict[tuple[int, int], float] | None
    round_index: int


@dataclass(frozen=True)
class LinearizedQPSolution:
    q_joint_target: np.ndarray
    base_delta: np.ndarray
    success: bool
    message: str
    num_iterations: int
    objective_value: float
    active_collision_pair_indices: list[tuple[int, int]]
    hard_collision_targets: dict[tuple[int, int], float] = field(default_factory=dict)
    hard_collision_slacks: np.ndarray = field(default_factory=lambda: np.empty(0, dtype=np.float64))
    hard_collision_duals: np.ndarray = field(default_factory=lambda: np.empty(0, dtype=np.float64))
    support_impulse: np.ndarray = field(default_factory=lambda: np.empty(0, dtype=np.float64))
    restoration_regularizer: np.ndarray = field(
        default_factory=lambda: np.empty((0, 0), dtype=np.float64)
    )
    support_region: FrozenSupportRegion | None = None
    info: dict[str, float | int | bool | str] = field(default_factory=dict)


@dataclass(frozen=True)
class AngularMotionModel:
    """q0-frozen linear maps used by angular-motion experiments.

    A displacement ``delta_z`` is interpreted as a characteristic generalized
    velocity over one unit of time.  Consequently momentum and angular
    velocity scale as ``1 / T`` and the kinetic quantities scale as
    ``1 / T**2`` if a different characteristic duration is assumed.
    """

    angular_momentum_matrix: np.ndarray
    spin_angular_momentum_matrix: np.ndarray
    orbital_angular_momentum_matrix: np.ndarray
    centroidal_inertia: np.ndarray
    centroidal_inertia_inverse: np.ndarray
    centroidal_angular_velocity_matrix: np.ndarray
    torso_angular_velocity_matrix: np.ndarray
    translational_inertia: np.ndarray
    rotational_inertia: np.ndarray
    objective_regularizer: np.ndarray


@dataclass(frozen=True)
class HardSupportBodyEnergyModel:
    """Frozen body-energy ablation contract for one hard-support solve."""

    active_inertia: np.ndarray
    removed_inertia: np.ndarray
    effective_joint_regularization: np.ndarray
    transferred_joint_weight: float
    transfer_numerator: float
    transfer_denominator: float
    transfer_nullity: int


@dataclass(frozen=True)
class StaticSupportEffortState:
    """Minimum actuator/contact effort for one frozen configuration."""

    generalized_bias: np.ndarray
    effort_metric: np.ndarray
    actuator_torque: np.ndarray
    support_force: np.ndarray
    effort: float
    equilibrium_residual: float
    system_rank: int
    system_condition_number: float


@dataclass(frozen=True)
class StaticSupportEffortModel:
    """q0-frozen Gauss-Newton model of quasistatic support effort."""

    reference_bias: np.ndarray
    load_jacobian: np.ndarray
    effort_metric: np.ndarray
    objective_regularizer: np.ndarray
    objective_linear_offset: np.ndarray
    reference_actuator_torque: np.ndarray
    reference_support_force: np.ndarray
    reference_effort: float
    reference_equilibrium_residual: float
    system_rank: int
    system_condition_number: float
    build_time_ms: float


class StaticSupportModelRankError(ValueError):
    """The optional quasistatic support model is rank deficient.

    This is deliberately narrower than ``ValueError`` so the hard-support
    solve may mark only this optional soft prior unavailable without hiding
    malformed inputs or failures in the mandatory feasibility constraints.
    """

    def __init__(self, rank: int, required_rank: int) -> None:
        self.rank = int(rank)
        self.required_rank = int(required_rank)
        super().__init__(
            "Selected translational stance contacts cannot support a full "
            "quasistatic floating-base equilibrium "
            f"(rank {self.rank}/{self.required_rank})"
        )


class DenseProxQPWorkspace:
    """Fixed-dimension ProxQP workspace reused within one reflex event.

    This class is used only by the default-off joint/hit restoration path.  It
    keeps the solver object and its previous primal/dual result, but every
    changed Hessian, Jacobian and bound is supplied again through ``update``.
    ProxQP therefore rebuilds the numerical preconditioner as required; no
    stale linearization or factorization is reused.
    """

    def __init__(
        self,
        *,
        n_variable: int,
        n_equality: int,
        n_inequality: int,
        eps_abs: float,
        eps_rel: float,
        max_iterations: int,
    ) -> None:
        try:
            from proxsuite import proxqp
        except ImportError as exc:
            raise ImportError(
                "ProxQP solver requires proxsuite; install it with "
                "`conda run -n reflex_rollout python -m pip install proxsuite`."
            ) from exc
        self._proxqp = proxqp
        self.n_variable = int(n_variable)
        self.n_equality = int(n_equality)
        self.n_inequality = int(n_inequality)
        self.qp = proxqp.dense.QP(
            self.n_variable,
            self.n_equality,
            self.n_inequality,
            True,
        )
        self.qp.settings.eps_abs = float(eps_abs)
        self.qp.settings.eps_rel = float(eps_rel)
        self.qp.settings.max_iter = int(max_iterations)
        self.qp.settings.initial_guess = proxqp.InitialGuess.NO_INITIAL_GUESS
        self.initialized = False
        self.init_count = 0
        self.update_count = 0

    def solve(
        self,
        *,
        regularizer: np.ndarray,
        linear_term: np.ndarray,
        lower: np.ndarray,
        upper: np.ndarray,
        inequality_jacobian: np.ndarray,
        inequality_lower: np.ndarray,
        inequality_upper: np.ndarray,
        equality_jacobian: np.ndarray,
        equality_target: np.ndarray,
    ) -> tuple[
        np.ndarray,
        bool,
        str,
        int,
        dict[str, float | int | bool | str],
        np.ndarray,
    ]:
        n = self.n_variable
        hessian = np.ascontiguousarray(2.0 * regularizer, dtype=np.float64)
        hessian = np.ascontiguousarray(0.5 * (hessian + hessian.T))
        gradient = np.ascontiguousarray(-linear_term, dtype=np.float64)
        equality_matrix = np.ascontiguousarray(equality_jacobian, dtype=np.float64)
        equality_vector = np.ascontiguousarray(equality_target, dtype=np.float64)
        inequality_matrix = np.ascontiguousarray(
            inequality_jacobian,
            dtype=np.float64,
        )
        inequality_lower = np.ascontiguousarray(inequality_lower, dtype=np.float64)
        inequality_upper = np.ascontiguousarray(inequality_upper, dtype=np.float64)
        lower_box = np.ascontiguousarray(lower, dtype=np.float64)
        upper_box = np.ascontiguousarray(upper, dtype=np.float64)
        expected = (
            hessian.shape == (n, n)
            and gradient.shape == (n,)
            and equality_matrix.shape == (self.n_equality, n)
            and equality_vector.shape == (self.n_equality,)
            and inequality_matrix.shape == (self.n_inequality, n)
            and inequality_lower.shape == (self.n_inequality,)
            and inequality_upper.shape == (self.n_inequality,)
            and lower_box.shape == (n,)
            and upper_box.shape == (n,)
        )
        if not expected:
            raise ValueError(
                "Reusable ProxQP dimensions changed within one reflex event"
            )

        operation = "init" if not self.initialized else "update"
        solve_start = time.perf_counter()
        if not self.initialized:
            self.qp.init(
                hessian,
                gradient,
                equality_matrix,
                equality_vector,
                inequality_matrix,
                inequality_lower,
                inequality_upper,
                lower_box,
                upper_box,
                True,
            )
            self.initialized = True
            self.init_count += 1
        else:
            self.qp.settings.initial_guess = (
                self._proxqp.InitialGuess.WARM_START_WITH_PREVIOUS_RESULT
            )
            self.qp.update(
                hessian,
                gradient,
                equality_matrix,
                equality_vector,
                inequality_matrix,
                inequality_lower,
                inequality_upper,
                lower_box,
                upper_box,
                True,
            )
            self.update_count += 1
        self.qp.solve()
        solve_time_ms = (time.perf_counter() - solve_start) * 1000.0

        result = self.qp.results
        variable = np.asarray(result.x, dtype=np.float64).copy()
        finite = bool(variable.shape == (n,) and np.all(np.isfinite(variable)))
        if not finite:
            variable = np.zeros(n, dtype=np.float64)
        inequality_value = inequality_matrix @ variable
        lower_violation = float(
            np.max(
                np.maximum(inequality_lower - inequality_value, 0.0),
                initial=0.0,
            )
        )
        finite_upper = np.isfinite(inequality_upper)
        upper_violation = float(
            np.max(
                np.maximum(
                    inequality_value[finite_upper]
                    - inequality_upper[finite_upper],
                    0.0,
                ),
                initial=0.0,
            )
        )
        box_lower_violation = float(
            np.max(np.maximum(lower_box - variable, 0.0), initial=0.0)
        )
        finite_box_upper = np.isfinite(upper_box)
        box_upper_violation = float(
            np.max(
                np.maximum(
                    variable[finite_box_upper]
                    - upper_box[finite_box_upper],
                    0.0,
                ),
                initial=0.0,
            )
        )
        equality_violation = float(
            np.max(
                np.abs(equality_matrix @ variable - equality_vector),
                initial=0.0,
            )
        )
        max_linear_violation = max(
            lower_violation,
            upper_violation,
            box_lower_violation,
            box_upper_violation,
            equality_violation,
        )
        status = str(result.info.status)
        status_solved = status.endswith("PROXQP_SOLVED")
        success = bool(
            finite
            and status_solved
            and max_linear_violation <= max(10.0 * self.qp.settings.eps_abs, 1.0e-7)
        )
        message = (
            status
            if success
            else f"{status}, max linear violation {max_linear_violation:.3e}"
        )
        if not success:
            variable = np.zeros(n, dtype=np.float64)
        dual = np.asarray(result.z[: self.n_inequality], dtype=np.float64).copy()
        return (
            variable,
            success,
            message,
            int(result.info.iter),
            {
                "hard_collision_linear_max_violation": max_linear_violation,
                "equality_constraint_count": self.n_equality,
                "equality_linear_max_violation": equality_violation,
                "proxqp_solve_time_ms": solve_time_ms,
                "proxqp_status": status,
                "proxqp_workspace_operation": operation,
                "proxqp_workspace_init_count": self.init_count,
                "proxqp_workspace_update_count": self.update_count,
            },
            dual,
        )


class WeightedCoMReflexOptimizer:
    def __init__(
        self,
        model: mujoco.MjModel,
        config: ReflexConfig | None = None,
        self_collision_pairs: list[tuple[str, str, float, float]] | None = None,
        *,
        collision_model_path: Path | None = None,
        require_compiled_collision: bool = False,
    ) -> None:
        self.model = model
        self.config = config or ReflexConfig()
        self._validate_config()
        self.robot_body_ids = np.arange(1, model.nbody, dtype=np.int32)
        self.joint_ids = [
            joint_id
            for joint_id in range(model.njnt)
            if model.jnt_type[joint_id] != mujoco.mjtJoint.mjJNT_FREE
        ]
        self.joint_qpos_addr = np.array(
            [model.jnt_qposadr[joint_id] for joint_id in self.joint_ids], dtype=np.int32
        )
        self.joint_dof_addr = np.array(
            [model.jnt_dofadr[joint_id] for joint_id in self.joint_ids], dtype=np.int32
        )
        free_joint_ids = [
            joint_id
            for joint_id in range(model.njnt)
            if model.jnt_type[joint_id] == mujoco.mjtJoint.mjJNT_FREE
        ]
        if not free_joint_ids:
            raise ValueError("WeightedCoMReflexOptimizer requires a floating-base model")
        if len(free_joint_ids) > 1:
            raise ValueError("WeightedCoMReflexOptimizer expects a single free joint")
        self.root_qpos_addr = int(model.jnt_qposadr[free_joint_ids[0]])
        self.root_dof_addr = int(model.jnt_dofadr[free_joint_ids[0]])
        self._base_dofs = np.arange(
            self.root_dof_addr,
            self.root_dof_addr + 6,
        )
        self._kinematic_dofs = np.concatenate(
            (self._base_dofs, self.joint_dof_addr)
        )
        if len(np.unique(self._kinematic_dofs)) != len(self._kinematic_dofs):
            raise RuntimeError("Floating-base and joint DoF indices overlap")
        self.joint_names = [
            mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_JOINT, joint_id) or str(joint_id)
            for joint_id in self.joint_ids
        ]
        self.joint_regularization_weights = self._joint_regularization_weights()
        self._contact_joint_regularization = self._resolve_contact_joint_regularization()
        self.waist_joint_indices = np.array(
            [
                i
                for i, joint_name in enumerate(self.joint_names)
                if joint_name.startswith("waist_")
            ],
            dtype=np.int32,
        )
        self.self_collision_model = PrimitiveSelfCollisionModel(
            model,
            collision_model_path=collision_model_path,
            require_compiled_collision=require_compiled_collision,
        )
        self.last_linearized_qp_solution: LinearizedQPSolution | None = None
        self._joint_id_to_index = {joint_id: i for i, joint_id in enumerate(self.joint_ids)}
        self._ancestor_joint_masks = [self._build_ancestor_joint_mask(body_id) for body_id in range(model.nbody)]
        self.candidate_stance_points = resolve_candidate_stance_points(model)

    def _resolve_contact_joint_regularization(self) -> dict[int, tuple[np.ndarray, np.ndarray]]:
        """Resolve event weights once; no hot-path name scans or changed masses."""
        joint_indices = {name: index for index, name in enumerate(self.joint_names)}
        resolved = {}
        for body_name, weights in self.config.hard_support_contact_joint_regularization.items():
            body_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_BODY, body_name)
            if body_id <= 0:
                raise ValueError(f"Unknown contact joint-weight body: {body_name!r}")
            if any(name not in joint_indices for name in weights):
                raise ValueError(f"Unknown contact joint-weight joint in {body_name!r}")
            values = np.array(list(weights.values()), dtype=np.float64)
            if not np.all(np.isfinite(values)) or np.any(values < 0):
                raise ValueError("Contact joint weights must be finite and non-negative")
            indices = np.array([joint_indices[name] for name in weights], dtype=np.int32)
            resolved[body_id] = (indices, values)
        return resolved

    def _validate_config(self) -> None:
        if not isinstance(self.config.hard_support_batched_collision_assembly, bool):
            raise TypeError("hard_support_batched_collision_assembly must be a bool")
        for name in ("w_retreat_shortfall", "w_world_retreat_cone"):
            value = getattr(self.config, name)
            if not np.isfinite(value) or value < 0:
                raise ValueError(f"{name} must be finite and non-negative")
        if not np.isfinite(self.config.world_retreat_cone_ratio) or not 0 < self.config.world_retreat_cone_ratio < 1:
            raise ValueError("world_retreat_cone_ratio must be between zero and one")
        distances = list(self.config.hard_support_contact_retreat_distances.values())
        if self.config.preferred_retreat_distance is not None:
            distances.append(self.config.preferred_retreat_distance)
        if any(not np.isfinite(d) or d <= 0 for d in distances):
            raise ValueError("Preferred retreat distances must be finite and positive")
        if self.config.w_retreat_shortfall > 0 and self.config.preferred_retreat_distance is None:
            raise ValueError("w_retreat_shortfall requires preferred_retreat_distance")
        guided_requested = (
            self.config.w_retreat_shortfall > 0 or self.config.w_world_retreat_cone > 0
            or bool(self.config.hard_support_contact_joint_regularization)
            or bool(self.config.hard_support_contact_retreat_distances)
            or self.config.hard_support_batched_collision_assembly
        )
        if guided_requested and (
            self.config.reflex_mode != REFLEX_MODE_HARD_SUPPORT
            or self.config.optimizer != "linearized_qp"
            or self.config.linearized_qp_solver != "proxqp"
            or self.config.hard_support_joint_hit_restoration_enabled
        ):
            raise ValueError("Guided objectives require ordinary hard-support ProxQP without joint-hit restoration")
        if self.config.reflex_mode not in REFLEX_MODES:
            raise ValueError(
                f"Unknown reflex_mode {self.config.reflex_mode!r}; expected one of {REFLEX_MODES}"
            )
        if not np.isfinite(self.config.stance_height_tolerance) or self.config.stance_height_tolerance < 0.0:
            raise ValueError("stance_height_tolerance must be finite and non-negative")
        if (
            not np.isfinite(self.config.hard_support_balance_margin)
            or self.config.hard_support_balance_margin < 0.0
        ):
            raise ValueError(
                "hard_support_balance_margin must be finite and non-negative"
            )
        if self.config.hard_support_balance_constraint_enabled:
            if self.config.reflex_mode == REFLEX_MODE_VIRTUAL_MASS_MOMENTUM:
                raise ValueError(
                    "hard-support balance constraints require a hard-support reflex mode"
                )
            if not self.config.hard_support_stance_constraints_enabled:
                raise ValueError(
                    "hard-support balance constraints require stance constraints"
                )
        if self.config.support_impulse_dt <= 0.0:
            raise ValueError("support_impulse_dt must be positive")
        if self.config.w_support_impulse < 0.0:
            raise ValueError("w_support_impulse must be non-negative")
        if not np.isfinite(self.config.w_world_com) or self.config.w_world_com < 0.0:
            raise ValueError("w_world_com must be finite and non-negative")
        if (
            not np.isfinite(self.config.w_static_support_effort)
            or self.config.w_static_support_effort < 0.0
        ):
            raise ValueError(
                "w_static_support_effort must be finite and non-negative"
            )
        if self.config.angular_regularization_mode not in ANGULAR_REGULARIZATION_MODES:
            raise ValueError(
                "Unknown angular_regularization_mode "
                f"{self.config.angular_regularization_mode!r}; expected one of "
                f"{ANGULAR_REGULARIZATION_MODES}"
            )
        if (
            not np.isfinite(self.config.w_angular_regularization)
            or self.config.w_angular_regularization < 0.0
        ):
            raise ValueError(
                "w_angular_regularization must be finite and non-negative"
            )
        if (
            self.config.angular_regularization_mode == ANGULAR_REGULARIZATION_NONE
            and self.config.w_angular_regularization != 0.0
        ):
            raise ValueError(
                "w_angular_regularization must be zero when "
                "angular_regularization_mode='none'"
            )
        if (
            self.config.angular_regularization_mode != ANGULAR_REGULARIZATION_NONE
            and self.config.reflex_mode == REFLEX_MODE_VIRTUAL_MASS_MOMENTUM
        ):
            raise ValueError(
                "Angular-motion regularizers are implemented only for hard-support modes"
            )
        if (
            self.config.w_static_support_effort > 0.0
            and self.config.reflex_mode == REFLEX_MODE_VIRTUAL_MASS_MOMENTUM
        ):
            raise ValueError(
                "Static support effort is implemented only for hard-support modes"
            )
        if self.config.hard_support_qp_rounds not in (1, 2, 3, 4):
            raise ValueError("hard_support_qp_rounds must be between 1 and 4")
        if (
            not np.isfinite(self.config.hard_support_joint_trust_region)
            or self.config.hard_support_joint_trust_region <= 0.0
        ):
            raise ValueError(
                "hard_support_joint_trust_region must be finite and positive"
            )
        if self.config.hard_support_stance_projection_iterations not in (0, 1, 2):
            raise ValueError(
                "hard_support_stance_projection_iterations must be 0, 1, or 2"
            )
        if self.config.hard_support_joint_hit_restoration_enabled:
            if self.config.optimizer != "linearized_qp":
                raise ValueError(
                    "hard-support joint/hit restoration requires optimizer='linearized_qp'"
                )
            if self.config.linearized_qp_solver != "proxqp":
                raise ValueError(
                    "hard-support joint/hit restoration requires linearized_qp_solver='proxqp'"
                )
            if self.config.reflex_mode != REFLEX_MODE_HARD_SUPPORT:
                raise ValueError(
                    "hard-support joint/hit restoration requires reflex_mode='hard_support'"
                )
            if self.config.hard_support_qp_rounds != 2:
                raise ValueError(
                    "hard-support joint/hit restoration requires exactly two task QP rounds"
                )
            if self.config.hard_support_stance_projection_iterations != 0:
                raise ValueError(
                    "hard-support joint/hit restoration cannot be combined with stance projection"
                )
            if not self.config.hard_support_stance_constraints_enabled:
                raise ValueError(
                    "hard-support joint/hit restoration requires stance constraints"
                )
            if not self.config.hard_support_collision_constraints_enabled:
                raise ValueError(
                    "hard-support joint/hit restoration requires collision constraints"
                )
        if (
            self.config.hard_support_body_energy_mode
            not in HARD_SUPPORT_BODY_ENERGY_MODES
        ):
            raise ValueError(
                "Unknown hard_support_body_energy_mode "
                f"{self.config.hard_support_body_energy_mode!r}; expected one of "
                f"{HARD_SUPPORT_BODY_ENERGY_MODES}"
            )
        if not isinstance(
            self.config.hard_support_free_world_com_z_body_energy, bool
        ):
            raise TypeError(
                "hard_support_free_world_com_z_body_energy must be a bool"
            )
        if (
            self.config.hard_support_free_world_com_z_body_energy
            and self.config.hard_support_body_energy_mode
            != HARD_SUPPORT_BODY_ENERGY_FULL
        ):
            raise ValueError(
                "free world-CoM Z body energy requires full body-energy mode"
            )
        if (
            self.config.hard_support_free_world_com_z_body_energy
            and self.config.hard_support_transfer_removed_body_energy_to_joint
        ):
            raise ValueError(
                "free world-CoM Z body energy cannot be transferred to joints"
            )
        if (
            self.config.hard_support_retreat_reference_frame
            not in RETREAT_REFERENCE_FRAMES
        ):
            raise ValueError(
                "Unknown hard_support_retreat_reference_frame "
                f"{self.config.hard_support_retreat_reference_frame!r}; "
                f"expected one of {RETREAT_REFERENCE_FRAMES}"
            )
        if (
            self.config.hard_support_retreat_reference_frame
            != RETREAT_REFERENCE_CONTACT_RELATIVE_TO_PHYSICAL_COM
            and self.config.reflex_mode == REFLEX_MODE_VIRTUAL_MASS_MOMENTUM
        ):
            raise ValueError(
                "World-contact retreat is an explicit hard-support-only ablation"
            )
        hard_support_ablation_requested = (
            not self.config.hard_support_collision_constraints_enabled
            or not self.config.hard_support_stance_constraints_enabled
            or self.config.hard_support_body_energy_mode
            != HARD_SUPPORT_BODY_ENERGY_FULL
            or self.config.hard_support_free_world_com_z_body_energy
            or self.config.hard_support_transfer_removed_body_energy_to_joint
        )
        if (
            hard_support_ablation_requested
            and self.config.reflex_mode == REFLEX_MODE_VIRTUAL_MASS_MOMENTUM
        ):
            raise ValueError(
                "Hard-support component ablations require a hard-support reflex mode"
            )
        if (
            self.config.hard_support_transfer_removed_body_energy_to_joint
            and self.config.hard_support_body_energy_mode
            == HARD_SUPPORT_BODY_ENERGY_FULL
        ):
            raise ValueError(
                "Cannot transfer removed body energy when body-energy mode is 'full'"
            )
        if (
            self.config.hard_support_transfer_removed_body_energy_to_joint
            and not self.config.hard_support_stance_constraints_enabled
        ):
            raise ValueError(
                "Removed body-energy transfer requires the stance-feasible motion space"
            )
        if (
            not self.config.hard_support_stance_constraints_enabled
            and self.config.reflex_mode == REFLEX_MODE_HARD_SUPPORT_MIN_IMPULSE
        ):
            raise ValueError(
                "hard_support_min_impulse requires stance constraints"
            )
        if self.config.reflex_mode != REFLEX_MODE_VIRTUAL_MASS_MOMENTUM:
            if self.config.optimizer != "linearized_qp":
                raise ValueError("Hard-support reflex modes require optimizer='linearized_qp'")
            if self.config.linearized_qp_solver != "proxqp":
                raise ValueError("Hard-support reflex modes require linearized_qp_solver='proxqp'")
        if (
            self.config.reflex_mode == REFLEX_MODE_HARD_SUPPORT_MIN_IMPULSE
            and self.config.w_support_impulse <= 0.0
        ):
            raise ValueError("hard_support_min_impulse requires w_support_impulse > 0")

    def solve(
        self,
        data: mujoco.MjData,
        qpos0: np.ndarray,
        contact_body_id: int,
        contact_point_local: np.ndarray,
        contact_normal_world: np.ndarray,
        stance_foot_body_ids: list[int],
        down_direction_world: np.ndarray | None = None,
    ) -> ReflexTargetResult:
        start = time.perf_counter()
        timing_enabled = os.environ.get("REFLEX_TIMING") == "1"
        timing_last = start
        timings: dict[str, float] = {}

        def mark_timing(name: str) -> None:
            nonlocal timing_last
            if not timing_enabled:
                return
            now = time.perf_counter()
            timings[name] = (now - timing_last) * 1000.0
            timing_last = now

        config = self.config
        if config.min_retreat_distance is not None and config.min_retreat_distance < 0.0:
            raise ValueError("min_retreat_distance must be non-negative")
        if config.min_retreat_distance is not None and config.linearized_qp_solver != "proxqp":
            raise ValueError("min_retreat_distance requires the ProxQP solver")
        stance_foot_body_ids = list(dict.fromkeys(int(body_id) for body_id in stance_foot_body_ids))
        if any(body_id <= 0 or body_id >= self.model.nbody for body_id in stance_foot_body_ids):
            raise ValueError("stance_foot_body_ids contains an invalid robot body id")
        n = np.asarray(contact_normal_world, dtype=np.float64)
        n_norm = np.linalg.norm(n)
        if n_norm < 1e-9:
            raise ValueError("contact_normal_world must be non-zero")
        n /= n_norm

        qpos0 = np.asarray(qpos0, dtype=np.float64).copy()
        contact_point_local = np.asarray(contact_point_local, dtype=np.float64)
        q0_joint = qpos0[self.joint_qpos_addr].copy()
        virtual_mass_body_ids = (
            stance_foot_body_ids
            if config.reflex_mode == REFLEX_MODE_VIRTUAL_MASS_MOMENTUM
            else []
        )
        effective_mass = self._effective_body_mass(virtual_mass_body_ids)

        self._set_qpos(data, qpos0)
        if config.reflex_mode == REFLEX_MODE_VIRTUAL_MASS_MOMENTUM:
            selected_stance_points: tuple[ResolvedStancePoint, ...] = ()
            stance_point_positions_0: dict[str, np.ndarray] = {}
            stance_frame_rotations_0: dict[str, np.ndarray] = {}
        else:
            if down_direction_world is None:
                raise ValueError("Hard-support reflex modes require down_direction_world")
            stance_selection = select_stance_points(
                data,
                self.candidate_stance_points,
                down_direction_world,
                height_tolerance=config.stance_height_tolerance,
            )
            selected_stance_points = stance_selection.selected_points
            stance_point_positions_0 = {
                point.name: stance_selection.candidate_positions_world[index].copy()
                for index, point in enumerate(stance_selection.candidate_points)
                if index in stance_selection.selected_indices
            }
            stance_frame_rotations_0 = {
                point.name: data.xmat[point.body_id].reshape(3, 3).copy()
                for point in selected_stance_points
            }
        reporting_pairs = self.self_collision_model.reporting_pairs
        optimization_pair_indices = (
            list(self.self_collision_model.optimization_pairs)
            if config.hard_support_collision_constraints_enabled
            or config.reflex_mode == REFLEX_MODE_VIRTUAL_MASS_MOMENTUM
            else []
        )
        needs_legacy_collision_reference = not (
            config.optimizer == "linearized_qp" and config.linearized_qp_solver == "proxqp"
        )
        collision_reference_distances: dict[tuple[int, int], float] = {}
        collision_reference_penalty = 0.0
        collision_reference_min_distance = float("nan")
        if needs_legacy_collision_reference:
            collision_reference_distances = self.self_collision_model.distance_map(
                data,
                pair_indices=reporting_pairs,
            )
            collision_reference = self.self_collision_model.evaluate_fast(
                data,
                d_safe=config.d_safe,
                pair_indices=reporting_pairs,
            )
            collision_reference_penalty = collision_reference.penalty
            collision_reference_min_distance = collision_reference.min_distance
        collision_reference_pair_indices = list(collision_reference_distances)
        mark_timing("initial_fk_collision_reference")
        weighted_com_0 = compute_weighted_com(data.xipos, effective_mass, self.robot_body_ids)
        x_tilde_0 = data.xipos[self.robot_body_ids].copy() - weighted_com_0
        p_contact_world_0 = contact_point_world(data, contact_body_id, contact_point_local)
        p_contact_body_origin_world_0 = data.xpos[contact_body_id].copy()
        p_contact_tilde_0 = (
            p_contact_world_0 - weighted_com_0
        )
        stance_xipos_0 = {
            body_id: data.xipos[body_id].copy() for body_id in stance_foot_body_ids
        }

        lower, upper = self._joint_bounds(q0_joint)
        mark_timing("setup")
        event_joint_weights = self.joint_regularization_weights
        if contact_body_id in self._contact_joint_regularization:
            indices, values = self._contact_joint_regularization[contact_body_id]
            event_joint_weights = event_joint_weights.copy()
            event_joint_weights[indices] = values

        def evaluate_current_qpos(
            q_joint: np.ndarray,
            collision_pair_indices: list[tuple[int, int]] | None = None,
            include_collision: bool = True,
        ) -> tuple[float, dict[str, float]]:
            weighted_com = compute_weighted_com(data.xipos, effective_mass, self.robot_body_ids)
            world_com_displacement = weighted_com - weighted_com_0
            x_tilde = data.xipos[self.robot_body_ids] - weighted_com
            dx = x_tilde - x_tilde_0
            body_cost = float(np.sum(effective_mass[self.robot_body_ids] * np.sum(dx * dx, axis=1)))

            p_contact_world_current = contact_point_world(
                data, contact_body_id, contact_point_local
            )
            p_contact_body_origin_world_current = data.xpos[contact_body_id].copy()
            p_contact_tilde = p_contact_world_current - weighted_com
            dp_contact = p_contact_tilde - p_contact_tilde_0
            com_relative_retreat = float(np.dot(n, dp_contact))
            com_relative_tangent = float(
                np.linalg.norm(dp_contact - com_relative_retreat * n)
            )
            world_dp_contact = p_contact_world_current - p_contact_world_0
            world_retreat = float(np.dot(n, world_dp_contact))
            world_tangent = float(
                np.linalg.norm(world_dp_contact - world_retreat * n)
            )
            if (
                config.hard_support_retreat_reference_frame
                == RETREAT_REFERENCE_CONTACT_WORLD
            ):
                retreat = world_retreat
                tangent = world_tangent
            else:
                retreat = com_relative_retreat
                tangent = com_relative_tangent
            world_body_origin_displacement = (
                p_contact_body_origin_world_current - p_contact_body_origin_world_0
            )
            world_body_origin_retreat = float(
                np.dot(n, world_body_origin_displacement)
            )

            joint_delta = q_joint - q0_joint
            joint_cost = float(np.dot(event_joint_weights, joint_delta * joint_delta))
            if include_collision:
                collision_result = self.self_collision_model.evaluate_fast(
                    data,
                    d_safe=config.d_safe,
                    pair_indices=collision_pair_indices,
                    broadphase_margin=config.collision_report_margin,
                )
                collision_cost = max(0.0, collision_result.penalty - collision_reference_penalty)
                min_collision_distance = collision_result.min_distance
            else:
                collision_cost = 0.0
                min_collision_distance = collision_reference_min_distance
            foot_cost = foot_position_cost(data, stance_xipos_0)

            loss = (
                -config.w_retreat * retreat
                + config.w_body * body_cost
                + joint_cost
                + config.w_collision * collision_cost
            )
            if config.use_foot_position_penalty:
                loss += config.w_foot * foot_cost

            guided_metrics = {}
            if config.w_retreat_shortfall > 0:
                shortfall = max(config.preferred_retreat_distance - retreat, 0.0)
                loss += config.w_retreat_shortfall * shortfall**2
                guided_metrics["retreat_shortfall"] = shortfall
            if config.w_world_retreat_cone > 0:
                cone_cost = config.w_world_retreat_cone * retreat_cone_model(
                    world_dp_contact, n, config.world_retreat_cone_ratio,
                )[0]
                loss += cone_cost
                guided_metrics.update(
                    world_retreat_cone_exact_final_cost=cone_cost,
                    world_retreat_cone_exact_final_normal_m=world_retreat,
                    world_retreat_cone_exact_final_tangent_m=world_tangent,
                )
            return loss, {
                "retreat": retreat,
                "tangent": tangent,
                "com_relative_retreat_distance": com_relative_retreat,
                "com_relative_tangent_displacement": com_relative_tangent,
                "world_retreat_distance": world_retreat,
                "world_tangent_displacement": world_tangent,
                "world_body_origin_retreat_distance": world_body_origin_retreat,
                "world_body_origin_displacement_norm": float(
                    np.linalg.norm(world_body_origin_displacement)
                ),
                "world_com_displacement_norm": float(
                    np.linalg.norm(world_com_displacement)
                ),
                "body_cost": body_cost,
                "joint_cost": joint_cost,
                "collision_cost": collision_cost,
                "min_collision_distance": min_collision_distance,
                "foot_cost": foot_cost,
                **guided_metrics,
            }

        def evaluate(
            q_joint: np.ndarray,
            collision_pair_indices: list[tuple[int, int]] | None = None,
            include_collision: bool = True,
        ) -> tuple[float, dict[str, float]]:
            qpos = qpos0.copy()
            qpos[self.joint_qpos_addr] = q_joint
            self._set_qpos(data, qpos)
            return evaluate_current_qpos(
                q_joint,
                collision_pair_indices=collision_pair_indices,
                include_collision=include_collision,
            )

        active_collision_pair_indices: list[tuple[int, int]] = []
        hard_collision_targets: dict[tuple[int, int], float] = {}
        solver_info: dict[str, float | int | bool | str] = {}
        self.last_linearized_qp_solution = None
        if config.optimizer == "slsqp":
            q_joint_target, optimizer_success, message, num_iterations, objective_value, active_collision_pair_indices = self._solve_slsqp(
                objective=evaluate,
                x0=x0,
                lower=lower,
                upper=upper,
            )
        elif config.optimizer == "linearized_qp":
            qp_solution = self._solve_linearized_qp(
                data=data,
                qpos0=qpos0,
                q0_joint=q0_joint,
                contact_body_id=contact_body_id,
                contact_point_local=contact_point_local,
                retreat_normal=n,
                effective_mass=effective_mass,
                stance_foot_body_ids=stance_foot_body_ids,
                selected_stance_points=selected_stance_points,
                down_direction_world=down_direction_world,
                lower=lower,
                upper=upper,
                optimization_pair_indices=optimization_pair_indices,
            )
            q_joint_target = qp_solution.q_joint_target
            optimizer_success = qp_solution.success
            message = qp_solution.message
            num_iterations = qp_solution.num_iterations
            objective_value = qp_solution.objective_value
            active_collision_pair_indices = qp_solution.active_collision_pair_indices
            hard_collision_targets = qp_solution.hard_collision_targets
            solver_info = qp_solution.info
            self.last_linearized_qp_solution = qp_solution
            mark_timing("linearized_qp")
        else:
            raise ValueError(f"Unknown optimizer {config.optimizer!r}")

        if config.optimizer == "linearized_qp" and config.linearized_qp_solver != "proxqp":
            q_joint_target = self._select_linearized_step(
                q0_joint=q0_joint,
                q_joint_target=q_joint_target,
                evaluate=evaluate,
                data=data,
                active_collision_pair_indices=merge_pair_indices(
                    active_collision_pair_indices,
                    collision_reference_pair_indices,
                ),
                collision_reference_distances=collision_reference_distances,
                contact_body_id=contact_body_id,
            )
            mark_timing("step_select")

        qpos_target = qpos0.copy()
        qpos_target[self.joint_qpos_addr] = q_joint_target
        base_delta = (
            qp_solution.base_delta
            if config.optimizer == "linearized_qp"
            else np.zeros(6, dtype=np.float64)
        )
        hard_support_mode = (
            config.optimizer == "linearized_qp"
            and config.linearized_qp_solver == "proxqp"
            and config.reflex_mode != REFLEX_MODE_VIRTUAL_MASS_MOMENTUM
        )
        if config.optimizer == "linearized_qp" and config.linearized_qp_solver == "proxqp":
            if hard_support_mode:
                self._apply_base_increment(qpos_target, base_delta)
            else:
                self._apply_base_reaction_rotation(qpos_target, base_delta)
        mark_timing("root_rotation")

        pre_placement_stance_foot_displacement = float("nan")
        pre_placement_stance_frame_rotation = float("nan")
        pre_placement_retreat_distance = float("nan")
        placement_start = time.perf_counter()
        self._set_qpos(data, qpos_target)
        if config.collect_diagnostics:
            _, pre_placement_metrics = evaluate_current_qpos(q_joint_target, include_collision=False)
            pre_placement_stance_foot_displacement = (
                max_stance_point_displacement(
                    data, selected_stance_points, stance_point_positions_0
                )
                if hard_support_mode
                else max_foot_displacement(data, stance_xipos_0)
            )
            pre_placement_stance_frame_rotation = (
                max_stance_frame_rotation(
                    data, selected_stance_points, stance_frame_rotations_0
                )
                if hard_support_mode
                else float("nan")
            )
            pre_placement_retreat_distance = pre_placement_metrics["retreat"]
        if hard_support_mode:
            com_placement_translation = np.zeros(3, dtype=np.float64)
        else:
            weighted_com = compute_weighted_com(data.xipos, effective_mass, self.robot_body_ids)
            com_placement_translation = weighted_com_0 - weighted_com
            qpos_target[self.root_qpos_addr : self.root_qpos_addr + 3] += com_placement_translation
            self._set_qpos(data, qpos_target)
        com_placement_translation_norm = float(np.linalg.norm(com_placement_translation))
        com_placement_time_ms = (time.perf_counter() - placement_start) * 1000.0
        mark_timing("root_translation")

        support_region = (
            qp_solution.support_region if hard_support_mode else None
        )
        if support_region is not None:
            balance_validation_start = time.perf_counter()
            (
                balance_success,
                balance_info,
            ) = self._validate_hard_support_balance_pose(
                data,
                support_region,
            )
            balance_fail_closed = bool(optimizer_success and not balance_success)
            if balance_fail_closed:
                attempted_min_margin = float(
                    balance_info["hard_support_balance_final_min_margin_m"]
                )
                attempted_violation = float(
                    balance_info[
                        "hard_support_balance_nonlinear_max_violation_m"
                    ]
                )
                qpos_target = qpos0.copy()
                q_joint_target = q0_joint.copy()
                base_delta = np.zeros(6, dtype=np.float64)
                optimizer_success = False
                message = (
                    f"{message}; exact support-region validation failed; "
                    "returned q0"
                )
                self._set_qpos(data, qpos_target)
                _, published_balance_info = (
                    self._validate_hard_support_balance_pose(
                        data,
                        support_region,
                    )
                )
                balance_info = {
                    **published_balance_info,
                    "hard_support_balance_attempted_final_min_margin_m": (
                        attempted_min_margin
                    ),
                    "hard_support_balance_attempted_nonlinear_max_violation_m": (
                        attempted_violation
                    ),
                    "hard_support_balance_fail_closed": True,
                }
                qp_solution = replace(
                    qp_solution,
                    q_joint_target=q0_joint.copy(),
                    base_delta=np.zeros(6, dtype=np.float64),
                    success=False,
                    message=message,
                )
                self.last_linearized_qp_solution = qp_solution
            else:
                balance_info["hard_support_balance_fail_closed"] = False
            balance_info["hard_support_balance_validation_time_ms"] = (
                time.perf_counter() - balance_validation_start
            ) * 1000.0
            solver_info.update(balance_info)
            mark_timing("support_region_validation")

        _, metrics = evaluate_current_qpos(q_joint_target, include_collision=False)
        joint_delta = q_joint_target - q0_joint
        joint_bound_activity = self._joint_bound_activity(q0_joint, q_joint_target)
        waist_delta = joint_delta[self.waist_joint_indices] if self.waist_joint_indices.size else np.array([], dtype=np.float64)
        stance_foot_displacement = (
            max_stance_point_displacement(
                data, selected_stance_points, stance_point_positions_0
            )
            if hard_support_mode
            else max_foot_displacement(data, stance_xipos_0)
        )
        stance_frame_rotation = (
            max_stance_frame_rotation(
                data, selected_stance_points, stance_frame_rotations_0
            )
            if hard_support_mode
            else float("nan")
        )
        if hard_support_mode and config.w_static_support_effort > 0.0:
            if bool(
                solver_info.get("static_support_effort_available", False)
            ):
                try:
                    final_static_support = self.evaluate_static_support_effort(
                        data,
                        selected_stance_points,
                    )
                except StaticSupportModelRankError as exc:
                    # This is final diagnostics for an optional soft prior,
                    # not a mandatory feasibility gate.  Keep it explicit and
                    # never convert it into a different model or fallback.
                    solver_info.update(
                        {
                            "static_support_effort_final_evaluation_available": (
                                False
                            ),
                            "static_support_effort_final_unavailable_reason": (
                                str(exc)
                            ),
                            "static_support_effort_final_unavailable_rank": (
                                exc.rank
                            ),
                        }
                    )
                else:
                    down_unit = np.asarray(
                        down_direction_world,
                        dtype=np.float64,
                    ).copy()
                    down_unit /= max(
                        float(np.linalg.norm(down_unit)),
                        1.0e-12,
                    )
                    support_normal_forces = (
                        final_static_support.support_force @ (-down_unit)
                    )
                    solver_info.update(
                        {
                            "static_support_effort_final_evaluation_available": (
                                True
                            ),
                            "static_support_effort_final_unavailable_reason": "",
                            "static_support_effort_final": (
                                final_static_support.effort
                            ),
                            "static_support_final_actuator_torque_norm": float(
                                np.linalg.norm(
                                    final_static_support.actuator_torque
                                )
                            ),
                            "static_support_final_min_normal_force": float(
                                np.min(support_normal_forces)
                            ),
                            "static_support_final_negative_normal_force_count": int(
                                np.count_nonzero(
                                    support_normal_forces < -1.0e-6
                                )
                            ),
                            "static_support_final_equilibrium_residual": (
                                final_static_support.equilibrium_residual
                            ),
                        }
                    )
            else:
                solver_info.update(
                    {
                        "static_support_effort_final_evaluation_available": (
                            False
                        ),
                        "static_support_effort_final_unavailable_reason": (
                            solver_info.get(
                                "static_support_effort_unavailable_reason",
                                "qpos0 model unavailable",
                            )
                        ),
                    }
                )
        if config.min_retreat_distance is None:
            retreat_satisfied = metrics["retreat"] > 0.0
            retreat_failure_message = "optimizer converged but contact point did not retreat along the requested normal"
        else:
            retreat_satisfied = metrics["retreat"] >= config.min_retreat_distance
            retreat_failure_message = (
                "optimizer converged but nonlinear retreat "
                f"{metrics['retreat']:.4f} m is below required {config.min_retreat_distance:.4f} m"
            )
        success = bool(optimizer_success and retreat_satisfied)
        if optimizer_success and not retreat_satisfied:
            message = retreat_failure_message

        min_self_collision_distance = float("nan")
        optimization_min_collision_distance = float("nan")
        reporting_optimization_min_error = float("nan")
        hard_collision_nonlinear_max_violation = float("nan")
        final_distances: dict[tuple[int, int], float] | None = None
        # The formal hard-support profile publishes the projected three-QP
        # result directly. Collision avoidance remains inside each QP; an
        # optional diagnostics request may evaluate the terminal pose, but it
        # is neither repeated in the required path nor used as a release gate.
        if (
            not config.hard_support_joint_hit_restoration_enabled
            and not config.hard_support_balance_constraint_enabled
        ):
            solver_info[
                "hard_support_nonlinear_validation_in_required_compute"
            ] = False
        mark_timing("final_metrics")
        required_compute_time_ms = (time.perf_counter() - start) * 1000.0

        diagnostics_start = time.perf_counter()
        if config.collect_diagnostics:
            if final_distances is None:
                diagnostic_pairs = merge_pair_indices(
                    list(reporting_pairs),
                    optimization_pair_indices,
                )
                final_distances = self.self_collision_model.distance_map(
                    data,
                    pair_indices=diagnostic_pairs,
                )
            reporting_distances = [final_distances[pair] for pair in reporting_pairs]
            optimization_distances = [final_distances[pair] for pair in optimization_pair_indices]
            min_self_collision_distance = min(reporting_distances, default=float("nan"))
            optimization_min_collision_distance = min(optimization_distances, default=float("nan"))
            reporting_optimization_min_error = abs(
                min_self_collision_distance - optimization_min_collision_distance
            )
            if hard_collision_targets:
                hard_collision_nonlinear_max_violation = max(
                    max(0.0, target - final_distances[pair])
                    for pair, target in hard_collision_targets.items()
                )
            else:
                hard_collision_nonlinear_max_violation = 0.0
            metrics["min_collision_distance"] = min_self_collision_distance
            if hard_support_mode:
                base_dofs = self._base_dofs
                kinematic_dofs = self._kinematic_dofs
                total_delta_full = np.zeros(
                    self.model.nv,
                    dtype=np.float64,
                )
                mujoco.mj_differentiatePos(
                    self.model,
                    total_delta_full,
                    1.0,
                    qpos0,
                    qpos_target,
                )
                total_delta_kinematic = total_delta_full[kinematic_dofs]

                self._set_qpos(data, qpos0)
                initial_angular_model = self._build_angular_motion_model(
                    data,
                    kinematic_dofs,
                )
                self._set_qpos(data, qpos_target)
                final_angular_model = self._build_angular_motion_model(
                    data,
                    kinematic_dofs,
                )
                initial_angular_momentum = (
                    initial_angular_model.angular_momentum_matrix
                    @ total_delta_kinematic
                )
                initial_centroidal_omega = (
                    initial_angular_model.centroidal_inertia_inverse
                    @ initial_angular_momentum
                )
                final_angular_momentum = (
                    final_angular_model.angular_momentum_matrix
                    @ total_delta_kinematic
                )
                final_centroidal_omega = (
                    final_angular_model.centroidal_inertia_inverse
                    @ final_angular_momentum
                )
                initial_omega_norm = float(
                    np.linalg.norm(initial_centroidal_omega)
                )
                if initial_omega_norm > 1.0e-12:
                    initial_omega_axis = (
                        initial_centroidal_omega / initial_omega_norm
                    )
                    initial_axis_inertia = float(
                        initial_omega_axis
                        @ initial_angular_model.centroidal_inertia
                        @ initial_omega_axis
                    )
                    final_axis_inertia = float(
                        initial_omega_axis
                        @ final_angular_model.centroidal_inertia
                        @ initial_omega_axis
                    )
                    axis_inertia_ratio = final_axis_inertia / max(
                        initial_axis_inertia,
                        1.0e-14,
                    )
                else:
                    initial_axis_inertia = 0.0
                    final_axis_inertia = 0.0
                    axis_inertia_ratio = 1.0
                initial_inertia_trace = float(
                    np.trace(initial_angular_model.centroidal_inertia)
                )
                final_inertia_trace = float(
                    np.trace(final_angular_model.centroidal_inertia)
                )
                solver_info.update(
                    {
                        "final_centroidal_angular_momentum_norm": float(
                            np.linalg.norm(final_angular_momentum)
                        ),
                        "final_centroidal_equivalent_angular_velocity_norm": float(
                            np.linalg.norm(final_centroidal_omega)
                        ),
                        "initial_locked_inertia_along_initial_omega": (
                            initial_axis_inertia
                        ),
                        "final_locked_inertia_along_initial_omega": (
                            final_axis_inertia
                        ),
                        "locked_inertia_along_initial_omega_ratio": (
                            axis_inertia_ratio
                        ),
                        "initial_locked_centroidal_inertia_trace": (
                            initial_inertia_trace
                        ),
                        "final_locked_centroidal_inertia_trace": (
                            final_inertia_trace
                        ),
                        "locked_centroidal_inertia_trace_ratio": (
                            final_inertia_trace
                            / max(initial_inertia_trace, 1.0e-14)
                        ),
                    }
                )
        postsolve_diagnostics_time_ms = (time.perf_counter() - diagnostics_start) * 1000.0
        if config.collect_diagnostics:
            mark_timing("postsolve_diagnostics")
        total_solve_wall_time_ms = (time.perf_counter() - start) * 1000.0

        return ReflexTargetResult(
            qpos_target=qpos_target,
            success=success,
            retreat_distance=metrics["retreat"],
            tangent_displacement=metrics["tangent"],
            body_displacement_cost=metrics["body_cost"],
            joint_delta_norm=float(np.linalg.norm(joint_delta)),
            max_joint_delta=float(np.max(np.abs(joint_delta))) if joint_delta.size else 0.0,
            stance_foot_displacement=stance_foot_displacement,
            min_self_collision_distance=min_self_collision_distance,
            solve_time_ms=required_compute_time_ms,
            num_iterations=num_iterations,
            message=message,
            stance_body_ids=tuple(
                dict.fromkeys(
                    point.body_id for point in selected_stance_points
                )
            ),
            info={
                "optimizer_success": bool(optimizer_success),
                "optimizer": config.optimizer,
                "linearized_qp_solver": config.linearized_qp_solver,
                "collision_reporting_pairs": len(reporting_pairs),
                "collision_optimization_pairs": len(optimization_pair_indices),
                "optimization_min_collision_distance": optimization_min_collision_distance,
                "reporting_optimization_min_error": reporting_optimization_min_error,
                "waist_delta_norm": float(np.linalg.norm(waist_delta)),
                "waist_max_delta": float(np.max(np.abs(waist_delta))) if waist_delta.size else 0.0,
                "pre_placement_stance_foot_displacement": pre_placement_stance_foot_displacement,
                "pre_placement_stance_frame_rotation": pre_placement_stance_frame_rotation,
                "pre_placement_retreat_distance": pre_placement_retreat_distance,
                "base_reaction_translation_norm": float(np.linalg.norm(base_delta[:3])),
                "base_reaction_rotation_norm": float(np.linalg.norm(base_delta[3:])),
                "com_placement_translation_norm": com_placement_translation_norm,
                "com_placement_time_ms": com_placement_time_ms,
                "root_translation_norm": float(
                    np.linalg.norm(
                        qpos_target[self.root_qpos_addr : self.root_qpos_addr + 3]
                        - qpos0[self.root_qpos_addr : self.root_qpos_addr + 3]
                    )
                ),
                "root_rotation_norm": float(np.linalg.norm(base_delta[3:])),
                "required_compute_time_ms": required_compute_time_ms,
                "optimizer_required_compute_time_ms": required_compute_time_ms,
                "postsolve_diagnostics_time_ms": postsolve_diagnostics_time_ms,
                "total_solve_wall_time_ms": total_solve_wall_time_ms,
                "diagnostics_collected": config.collect_diagnostics,
                "objective": objective_value,
                "required_retreat_distance": config.min_retreat_distance or 0.0,
                "hard_collision_nonlinear_max_violation": hard_collision_nonlinear_max_violation,
                "selected_stance_point_count": len(selected_stance_points),
                "stance_point_displacement": stance_foot_displacement,
                "stance_frame_rotation": stance_frame_rotation,
                **joint_bound_activity,
                **solver_info,
                **{f"timing_{key}_ms": value for key, value in timings.items()},
                **metrics,
            },
        )

    def _solve_slsqp(
        self,
        objective,
        x0: np.ndarray,
        lower: np.ndarray,
        upper: np.ndarray,
    ) -> tuple[np.ndarray, bool, str, int, float, list[tuple[int, int]]]:
        def scalar_objective(q_joint: np.ndarray) -> float:
            value, _ = objective(q_joint)
            if not math.isfinite(value):
                return 1e12
            return value

        result = minimize(
            scalar_objective,
            x0=x0,
            method="SLSQP",
            bounds=list(zip(lower, upper)),
            options={
                "maxiter": self.config.max_iter,
                "ftol": self.config.ftol,
                "eps": self.config.finite_difference_step,
                "disp": False,
            },
        )
        if np.all(np.isfinite(result.x)):
            q_joint_target = np.clip(result.x, lower, upper)
        else:
            q_joint_target = x0.copy()
        return (
            q_joint_target,
            bool(result.success),
            str(result.message),
            int(getattr(result, "nit", 0)),
            float(getattr(result, "fun", np.nan)),
            [],
        )

    def _solve_linearized_qp(
        self,
        data: mujoco.MjData,
        qpos0: np.ndarray,
        q0_joint: np.ndarray,
        contact_body_id: int,
        contact_point_local: np.ndarray,
        retreat_normal: np.ndarray,
        effective_mass: np.ndarray,
        stance_foot_body_ids: list[int],
        selected_stance_points: tuple[ResolvedStancePoint, ...],
        down_direction_world: np.ndarray | None,
        lower: np.ndarray,
        upper: np.ndarray,
        optimization_pair_indices: list[tuple[int, int]],
    ) -> LinearizedQPSolution:
        self._set_qpos(data, qpos0)
        if (
            self.config.linearized_qp_solver == "proxqp"
            and self.config.reflex_mode != REFLEX_MODE_VIRTUAL_MASS_MOMENTUM
        ):
            return self._solve_hard_support_qp(
                data=data,
                qpos0=qpos0,
                q0_joint=q0_joint,
                contact_body_id=contact_body_id,
                contact_point_local=contact_point_local,
                retreat_normal=retreat_normal,
                selected_stance_points=selected_stance_points,
                down_direction_world=down_direction_world,
                lower=lower,
                upper=upper,
                optimization_pair_indices=optimization_pair_indices,
            )
        body_com_jacobians_full = self._body_com_jacobians_full(data)
        body_com_jacobians = np.take(
            body_com_jacobians_full, self.joint_dof_addr, axis=2
        )
        j_wcom = self._weighted_com_jacobian_from_cache(body_com_jacobians, effective_mass)
        j_contact = self._point_jacobian(data, contact_body_id, contact_point_local)
        j_contact_tilde = j_contact - j_wcom

        n_joint = len(self.joint_ids)
        regularizer = np.diag(self.joint_regularization_weights)
        momentum_connection = np.empty((0, n_joint), dtype=np.float64)

        if self.config.linearized_qp_solver == "proxqp":
            reduced_inertia, momentum_connection, connection_residual = (
                self._reduced_generalized_inertia(data, stance_foot_body_ids)
            )
            if self.config.w_body > 0.0:
                regularizer += 0.5 * self.config.w_body * reduced_inertia
            j_wcom_full = self._weighted_com_jacobian_from_cache(
                body_com_jacobians_full, effective_mass
            )
            j_contact_full = self._point_jacobian_full(
                data, contact_body_id, contact_point_local
            )
            j_contact_tilde_full = j_contact_full - j_wcom_full
            base = np.arange(self.root_dof_addr, self.root_dof_addr + 6)
            j_contact_tilde = (
                j_contact_tilde_full[:, base] @ momentum_connection
                + j_contact_tilde_full[:, self.joint_dof_addr]
            )
        else:
            for body_id in self.robot_body_ids:
                jac = body_com_jacobians[body_id] - j_wcom
                regularizer += self.config.w_body * effective_mass[body_id] * (jac.T @ jac)

            if self.config.use_foot_position_penalty and stance_foot_body_ids:
                for body_id in stance_foot_body_ids:
                    jac = body_com_jacobians[body_id]
                    regularizer += self.config.w_foot * (jac.T @ jac)

        regularizer += self.config.linearized_damping * np.eye(n_joint)
        hard_retreat = (
            self.config.linearized_qp_solver == "proxqp"
            and self.config.min_retreat_distance is not None
        )
        linear_term = (
            np.zeros(n_joint, dtype=np.float64)
            if hard_retreat
            else self.config.w_retreat * (j_contact_tilde.T @ retreat_normal)
        )
        active_collision_pair_indices: list[tuple[int, int]] = []
        contact_mask = self._ancestor_joint_mask(contact_body_id)
        if self.config.non_contact_joint_scale < 1.0:
            linear_term[~contact_mask] *= self.config.non_contact_joint_scale

        lower_delta = lower - q0_joint
        upper_delta = upper - q0_joint
        hard_collision_targets: dict[tuple[int, int], float] = {}
        hard_collision_slacks = np.empty(0, dtype=np.float64)
        hard_collision_duals = np.empty(0, dtype=np.float64)
        solver_info: dict[str, float | int | bool | str] = {}
        if self.config.linearized_qp_solver == "proxqp":
            (
                collision_jacobian,
                collision_lower,
                active_collision_pair_indices,
                hard_collision_targets,
            ) = self._linearized_collision_constraints(data, optimization_pair_indices)
            qp_jacobian = collision_jacobian
            qp_lower = collision_lower
            if hard_retreat:
                retreat_jacobian = (retreat_normal @ j_contact_tilde).reshape(1, -1)
                qp_jacobian = np.vstack((qp_jacobian, retreat_jacobian))
                qp_lower = np.concatenate((qp_lower, [self.config.min_retreat_distance]))
            (
                delta,
                optimizer_success,
                message,
                num_iterations,
                solver_info,
                hard_collision_duals,
            ) = solve_box_collision_qp_proxqp(
                regularizer=regularizer,
                linear_term=linear_term,
                lower=lower_delta,
                upper=upper_delta,
                collision_jacobian=qp_jacobian,
                collision_lower=qp_lower,
                eps_abs=self.config.proxqp_eps_abs,
                eps_rel=self.config.proxqp_eps_rel,
                max_iterations=self.config.proxqp_max_iter,
            )
            solver_info["momentum_connection_residual"] = connection_residual
            collision_constraint_count = collision_jacobian.shape[0]
            hard_collision_duals = hard_collision_duals[:collision_constraint_count]
            solver_info["hard_collision_constraint_count"] = collision_constraint_count
            solver_info["hard_collision_linear_max_violation"] = float(
                np.max(np.maximum(collision_lower - collision_jacobian @ delta, 0.0), initial=0.0)
            )
            if hard_retreat:
                retreat_slack = float(
                    (retreat_jacobian @ delta)[0] - self.config.min_retreat_distance
                )
                solver_info["retreat_constraint_linear_slack"] = retreat_slack
                solver_info["retreat_constraint_linear_violation"] = max(0.0, -retreat_slack)
            hard_collision_slacks = collision_jacobian @ delta - collision_lower
        elif self.config.linearized_qp_solver == "lbfgsb":
            active_collision_pair_indices = self._add_linearized_collision_terms(
                data,
                regularizer,
                linear_term,
                optimization_pair_indices,
            )
            delta, optimizer_success, message, num_iterations = solve_box_qp_lbfgsb(
                regularizer=regularizer,
                linear_term=linear_term,
                lower=lower_delta,
                upper=upper_delta,
                max_iterations=self.config.linearized_lbfgsb_max_iter,
                ftol=self.config.linearized_lbfgsb_ftol,
                gtol=self.config.linearized_lbfgsb_gtol,
            )
        elif self.config.linearized_qp_solver == "active_set":
            active_collision_pair_indices = self._add_linearized_collision_terms(
                data,
                regularizer,
                linear_term,
                optimization_pair_indices,
            )
            delta = solve_box_qp_active_set(
                regularizer=regularizer,
                linear_term=linear_term,
                lower=lower_delta,
                upper=upper_delta,
                max_iterations=self.config.linearized_active_set_iterations,
            )
            optimizer_success = True
            message = "active_set solved"
            num_iterations = 1
        else:
            raise ValueError(f"Unknown linearized QP solver {self.config.linearized_qp_solver!r}")
        q_joint_target = np.clip(q0_joint + delta, lower, upper)
        base_delta = (
            momentum_connection @ (q_joint_target - q0_joint)
            if self.config.linearized_qp_solver == "proxqp"
            else np.zeros(6, dtype=np.float64)
        )
        objective_value = float(delta @ regularizer @ delta - linear_term @ delta)
        return LinearizedQPSolution(
            q_joint_target=q_joint_target,
            base_delta=base_delta,
            success=optimizer_success,
            message=f"linearized_qp/{self.config.linearized_qp_solver}: {message}",
            num_iterations=num_iterations,
            objective_value=objective_value,
            active_collision_pair_indices=active_collision_pair_indices,
            hard_collision_targets=hard_collision_targets,
            hard_collision_slacks=hard_collision_slacks,
            hard_collision_duals=hard_collision_duals,
            info=solver_info,
        )

    def _solve_hard_support_qp(
        self,
        data: mujoco.MjData,
        qpos0: np.ndarray,
        q0_joint: np.ndarray,
        contact_body_id: int,
        contact_point_local: np.ndarray,
        retreat_normal: np.ndarray,
        selected_stance_points: tuple[ResolvedStancePoint, ...],
        down_direction_world: np.ndarray | None,
        lower: np.ndarray,
        upper: np.ndarray,
        optimization_pair_indices: list[tuple[int, int]],
    ) -> LinearizedQPSolution:
        """Solve up to four sequential hard-support trust-region QPs."""

        rounds = self.config.hard_support_qp_rounds
        if rounds not in (1, 2, 3, 4):
            raise ValueError("hard_support_qp_rounds must be between 1 and 4")

        base_dofs = self._base_dofs
        kinematic_dofs = self._kinematic_dofs
        n_kinematic = len(kinematic_dofs)

        self._set_qpos(data, qpos0)
        inertia_full = np.empty((self.model.nv, self.model.nv), dtype=np.float64)
        mujoco.mj_fullM(self.model, data, inertia_full)
        reference_inertia = inertia_full[np.ix_(kinematic_dofs, kinematic_dofs)]
        reference_inertia = 0.5 * (reference_inertia + reference_inertia.T)
        angular_motion_model = None
        if (
            self.config.collect_diagnostics
            or self.config.angular_regularization_mode
            != ANGULAR_REGULARIZATION_NONE
            or self.config.hard_support_body_energy_mode
            != HARD_SUPPORT_BODY_ENERGY_FULL
        ):
            angular_motion_model = self._build_angular_motion_model(
                data,
                kinematic_dofs,
            )
        reference_com = compute_weighted_com(
            data.xipos,
            self.model.body_mass,
            self.robot_body_ids,
        )
        if self.config.hard_support_balance_constraint_enabled:
            if down_direction_world is None:
                raise ValueError(
                    "Hard-support balance constraints require down_direction_world"
                )
            support_region = build_frozen_support_region(
                data,
                selected_stance_points,
                down_direction_world,
                reference_com,
                safety_margin_m=self.config.hard_support_balance_margin,
            )
        else:
            support_region = None
        reference_contact_world = contact_point_world(
            data, contact_body_id, contact_point_local
        )
        reference_contact_relative_to_com = reference_contact_world - reference_com
        reference_stance_positions = {
            point.name: contact_point_world(data, point.body_id, point.local_position)
            for point in selected_stance_points
        }
        reference_stance_rotations = {
            point.name: data.xmat[point.body_id].reshape(3, 3).copy()
            for point in selected_stance_points
        }
        body_energy_model = self._build_hard_support_body_energy_model(
            data=data,
            kinematic_dofs=kinematic_dofs,
            reference_inertia=reference_inertia,
            angular_motion_model=angular_motion_model,
            selected_stance_points=selected_stance_points,
        )
        if contact_body_id in self._contact_joint_regularization:
            indices, values = self._contact_joint_regularization[contact_body_id]
            event_weights = body_energy_model.effective_joint_regularization.copy()
            event_weights[indices] = values
            body_energy_model = replace(body_energy_model, effective_joint_regularization=event_weights)
        static_support_effort_requested = (
            self.config.w_static_support_effort > 0.0
        )
        static_support_effort_model = None
        static_support_availability: dict[str, float | int | bool | str] = {
            "static_support_effort_requested": static_support_effort_requested,
            "static_support_effort_available": False,
            "static_support_effort_unavailable_reason": (
                "disabled by zero weight"
                if not static_support_effort_requested
                else ""
            ),
            "static_support_effort_unavailable_rank": 0,
            "static_support_effort_required_rank": n_kinematic,
        }
        if static_support_effort_requested:
            try:
                static_support_effort_model = (
                    self._build_static_support_effort_model(
                        data,
                        qpos0,
                        selected_stance_points,
                        kinematic_dofs,
                    )
                )
            except StaticSupportModelRankError as exc:
                # The quasistatic effort term is an optional soft prior.  A
                # translational point-force model that cannot span the full
                # floating-base equilibrium must not invalidate the mandatory
                # stance, collision, joint, retreat, or balance constraints.
                static_support_availability.update(
                    {
                        "static_support_effort_unavailable_reason": str(exc),
                        "static_support_effort_unavailable_rank": exc.rank,
                        "static_support_effort_required_rank": (
                            exc.required_rank
                        ),
                    }
                )
            else:
                static_support_availability.update(
                    {
                        "static_support_effort_available": True,
                        "static_support_effort_unavailable_reason": "",
                        "static_support_effort_unavailable_rank": 0,
                        "static_support_effort_required_rank": n_kinematic,
                    }
                )
        # This q0-frozen curvature is identical in every sequential QP round.
        # Build it once per event, in exactly the same operation order used by
        # the former per-round path, and pass it through read-only.
        absolute_regularizer = (
            0.5 * self.config.w_body * body_energy_model.active_inertia
        )
        absolute_regularizer[6:, 6:] += np.diag(
            body_energy_model.effective_joint_regularization
        )
        absolute_regularizer += self.config.linearized_damping * np.eye(
            n_kinematic
        )
        if angular_motion_model is not None:
            absolute_regularizer += angular_motion_model.objective_regularizer
        if static_support_effort_model is not None:
            absolute_regularizer += (
                static_support_effort_model.objective_regularizer
            )
        if rounds == 1:
            solution = self._solve_hard_support_qp_round(
                data=data,
                q0_joint=q0_joint,
                current_qpos=qpos0,
                accumulated_delta=np.zeros(n_kinematic, dtype=np.float64),
                reference_inertia=reference_inertia,
                body_energy_model=body_energy_model,
                absolute_regularizer=absolute_regularizer,
                static_support_effort_model=static_support_effort_model,
                angular_motion_model=angular_motion_model,
                reference_com=reference_com,
                reference_contact_world=reference_contact_world,
                reference_contact_relative_to_com=reference_contact_relative_to_com,
                reference_stance_positions=reference_stance_positions,
                reference_stance_rotations=reference_stance_rotations,
                support_region=support_region,
                contact_body_id=contact_body_id,
                contact_point_local=contact_point_local,
                retreat_normal=retreat_normal,
                selected_stance_points=selected_stance_points,
                correction_lower=lower - q0_joint,
                correction_upper=upper - q0_joint,
                optimization_pair_indices=optimization_pair_indices,
                collision_target_distances=None,
                round_index=1,
            )
            info = dict(solution.info)
            info.update(
                {
                    "hard_support_qp_rounds_requested": 1,
                    "hard_support_qp_rounds_completed": int(solution.success),
                    "hard_support_joint_trust_region": 0.0,
                    "hard_support_round_1_success": solution.success,
                    "hard_support_round_1_iterations": solution.num_iterations,
                    "hard_support_round_1_proxqp_solve_time_ms": float(
                        solution.info.get("proxqp_solve_time_ms", 0.0)
                    ),
                    "hard_support_round_1_joint_correction_max": float(
                        solution.info.get(
                            "hard_support_round_joint_correction_max",
                            0.0,
                        )
                    ),
                    **static_support_availability,
                }
            )
            return replace(solution, info=info)

        physical_lower, physical_upper = self._physical_joint_target_bounds(q0_joint)
        trust_radius = self.config.hard_support_joint_trust_region
        current_qpos = qpos0.copy()
        accumulated_delta = np.zeros(n_kinematic, dtype=np.float64)
        round_solutions: list[LinearizedQPSolution] = []
        collision_target_distances: dict[tuple[int, int], float] | None = None
        restoration_enabled = (
            self.config.hard_support_joint_hit_restoration_enabled
        )
        qp_workspace_holder: list[DenseProxQPWorkspace] | None = (
            [] if restoration_enabled else None
        )
        used_minimal_round_reports = False
        round_replay_inputs: list[HardSupportRoundReplayInputs] = []
        round_solver_replays: list[HardSupportQPSolverReplay | None] = []

        for round_index in range(1, rounds + 1):
            self._set_qpos(data, current_qpos)
            current_joint = current_qpos[self.joint_qpos_addr].copy()
            correction_lower = np.maximum(
                physical_lower - current_joint,
                -trust_radius,
            )
            correction_upper = np.minimum(
                physical_upper - current_joint,
                trust_radius,
            )
            round_replay_inputs.append(
                HardSupportRoundReplayInputs(
                    current_qpos=current_qpos,
                    accumulated_delta=accumulated_delta,
                    correction_lower=correction_lower,
                    correction_upper=correction_upper,
                    collision_target_distances=collision_target_distances,
                    round_index=round_index,
                )
            )
            solver_replay_holder: list[HardSupportQPSolverReplay] = []
            solution = self._solve_hard_support_qp_round(
                data=data,
                q0_joint=q0_joint,
                current_qpos=current_qpos,
                accumulated_delta=accumulated_delta,
                reference_inertia=reference_inertia,
                body_energy_model=body_energy_model,
                absolute_regularizer=absolute_regularizer,
                static_support_effort_model=static_support_effort_model,
                angular_motion_model=angular_motion_model,
                reference_com=reference_com,
                reference_contact_world=reference_contact_world,
                reference_contact_relative_to_com=reference_contact_relative_to_com,
                reference_stance_positions=reference_stance_positions,
                reference_stance_rotations=reference_stance_rotations,
                support_region=support_region,
                contact_body_id=contact_body_id,
                contact_point_local=contact_point_local,
                retreat_normal=retreat_normal,
                selected_stance_points=selected_stance_points,
                correction_lower=correction_lower,
                correction_upper=correction_upper,
                optimization_pair_indices=optimization_pair_indices,
                collision_target_distances=collision_target_distances,
                round_index=round_index,
                qp_workspace_holder=qp_workspace_holder,
                minimal_report=bool(
                    not self.config.collect_diagnostics
                    and not restoration_enabled
                    and round_index < rounds
                ),
                solver_replay_holder=solver_replay_holder,
            )
            round_solver_replays.append(
                solver_replay_holder[0] if solver_replay_holder else None
            )
            used_minimal_round_reports = bool(
                used_minimal_round_reports
                or (
                    not self.config.collect_diagnostics
                    and not restoration_enabled
                    and round_index < rounds
                )
            )
            round_solutions.append(solution)
            if not solution.success:
                break

            correction = np.zeros(self.model.nv, dtype=np.float64)
            correction[base_dofs] = solution.base_delta
            correction[self.joint_dof_addr] = (
                solution.q_joint_target - current_joint
            )
            next_qpos = current_qpos.copy()
            mujoco.mj_integratePos(self.model, next_qpos, correction, 1.0)
            current_qpos = next_qpos
            total_delta = np.zeros(self.model.nv, dtype=np.float64)
            mujoco.mj_differentiatePos(
                self.model,
                total_delta,
                1.0,
                qpos0,
                current_qpos,
            )
            accumulated_delta = total_delta[kinematic_dofs]
            collision_target_distances = solution.hard_collision_targets
        completed = sum(solution.success for solution in round_solutions)
        if used_minimal_round_reports and completed != rounds:
            # Only the published fallback needs a full report.  Reconstruct
            # that report from its already-frozen ProxQP result: re-solving a
            # fresh, ill-conditioned QP here could select a different branch
            # and would therefore alter failure semantics.
            published_index = 0 if completed == 0 else completed - 1
            replay = round_solver_replays[published_index]
            if replay is None:
                raise RuntimeError("deferred hard-support report is unavailable")
            replay_inputs = round_replay_inputs[published_index]
            self._set_qpos(data, replay_inputs.current_qpos)
            round_solutions[published_index] = self._solve_hard_support_qp_round(
                data=data,
                q0_joint=q0_joint,
                current_qpos=replay_inputs.current_qpos,
                accumulated_delta=replay_inputs.accumulated_delta,
                reference_inertia=reference_inertia,
                body_energy_model=body_energy_model,
                absolute_regularizer=absolute_regularizer,
                static_support_effort_model=static_support_effort_model,
                angular_motion_model=angular_motion_model,
                reference_com=reference_com,
                reference_contact_world=reference_contact_world,
                reference_contact_relative_to_com=reference_contact_relative_to_com,
                reference_stance_positions=reference_stance_positions,
                reference_stance_rotations=reference_stance_rotations,
                support_region=support_region,
                contact_body_id=contact_body_id,
                contact_point_local=contact_point_local,
                retreat_normal=retreat_normal,
                selected_stance_points=selected_stance_points,
                correction_lower=replay_inputs.correction_lower,
                correction_upper=replay_inputs.correction_upper,
                optimization_pair_indices=optimization_pair_indices,
                collision_target_distances=(
                    replay_inputs.collision_target_distances
                ),
                round_index=replay_inputs.round_index,
                qp_workspace_holder=None,
                minimal_report=False,
                precomputed_solver_result=replay,
            )
        first = round_solutions[0]
        restoration_success = not restoration_enabled
        restoration_message = "disabled"
        restoration_iterations = 0
        restoration_info: dict[str, float | int | bool | str] = {
            "hard_support_joint_hit_restoration_enabled": restoration_enabled,
            "hard_support_joint_hit_restoration_attempted": False,
            "hard_support_joint_hit_restoration_success": restoration_success,
        }
        if restoration_enabled:
            if completed != rounds:
                restoration_message = (
                    "task QP did not complete both required rounds"
                )
            elif qp_workspace_holder is None or len(qp_workspace_holder) != 1:
                restoration_message = "event-local ProxQP workspace is unavailable"
            else:
                restoration_info[
                    "hard_support_joint_hit_restoration_attempted"
                ] = True
                (
                    restored_qpos,
                    restoration_success,
                    restoration_message,
                    restoration_iterations,
                    attempted_restoration_info,
                ) = self._restore_hard_support_joint_hit_constraints(
                    data=data,
                    candidate_qpos=current_qpos,
                    selected_stance_points=selected_stance_points,
                    reference_stance_positions=reference_stance_positions,
                    reference_stance_rotations=reference_stance_rotations,
                    support_region=support_region,
                    reference_contact_world=reference_contact_world,
                    reference_contact_relative_to_com=(
                        reference_contact_relative_to_com
                    ),
                    contact_body_id=contact_body_id,
                    contact_point_local=contact_point_local,
                    retreat_normal=retreat_normal,
                    kinematic_dofs=kinematic_dofs,
                    physical_lower=physical_lower,
                    physical_upper=physical_upper,
                    optimization_pair_indices=optimization_pair_indices,
                    collision_target_distances=(
                        collision_target_distances or {}
                    ),
                    regularizer_kinematic=(
                        round_solutions[-1].restoration_regularizer
                    ),
                    qp_workspace=qp_workspace_holder[0],
                )
                restoration_info.update(attempted_restoration_info)
                if restoration_success:
                    current_qpos = restored_qpos
            restoration_info.update(
                {
                    "hard_support_joint_hit_restoration_success": (
                        restoration_success
                    ),
                    "hard_support_joint_hit_restoration_message": (
                        restoration_message
                    ),
                }
            )

        projection_info: dict[str, float | int | bool | str] = {
            "hard_support_stance_projection_iterations_requested": (
                self.config.hard_support_stance_projection_iterations
            ),
            "hard_support_stance_projection_iterations_completed": 0,
            "hard_support_stance_projection_max_correction": 0.0,
        }
        if completed == rounds and self.config.hard_support_stance_projection_iterations:
            final_qpos, projection_info = self._project_hard_support_stance_frames(
                data=data,
                qpos=current_qpos,
                selected_stance_points=selected_stance_points,
                reference_stance_positions=reference_stance_positions,
                reference_stance_rotations=reference_stance_rotations,
                kinematic_dofs=kinematic_dofs,
                physical_lower=physical_lower,
                physical_upper=physical_upper,
                iterations=self.config.hard_support_stance_projection_iterations,
            )
            current_qpos = final_qpos
        if completed == 0:
            final = first
            final_qpos = qpos0
        else:
            # The loop stops at the first failure.  current_qpos therefore
            # always contains the last successfully accepted nonlinear pose.
            final = round_solutions[completed - 1]
            final_qpos = current_qpos
        if restoration_enabled and not restoration_success:
            # Fail closed: never publish the un-restored task pose as a
            # successful reflex or as an implicit fallback.
            final_qpos = qpos0

        final_total_delta = np.zeros(self.model.nv, dtype=np.float64)
        mujoco.mj_differentiatePos(
            self.model,
            final_total_delta,
            1.0,
            qpos0,
            final_qpos,
        )
        info = dict(final.info)
        info.update(
            {
                "hard_support_qp_rounds_requested": rounds,
                "hard_support_qp_rounds_completed": completed,
                "hard_support_joint_trust_region": trust_radius,
                **projection_info,
                **restoration_info,
                **static_support_availability,
            }
        )
        for index, solution in enumerate(round_solutions, start=1):
            info[f"hard_support_round_{index}_success"] = solution.success
            info[f"hard_support_round_{index}_iterations"] = solution.num_iterations
            info[f"hard_support_round_{index}_proxqp_solve_time_ms"] = float(
                solution.info.get("proxqp_solve_time_ms", 0.0)
            )
            info[f"hard_support_round_{index}_joint_correction_max"] = float(
                solution.info.get("hard_support_round_joint_correction_max", 0.0)
            )
        for round_index in range(len(round_solutions) + 1, rounds + 1):
            info[f"hard_support_round_{round_index}_success"] = False

        fallback = bool(round_solutions and not round_solutions[-1].success)
        if restoration_enabled:
            if restoration_success:
                message = f"{final.message}; joint/hit restoration solved"
            else:
                message = (
                    f"{final.message}; joint/hit restoration failed: "
                    f"{restoration_message}; returned q0"
                )
        else:
            message = (
                f"{final.message}; round {completed + 1} failed, "
                f"returned round {completed}"
                if fallback
                else final.message
            )
        return replace(
            final,
            q_joint_target=final_qpos[self.joint_qpos_addr].copy(),
            base_delta=final_total_delta[base_dofs].copy(),
            success=bool(
                final.success
                and (
                    not restoration_enabled
                    or (completed == rounds and restoration_success)
                )
            ),
            message=message,
            num_iterations=(
                sum(solution.num_iterations for solution in round_solutions)
                + restoration_iterations
            ),
            info=info,
        )

    def _validate_hard_support_balance_pose(
        self,
        data: mujoco.MjData,
        support_region: FrozenSupportRegion | None,
    ) -> tuple[bool, dict[str, float | int | bool | str]]:
        """Validate the current exact physical CoM against one frozen region."""

        if support_region is None:
            return True, {
                "hard_support_balance_constraint_enabled": False,
                "hard_support_balance_constraint_applied": False,
            }
        physical_com = compute_weighted_com(
            data.xipos,
            self.model.body_mass,
            self.robot_body_ids,
        )
        margins = support_region.margins(physical_com)
        violation = support_region.max_violation(physical_com)
        return (
            violation <= SUPPORT_REGION_VALIDATION_TOLERANCE_M,
            {
                "hard_support_balance_constraint_enabled": True,
                "hard_support_balance_constraint_applied": True,
                "hard_support_balance_final_min_margin_m": float(
                    np.min(margins)
                ),
                "hard_support_balance_nonlinear_max_violation_m": violation,
                "hard_support_balance_validation_tolerance_m": (
                    SUPPORT_REGION_VALIDATION_TOLERANCE_M
                ),
                "hard_support_nonlinear_validation_in_required_compute": True,
            },
        )

    def _restore_hard_support_joint_hit_constraints(
        self,
        *,
        data: mujoco.MjData,
        candidate_qpos: np.ndarray,
        selected_stance_points: tuple[ResolvedStancePoint, ...],
        reference_stance_positions: dict[str, np.ndarray],
        reference_stance_rotations: dict[str, np.ndarray],
        support_region: FrozenSupportRegion | None,
        reference_contact_world: np.ndarray,
        reference_contact_relative_to_com: np.ndarray,
        contact_body_id: int,
        contact_point_local: np.ndarray,
        retreat_normal: np.ndarray,
        kinematic_dofs: np.ndarray,
        physical_lower: np.ndarray,
        physical_upper: np.ndarray,
        optimization_pair_indices: list[tuple[int, int]],
        collision_target_distances: dict[tuple[int, int], float],
        regularizer_kinematic: np.ndarray,
        qp_workspace: DenseProxQPWorkspace,
    ) -> tuple[
        np.ndarray,
        bool,
        str,
        int,
        dict[str, float | int | bool | str],
    ]:
        """Restore final nonlinear feasibility without re-running the task.

        The task pose determines two scalar invariants: world-normal struck
        point displacement and CoM-relative-normal struck point displacement.
        The restoration correction fixes the already-selected 6D stance
        frames while preserving both invariants to first order.  Fresh
        final-pose Jacobians are used for every row.
        """

        restoration_start = time.perf_counter()
        candidate = np.asarray(candidate_qpos, dtype=np.float64).copy()
        if regularizer_kinematic.shape != (
            len(kinematic_dofs),
            len(kinematic_dofs),
        ):
            return candidate, False, "missing final task metric", 0, {
                "hard_support_joint_hit_restoration_time_ms": (
                    (time.perf_counter() - restoration_start) * 1000.0
                )
            }

        self._set_qpos(data, candidate)
        candidate_com = compute_weighted_com(
            data.xipos,
            self.model.body_mass,
            self.robot_body_ids,
        )
        candidate_contact_world = contact_point_world(
            data,
            contact_body_id,
            contact_point_local,
        )
        candidate_contact_relative = candidate_contact_world - candidate_com
        achieved_world_retreat = float(
            retreat_normal @ (candidate_contact_world - reference_contact_world)
        )
        achieved_local_retreat = float(
            retreat_normal
            @ (
                candidate_contact_relative
                - reference_contact_relative_to_com
            )
        )

        support_residual = stance_frame_residual_vector(
            data,
            selected_stance_points,
            reference_stance_positions,
            reference_stance_rotations,
        )
        support_jacobian = self._point_support_jacobian(
            data,
            selected_stance_points,
            kinematic_dofs,
        )
        support_basis, support_target, support_rank = independent_equality_system(
            support_jacobian,
            -support_residual,
        )
        if support_rank != qp_workspace.n_equality:
            elapsed = (time.perf_counter() - restoration_start) * 1000.0
            return candidate, False, (
                "stance equality rank changed from "
                f"{qp_workspace.n_equality} to {support_rank}"
            ), 0, {
                "hard_support_joint_hit_restoration_time_ms": elapsed,
                "hard_support_joint_hit_restoration_support_rank": support_rank,
                "hard_support_joint_hit_restoration_expected_support_rank": (
                    qp_workspace.n_equality
                ),
            }

        world_com_jacobian = self._physical_com_jacobian_full(data)[
            :, kinematic_dofs
        ]
        contact_jacobian = self._point_jacobian_full(
            data,
            contact_body_id,
            contact_point_local,
        )[:, kinematic_dofs]
        world_hit_row = (retreat_normal @ contact_jacobian).reshape(1, -1)
        local_hit_row = (
            retreat_normal @ (contact_jacobian - world_com_jacobian)
        ).reshape(1, -1)

        (
            collision_jacobian,
            collision_lower,
            active_collision_pair_indices,
            restored_collision_targets,
        ) = self._linearized_collision_constraints(
            data,
            optimization_pair_indices,
            dof_indices=kinematic_dofs,
            target_distances=collision_target_distances,
        )
        inequality_jacobian = collision_jacobian
        inequality_lower = collision_lower
        inequality_upper = np.full(
            collision_lower.shape,
            np.inf,
            dtype=np.float64,
        )
        if support_region is not None:
            (
                balance_jacobian,
                balance_lower,
                _,
            ) = support_region.linearized_constraints(
                candidate_com,
                world_com_jacobian,
            )
            inequality_jacobian = np.vstack(
                (inequality_jacobian, balance_jacobian)
            )
            inequality_lower = np.concatenate(
                (inequality_lower, balance_lower)
            )
            inequality_upper = np.concatenate(
                (
                    inequality_upper,
                    np.full(support_region.edge_count, np.inf, dtype=np.float64),
                )
            )
        if self.config.min_retreat_distance is not None:
            # The workspace contains the original hard-retreat row.  The two
            # preservation equalities below already keep its achieved value,
            # so retain only the dimension here and deactivate the duplicate.
            inequality_jacobian = np.vstack(
                (
                    inequality_jacobian,
                    np.zeros((1, len(kinematic_dofs)), dtype=np.float64),
                )
            )
            inequality_lower = np.concatenate((inequality_lower, [-np.inf]))
            inequality_upper = np.concatenate((inequality_upper, [np.inf]))
        inequality_jacobian = np.vstack(
            (inequality_jacobian, world_hit_row, local_hit_row)
        )
        inequality_lower = np.concatenate((inequality_lower, [0.0, 0.0]))
        inequality_upper = np.concatenate((inequality_upper, [0.0, 0.0]))

        current_joint = candidate[self.joint_qpos_addr]
        correction_lower = np.concatenate(
            (
                np.full(6, -np.inf, dtype=np.float64),
                physical_lower - current_joint,
            )
        )
        correction_upper = np.concatenate(
            (
                np.full(6, np.inf, dtype=np.float64),
                physical_upper - current_joint,
            )
        )
        try:
            (
                correction,
                optimizer_success,
                optimizer_message,
                optimizer_iterations,
                solver_info,
                _,
            ) = qp_workspace.solve(
                regularizer=regularizer_kinematic,
                linear_term=np.zeros(len(kinematic_dofs), dtype=np.float64),
                lower=correction_lower,
                upper=correction_upper,
                inequality_jacobian=inequality_jacobian,
                inequality_lower=inequality_lower,
                inequality_upper=inequality_upper,
                equality_jacobian=support_basis,
                equality_target=support_target,
            )
        except (ValueError, RuntimeError) as exc:
            elapsed = (time.perf_counter() - restoration_start) * 1000.0
            return candidate, False, str(exc), 0, {
                "hard_support_joint_hit_restoration_time_ms": elapsed,
                "hard_support_joint_hit_restoration_support_rank": support_rank,
            }

        restored = candidate.copy()
        tangent = np.zeros(self.model.nv, dtype=np.float64)
        tangent[kinematic_dofs] = correction
        mujoco.mj_integratePos(self.model, restored, tangent, 1.0)
        mujoco.mj_normalizeQuat(self.model, restored)
        self._set_qpos(data, restored)

        stance_position_error = max_stance_point_displacement(
            data,
            selected_stance_points,
            reference_stance_positions,
        )
        stance_rotation_error = max_stance_frame_rotation(
            data,
            selected_stance_points,
            reference_stance_rotations,
        )
        restored_com = compute_weighted_com(
            data.xipos,
            self.model.body_mass,
            self.robot_body_ids,
        )
        restored_contact_world = contact_point_world(
            data,
            contact_body_id,
            contact_point_local,
        )
        restored_contact_relative = restored_contact_world - restored_com
        if support_region is None:
            balance_margins = np.empty(0, dtype=np.float64)
            balance_violation = 0.0
            balance_min_margin = 0.0
        else:
            balance_margins = support_region.margins(restored_com)
            balance_violation = support_region.max_violation(restored_com)
            balance_min_margin = float(np.min(balance_margins))
        restored_world_retreat = float(
            retreat_normal @ (restored_contact_world - reference_contact_world)
        )
        restored_local_retreat = float(
            retreat_normal
            @ (
                restored_contact_relative
                - reference_contact_relative_to_com
            )
        )
        world_retreat_drift = abs(
            restored_world_retreat - achieved_world_retreat
        )
        local_retreat_drift = abs(
            restored_local_retreat - achieved_local_retreat
        )

        final_distances = self.self_collision_model.distance_map(
            data,
            pair_indices=active_collision_pair_indices,
        )
        collision_violation = max(
            (
                max(0.0, target - final_distances[pair])
                for pair, target in restored_collision_targets.items()
            ),
            default=0.0,
        )
        restored_joint = restored[self.joint_qpos_addr]
        joint_limit_violation = float(
            max(
                np.max(physical_lower - restored_joint, initial=0.0),
                np.max(restored_joint - physical_upper, initial=0.0),
                0.0,
            )
        )
        validation_success = bool(
            stance_position_error <= RESTORATION_STANCE_POSITION_TOLERANCE_M
            and stance_rotation_error
            <= RESTORATION_STANCE_ROTATION_TOLERANCE_RAD
            and world_retreat_drift
            <= RESTORATION_RETREAT_DRIFT_TOLERANCE_M
            and local_retreat_drift
            <= RESTORATION_RETREAT_DRIFT_TOLERANCE_M
            and collision_violation
            <= RESTORATION_COLLISION_VIOLATION_TOLERANCE_M
            and joint_limit_violation
            <= RESTORATION_JOINT_LIMIT_TOLERANCE_RAD
            and balance_violation <= SUPPORT_REGION_VALIDATION_TOLERANCE_M
        )
        success = bool(optimizer_success and validation_success)
        elapsed = (time.perf_counter() - restoration_start) * 1000.0
        info: dict[str, float | int | bool | str] = {
            **solver_info,
            "hard_support_joint_hit_restoration_time_ms": elapsed,
            "hard_support_joint_hit_restoration_support_rank": support_rank,
            "hard_support_joint_hit_restoration_correction_norm": float(
                np.linalg.norm(correction)
            ),
            "hard_support_joint_hit_restoration_joint_correction_max": float(
                np.max(np.abs(correction[6:]), initial=0.0)
            ),
            "hard_support_joint_hit_restoration_achieved_world_retreat": (
                achieved_world_retreat
            ),
            "hard_support_joint_hit_restoration_achieved_local_retreat": (
                achieved_local_retreat
            ),
            "hard_support_joint_hit_restoration_final_world_retreat": (
                restored_world_retreat
            ),
            "hard_support_joint_hit_restoration_final_local_retreat": (
                restored_local_retreat
            ),
            "hard_support_joint_hit_restoration_world_retreat_drift": (
                world_retreat_drift
            ),
            "hard_support_joint_hit_restoration_local_retreat_drift": (
                local_retreat_drift
            ),
            "hard_support_joint_hit_restoration_stance_position_error": (
                stance_position_error
            ),
            "hard_support_joint_hit_restoration_stance_rotation_error": (
                stance_rotation_error
            ),
            "hard_support_joint_hit_restoration_collision_violation": (
                collision_violation
            ),
            "hard_support_joint_hit_restoration_joint_limit_violation": (
                joint_limit_violation
            ),
            "hard_support_joint_hit_restoration_balance_min_margin_m": (
                balance_min_margin
            ),
            "hard_support_joint_hit_restoration_balance_violation_m": (
                balance_violation
            ),
            "hard_support_nonlinear_validation_in_required_compute": True,
            "hard_collision_nonlinear_max_violation": collision_violation,
        }
        if success:
            message = optimizer_message
        elif not optimizer_success:
            message = f"ProxQP failed: {optimizer_message}"
        else:
            message = (
                "final nonlinear validation failed: "
                f"stance={stance_position_error:.3e} m/"
                f"{math.degrees(stance_rotation_error):.3e} deg, "
                f"retreat drift={world_retreat_drift:.3e}/"
                f"{local_retreat_drift:.3e} m, collision="
                f"{collision_violation:.3e} m, joint="
                f"{joint_limit_violation:.3e} rad, balance="
                f"{balance_violation:.3e} m"
            )
        return restored, success, message, optimizer_iterations, info

    def _project_hard_support_stance_frames(
        self,
        data: mujoco.MjData,
        qpos: np.ndarray,
        selected_stance_points: tuple[ResolvedStancePoint, ...],
        reference_stance_positions: dict[str, np.ndarray],
        reference_stance_rotations: dict[str, np.ndarray],
        kinematic_dofs: np.ndarray,
        physical_lower: np.ndarray,
        physical_upper: np.ndarray,
        iterations: int,
    ) -> tuple[np.ndarray, dict[str, float | int | bool | str]]:
        """Project a candidate onto the existing nonlinear 6D stance manifold.

        This is a feasibility restoration step, not another task objective.  At
        each iteration the minimum-norm tangent correction solves the compressed
        stance equality exactly, then MuJoCo integrates it on the configuration
        manifold.  The correction is fail-closed if it would cross a physical
        joint limit.
        """

        projected = np.asarray(qpos, dtype=np.float64).copy()
        completed = 0
        max_correction = 0.0
        initial_residual = 0.0
        final_residual = 0.0
        for projection_index in range(iterations):
            self._set_qpos(data, projected)
            residual = stance_frame_residual_vector(
                data,
                selected_stance_points,
                reference_stance_positions,
                reference_stance_rotations,
            )
            residual_norm = float(np.max(np.abs(residual), initial=0.0))
            if projection_index == 0:
                initial_residual = residual_norm
            final_residual = residual_norm
            if residual_norm <= 1.0e-10:
                break

            support_jacobian = self._point_support_jacobian(
                data,
                selected_stance_points,
                kinematic_dofs,
            )
            support_basis, support_target, _ = independent_equality_system(
                support_jacobian,
                -residual,
            )
            # independent_equality_system returns orthonormal rows, so this is
            # the minimum Euclidean-norm solution of basis @ dz = target.
            delta_kinematic = support_basis.T @ support_target
            max_correction = max(
                max_correction,
                float(np.max(np.abs(delta_kinematic), initial=0.0)),
            )
            tangent = np.zeros(self.model.nv, dtype=np.float64)
            tangent[kinematic_dofs] = delta_kinematic
            candidate = projected.copy()
            mujoco.mj_integratePos(self.model, candidate, tangent, 1.0)
            candidate_joint = candidate[self.joint_qpos_addr]
            if np.any(candidate_joint < physical_lower - 1.0e-10) or np.any(
                candidate_joint > physical_upper + 1.0e-10
            ):
                break
            projected = candidate
            completed += 1

        self._set_qpos(data, projected)
        final_residual_vector = stance_frame_residual_vector(
            data,
            selected_stance_points,
            reference_stance_positions,
            reference_stance_rotations,
        )
        final_residual = float(
            np.max(np.abs(final_residual_vector), initial=0.0)
        )
        return projected, {
            "hard_support_stance_projection_iterations_requested": iterations,
            "hard_support_stance_projection_iterations_completed": completed,
            "hard_support_stance_projection_initial_residual": initial_residual,
            "hard_support_stance_projection_final_residual": final_residual,
            "hard_support_stance_projection_max_correction": max_correction,
        }

    def _solve_hard_support_qp_round(
        self,
        data: mujoco.MjData,
        q0_joint: np.ndarray,
        current_qpos: np.ndarray,
        accumulated_delta: np.ndarray,
        reference_inertia: np.ndarray,
        body_energy_model: HardSupportBodyEnergyModel,
        absolute_regularizer: np.ndarray,
        static_support_effort_model: StaticSupportEffortModel | None,
        angular_motion_model: AngularMotionModel | None,
        reference_com: np.ndarray,
        reference_contact_world: np.ndarray,
        reference_contact_relative_to_com: np.ndarray,
        reference_stance_positions: dict[str, np.ndarray],
        reference_stance_rotations: dict[str, np.ndarray],
        support_region: FrozenSupportRegion | None,
        contact_body_id: int,
        contact_point_local: np.ndarray,
        retreat_normal: np.ndarray,
        selected_stance_points: tuple[ResolvedStancePoint, ...],
        correction_lower: np.ndarray,
        correction_upper: np.ndarray,
        optimization_pair_indices: list[tuple[int, int]],
        collision_target_distances: dict[tuple[int, int], float] | None,
        round_index: int,
        qp_workspace_holder: list[DenseProxQPWorkspace] | None = None,
        minimal_report: bool = False,
        precomputed_solver_result: HardSupportQPSolverReplay | None = None,
        solver_replay_holder: list[HardSupportQPSolverReplay] | None = None,
    ) -> LinearizedQPSolution:
        """Solve a floating-base QP with selected surface frames fixed in 6D.

        Each selected visual-surface point defines an attached body frame: its
        origin is the point offset and its orientation is the owning body's
        orientation.  Both translational and angular first-order motion are
        fixed.  No virtual stance mass is added.
        """

        if not selected_stance_points:
            raise ValueError("Hard-support reflex modes require at least one selected stance point")

        base_dofs = self._base_dofs
        kinematic_dofs = self._kinematic_dofs
        n_kinematic = len(kinematic_dofs)

        if accumulated_delta.shape != (n_kinematic,):
            raise ValueError("accumulated_delta has an incompatible shape")
        current_joint = current_qpos[self.joint_qpos_addr].copy()
        current_com = compute_weighted_com(
            data.xipos,
            self.model.body_mass,
            self.robot_body_ids,
        )
        current_com_displacement = current_com - reference_com
        current_contact_world = contact_point_world(
            data, contact_body_id, contact_point_local
        )
        current_contact_relative_to_com = current_contact_world - current_com
        current_world_contact_displacement = (
            current_contact_world - reference_contact_world
        )
        current_com_relative_retreat = float(
            retreat_normal
            @ (
                current_contact_relative_to_com
                - reference_contact_relative_to_com
            )
        )
        current_world_retreat = float(
            retreat_normal @ current_world_contact_displacement
        )

        world_com_jacobian_full = self._physical_com_jacobian_full(data)
        world_com_jacobian = world_com_jacobian_full[:, kinematic_dofs]

        j_contact_full = self._point_jacobian_full(
            data,
            contact_body_id,
            contact_point_local,
        )
        j_contact = j_contact_full[:, kinematic_dofs]
        # Canonical retreat is local deformation of the struck point relative
        # to the physical CoM.  J_contact alone would let floating-base motion
        # masquerade as a reflex and induce compensating support-chain motion.
        j_contact_relative_to_com = j_contact - world_com_jacobian
        if (
            self.config.hard_support_retreat_reference_frame
            == RETREAT_REFERENCE_CONTACT_WORLD
        ):
            current_retreat = current_world_retreat
            retreat_jacobian_kinematic = j_contact
        else:
            current_retreat = current_com_relative_retreat
            retreat_jacobian_kinematic = j_contact_relative_to_com

        regularizer_kinematic = absolute_regularizer.copy()
        if self.config.w_world_com > 0.0:
            regularizer_kinematic += self.config.w_world_com * (
                world_com_jacobian.T @ world_com_jacobian
            )

        hard_retreat = self.config.min_retreat_distance is not None
        retreat_linear = (
            np.zeros(n_kinematic, dtype=np.float64)
            if hard_retreat
            else self.config.w_retreat
            * (retreat_jacobian_kinematic.T @ retreat_normal)
        )
        contact_mask = self._ancestor_joint_mask(contact_body_id)
        if self.config.non_contact_joint_scale < 1.0:
            non_contact_indices = 6 + np.flatnonzero(~contact_mask)
            retreat_linear[non_contact_indices] *= self.config.non_contact_joint_scale

        # The second QP optimizes the same absolute objective as round one.
        # Its variable is only a correction around current_qpos, so expand all
        # q-vs-q0 terms and move their linear cross terms into ProxQP's l vector.
        linear_kinematic = retreat_linear - 2.0 * (
            absolute_regularizer @ accumulated_delta
        )
        if self.config.w_world_com > 0.0:
            linear_kinematic -= 2.0 * self.config.w_world_com * (
                world_com_jacobian.T @ current_com_displacement
            )
        if static_support_effort_model is not None:
            linear_kinematic -= (
                static_support_effort_model.objective_linear_offset
            )
        world_cone_model = None
        if self.config.w_world_retreat_cone > 0:
            world_cone_model = retreat_cone_model(
                current_world_contact_displacement, retreat_normal,
                self.config.world_retreat_cone_ratio,
            )
            _, cone_gradient, cone_half_hessian = world_cone_model
            regularizer_kinematic += self.config.w_world_retreat_cone * (
                j_contact.T @ cone_half_hessian @ j_contact
            )
            linear_kinematic -= self.config.w_world_retreat_cone * (j_contact.T @ cone_gradient)
        lower_kinematic = np.concatenate(
            (np.full(6, -np.inf), correction_lower)
        )
        upper_kinematic = np.concatenate(
            (np.full(6, np.inf), correction_upper)
        )

        impulse_enabled = (
            self.config.reflex_mode == REFLEX_MODE_HARD_SUPPORT_MIN_IMPULSE
        )
        # Preserve the historical one-round result-info contract exactly.
        # Multi-round production timing may skip these report-only quantities
        # when diagnostics are explicitly disabled.
        needs_centroidal_diagnostics = bool(
            self.config.collect_diagnostics
            or self.config.hard_support_qp_rounds == 1
        )
        if impulse_enabled or needs_centroidal_diagnostics:
            support_jacobian, support_grasp, centroidal_matrix = (
                self._point_support_and_centroidal_matrices(
                    data,
                    selected_stance_points,
                    kinematic_dofs,
                )
            )
        else:
            # Ordinary hard-support QPs use only the attached-frame Jacobian.
            # Building grasp/centroidal matrices here changes no objective or
            # constraint and is avoidable overhead in every SQP round.
            support_jacobian = self._point_support_jacobian(
                data,
                selected_stance_points,
                kinematic_dofs,
            )
            support_grasp = np.empty((6, 0), dtype=np.float64)
            centroidal_matrix = np.empty((6, n_kinematic), dtype=np.float64)
        support_residual_vector = stance_frame_residual_vector(
            data,
            selected_stance_points,
            reference_stance_positions,
            reference_stance_rotations,
        )
        if self.config.hard_support_stance_constraints_enabled:
            support_basis, support_target, support_rank = independent_equality_system(
                support_jacobian,
                -support_residual_vector,
            )
        else:
            support_basis = np.empty((0, n_kinematic), dtype=np.float64)
            support_target = np.empty(0, dtype=np.float64)
            support_rank = 0
        support_count = len(selected_stance_points)
        n_impulse = 3 * support_count if impulse_enabled else 0
        n_variable = n_kinematic + n_impulse

        if n_impulse == 0:
            regularizer = regularizer_kinematic.copy()
            linear_term = linear_kinematic.copy()
            lower_variable = lower_kinematic.copy()
            upper_variable = upper_kinematic.copy()
            equality_jacobian = support_basis.copy()
        else:
            regularizer = np.zeros((n_variable, n_variable), dtype=np.float64)
            regularizer[:n_kinematic, :n_kinematic] = regularizer_kinematic
            regularizer[n_kinematic:, n_kinematic:] = (
                self.config.w_support_impulse * np.eye(n_impulse)
            )
            linear_term = np.zeros(n_variable, dtype=np.float64)
            linear_term[:n_kinematic] = linear_kinematic
            lower_variable = np.concatenate(
                (lower_kinematic, np.full(n_impulse, -np.inf))
            )
            upper_variable = np.concatenate(
                (upper_kinematic, np.full(n_impulse, np.inf))
            )
            equality_jacobian = np.hstack(
                (
                    support_basis,
                    np.zeros((support_rank, n_impulse), dtype=np.float64),
                )
            )
        equality_target = support_target
        if impulse_enabled:
            momentum_equality = np.hstack(
                (
                    centroidal_matrix / self.config.support_impulse_dt,
                    -support_grasp,
                )
            )
            equality_jacobian = np.vstack((equality_jacobian, momentum_equality))
            equality_target = np.concatenate(
                (
                    equality_target,
                    -centroidal_matrix
                    @ accumulated_delta
                    / self.config.support_impulse_dt,
                )
            )

        (
            collision_jacobian_kinematic,
            collision_lower,
            active_collision_pair_indices,
            hard_collision_targets,
        ) = self._linearized_collision_constraints(
            data,
            optimization_pair_indices,
            dof_indices=kinematic_dofs,
            target_distances=collision_target_distances,
        )
        collision_jacobian = (
            collision_jacobian_kinematic.copy()
            if n_impulse == 0
            else np.hstack(
                (
                    collision_jacobian_kinematic,
                    np.zeros(
                        (collision_jacobian_kinematic.shape[0], n_impulse),
                        dtype=np.float64,
                    ),
                )
            )
        )
        qp_jacobian = collision_jacobian
        qp_lower = collision_lower
        qp_upper = np.full(collision_lower.shape, np.inf, dtype=np.float64)
        if support_region is None:
            balance_jacobian_kinematic = np.empty(
                (0, n_kinematic), dtype=np.float64
            )
            balance_current_margins = np.empty(0, dtype=np.float64)
            balance_lower = np.empty(0, dtype=np.float64)
            balance_row_norms = np.empty(0, dtype=np.float64)
        else:
            (
                balance_jacobian_kinematic,
                balance_lower,
                balance_current_margins,
            ) = support_region.linearized_constraints(
                current_com,
                world_com_jacobian,
            )
            balance_jacobian = np.hstack(
                (
                    balance_jacobian_kinematic,
                    np.zeros(
                        (support_region.edge_count, n_impulse),
                        dtype=np.float64,
                    ),
                )
            )
            balance_row_norms = np.linalg.norm(
                balance_jacobian_kinematic,
                axis=1,
            )
            qp_jacobian = np.vstack((qp_jacobian, balance_jacobian))
            qp_lower = np.concatenate((qp_lower, balance_lower))
            qp_upper = np.concatenate(
                (
                    qp_upper,
                    np.full(support_region.edge_count, np.inf, dtype=np.float64),
                )
            )
        if hard_retreat:
            retreat_jacobian = np.zeros((1, n_variable), dtype=np.float64)
            retreat_jacobian[0, :n_kinematic] = (
                retreat_normal @ retreat_jacobian_kinematic
            )
            qp_jacobian = np.vstack((qp_jacobian, retreat_jacobian))
            qp_lower = np.concatenate(
                (
                    qp_lower,
                    [self.config.min_retreat_distance - current_retreat],
                )
            )
            qp_upper = np.concatenate((qp_upper, [np.inf]))

        retreat_shortfall_enabled = self.config.w_retreat_shortfall > 0
        if retreat_shortfall_enabled:
            # Epigraph: min w_s*s^2, s>=0, r_linearized+s>=d_preferred.
            # Add one scalar after the unchanged kinematic/constraint assembly.
            # There is no hard retreat minimum and no reward beyond preference.
            augmented = np.zeros((n_variable + 1, n_variable + 1), dtype=np.float64)
            augmented[:n_variable, :n_variable] = regularizer
            augmented[-1, -1] = self.config.w_retreat_shortfall
            regularizer = augmented
            linear_term = np.concatenate((linear_term, [0.0]))
            lower_variable = np.concatenate((lower_variable, [0.0]))
            upper_variable = np.concatenate((upper_variable, [np.inf]))
            equality_jacobian = np.column_stack((equality_jacobian, np.zeros(equality_jacobian.shape[0])))
            qp_jacobian = np.column_stack((qp_jacobian, np.zeros(qp_jacobian.shape[0])))
            n_variable += 1
            shortfall_row = np.zeros((1, n_variable), dtype=np.float64)
            shortfall_row[0, :n_kinematic] = retreat_jacobian_kinematic.T @ retreat_normal
            shortfall_row[0, -1] = 1.0
            qp_jacobian = np.vstack((qp_jacobian, shortfall_row))
            qp_lower = np.concatenate((qp_lower, [self.config.preferred_retreat_distance - current_retreat]))
            qp_upper = np.concatenate((qp_upper, [np.inf]))

        if qp_workspace_holder is not None:
            # Keep two rows reserved across both task rounds.  They become the
            # exact achieved-world and achieved-local retreat preservation
            # rows only in the final feasibility restoration update.
            qp_jacobian = np.vstack(
                (
                    qp_jacobian,
                    np.zeros((2, n_variable), dtype=np.float64),
                )
            )
            qp_lower = np.concatenate((qp_lower, [-np.inf, -np.inf]))
            qp_upper = np.concatenate((qp_upper, [np.inf, np.inf]))

        if precomputed_solver_result is not None:
            if qp_workspace_holder is not None:
                raise ValueError(
                    "A deferred report cannot reuse a mutable ProxQP workspace"
                )
            variable = precomputed_solver_result.variable
            optimizer_success = precomputed_solver_result.success
            message = precomputed_solver_result.message
            num_iterations = precomputed_solver_result.num_iterations
            solver_info = dict(precomputed_solver_result.solver_info)
            inequality_duals = precomputed_solver_result.inequality_duals
        elif qp_workspace_holder is None:
            (
                variable,
                optimizer_success,
                message,
                num_iterations,
                solver_info,
                inequality_duals,
            ) = solve_box_collision_qp_proxqp(
                regularizer=regularizer,
                linear_term=linear_term,
                lower=lower_variable,
                upper=upper_variable,
                collision_jacobian=qp_jacobian,
                collision_lower=qp_lower,
                eps_abs=self.config.proxqp_eps_abs,
                eps_rel=self.config.proxqp_eps_rel,
                max_iterations=self.config.proxqp_max_iter,
                equality_jacobian=equality_jacobian,
                equality_target=equality_target,
            )
        else:
            if not qp_workspace_holder:
                qp_workspace_holder.append(
                    DenseProxQPWorkspace(
                        n_variable=n_variable,
                        n_equality=equality_jacobian.shape[0],
                        n_inequality=qp_jacobian.shape[0],
                        eps_abs=self.config.proxqp_eps_abs,
                        eps_rel=self.config.proxqp_eps_rel,
                        max_iterations=self.config.proxqp_max_iter,
                    )
                )
            workspace = qp_workspace_holder[0]
            try:
                (
                    variable,
                    optimizer_success,
                    message,
                    num_iterations,
                    solver_info,
                    inequality_duals,
                ) = workspace.solve(
                    regularizer=regularizer,
                    linear_term=linear_term,
                    lower=lower_variable,
                    upper=upper_variable,
                    inequality_jacobian=qp_jacobian,
                    inequality_lower=qp_lower,
                    inequality_upper=qp_upper,
                    equality_jacobian=equality_jacobian,
                    equality_target=equality_target,
                )
            except (ValueError, RuntimeError) as exc:
                variable = np.zeros(n_variable, dtype=np.float64)
                optimizer_success = False
                message = str(exc)
                num_iterations = 0
                solver_info = {
                    "proxqp_status": "workspace_dimension_change",
                    "proxqp_workspace_operation": "rejected_update",
                    "proxqp_workspace_init_count": workspace.init_count,
                    "proxqp_workspace_update_count": workspace.update_count,
                    "proxqp_solve_time_ms": 0.0,
                    "hard_collision_linear_max_violation": float("inf"),
                    "equality_constraint_count": int(
                        equality_jacobian.shape[0]
                    ),
                    "equality_linear_max_violation": float("inf"),
                }
                inequality_duals = np.zeros(
                    qp_jacobian.shape[0],
                    dtype=np.float64,
                )
        delta_z = variable[:n_kinematic].copy()
        q_joint_target = np.clip(
            current_joint + delta_z[6:],
            current_joint + correction_lower,
            current_joint + correction_upper,
        )
        delta_z[6:] = q_joint_target - current_joint
        if impulse_enabled:
            support_impulse = variable[n_kinematic:].reshape(support_count, 3).copy()
        else:
            support_impulse = np.empty((0, 3), dtype=np.float64)

        if minimal_report:
            if solver_replay_holder is None:
                raise ValueError(
                    "A minimal hard-support report requires a replay holder"
                )
            if solver_replay_holder:
                raise ValueError("The solver replay holder must start empty")
            solver_replay_holder.append(
                HardSupportQPSolverReplay(
                    variable=variable,
                    success=optimizer_success,
                    message=message,
                    num_iterations=num_iterations,
                    solver_info=solver_info,
                    inequality_duals=inequality_duals,
                )
            )
            collision_constraint_count = collision_jacobian.shape[0]
            minimal_info = dict(solver_info)
            minimal_info.update(
                {
                    "hard_support_qp_round_index": round_index,
                    "hard_support_round_joint_correction_max": float(
                        np.max(np.abs(delta_z[6:]), initial=0.0)
                    ),
                }
            )
            return LinearizedQPSolution(
                q_joint_target=q_joint_target,
                base_delta=delta_z[:6],
                success=optimizer_success,
                message=(
                    f"linearized_qp/proxqp/{self.config.reflex_mode}: "
                    f"{message}"
                ),
                num_iterations=num_iterations,
                objective_value=float("nan"),
                active_collision_pair_indices=active_collision_pair_indices,
                hard_collision_targets=hard_collision_targets,
                hard_collision_slacks=np.empty(0, dtype=np.float64),
                hard_collision_duals=inequality_duals[
                    :collision_constraint_count
                ].copy(),
                support_impulse=support_impulse,
                support_region=support_region,
                info=minimal_info,
            )

        support_twist = (
            support_residual_vector + support_jacobian @ delta_z
        ).reshape(support_count, 6)
        support_position_residual = float(
            np.max(np.abs(support_twist[:, :3]), initial=0.0)
        )
        support_rotation_residual = float(
            np.max(np.abs(support_twist[:, 3:]), initial=0.0)
        )
        support_residual = max(support_position_residual, support_rotation_residual)
        if impulse_enabled or needs_centroidal_diagnostics:
            predicted_momentum = (
                centroidal_matrix
                @ (accumulated_delta + delta_z)
                / self.config.support_impulse_dt
            )
            implied_minimum_impulse = np.linalg.lstsq(
                support_grasp,
                predicted_momentum,
                rcond=None,
            )[0]
            implied_minimum_impulse_norm = float(
                np.linalg.norm(implied_minimum_impulse)
            )
        else:
            predicted_momentum = np.empty(0, dtype=np.float64)
            implied_minimum_impulse_norm = float("nan")
        if impulse_enabled:
            momentum_residual_vector = (
                predicted_momentum - support_grasp @ support_impulse.reshape(-1)
            )
            momentum_residual = float(np.max(np.abs(momentum_residual_vector), initial=0.0))
            impulse_norms = np.linalg.norm(support_impulse, axis=1)
            impulse_norm = float(np.linalg.norm(support_impulse))
            impulse_max_norm = float(np.max(impulse_norms, initial=0.0))
        else:
            momentum_residual = float("nan")
            impulse_norm = 0.0
            impulse_max_norm = 0.0

        total_delta_model = accumulated_delta + delta_z
        total_delta_q = total_delta_model[6:]
        predicted_com_relative_retreat = float(
            current_com_relative_retreat
            + retreat_normal @ j_contact_relative_to_com @ delta_z
        )
        predicted_world_retreat = float(
            current_world_retreat + retreat_normal @ j_contact @ delta_z
        )
        predicted_retreat = (
            predicted_world_retreat
            if self.config.hard_support_retreat_reference_frame
            == RETREAT_REFERENCE_CONTACT_WORLD
            else predicted_com_relative_retreat
        )
        objective_term_retreat_signed = (
            0.0
            if hard_retreat
            else float(-self.config.w_retreat * current_retreat - retreat_linear @ delta_z)
        )
        objective_term_joint_l2 = float(
            np.dot(
                body_energy_model.effective_joint_regularization,
                total_delta_q * total_delta_q,
            )
        )
        objective_term_generalized_inertia = float(
            0.5
            * self.config.w_body
            * (
                total_delta_model
                @ body_energy_model.active_inertia
                @ total_delta_model
            )
        )
        objective_term_removed_generalized_inertia = float(
            0.5
            * self.config.w_body
            * (
                total_delta_model
                @ body_energy_model.removed_inertia
                @ total_delta_model
            )
        )
        objective_term_full_generalized_inertia = float(
            0.5
            * self.config.w_body
            * (total_delta_model @ reference_inertia @ total_delta_model)
        )
        predicted_world_com_delta = (
            current_com_displacement + world_com_jacobian @ delta_z
        )
        predicted_world_contact_delta = (
            current_world_contact_displacement + j_contact @ delta_z
        )
        objective_term_world_com = float(
            self.config.w_world_com
            * np.dot(predicted_world_com_delta, predicted_world_com_delta)
        )
        objective_term_numerical_damping = float(
            self.config.linearized_damping
            * np.dot(total_delta_model, total_delta_model)
        )
        objective_term_support_impulse = float(
            self.config.w_support_impulse
            * np.dot(support_impulse.reshape(-1), support_impulse.reshape(-1))
        )
        objective_term_angular_regularization = (
            0.0
            if angular_motion_model is None
            else float(
                total_delta_model
                @ angular_motion_model.objective_regularizer
                @ total_delta_model
            )
        )
        if static_support_effort_model is None:
            predicted_static_support_effort = 0.0
            objective_term_static_support_effort = 0.0
        else:
            predicted_static_support_load = (
                static_support_effort_model.reference_bias
                + static_support_effort_model.load_jacobian @ total_delta_model
            )
            predicted_static_support_effort = float(
                predicted_static_support_load
                @ static_support_effort_model.effort_metric
                @ predicted_static_support_load
            )
            objective_term_static_support_effort = float(
                self.config.w_static_support_effort
                * predicted_static_support_effort
            )
        objective_positive_total = (
            objective_term_joint_l2
            + objective_term_generalized_inertia
            + objective_term_world_com
            + objective_term_numerical_damping
            + objective_term_support_impulse
            + objective_term_angular_regularization
            + objective_term_static_support_effort
        )
        guided_info = {}
        if retreat_shortfall_enabled:
            shortfall_cost = self.config.w_retreat_shortfall * float(variable[-1])**2
            objective_positive_total += shortfall_cost
            guided_info.update(
                preferred_retreat_distance_m=self.config.preferred_retreat_distance,
                retreat_shortfall_weight=self.config.w_retreat_shortfall,
                objective_term_retreat_shortfall=shortfall_cost,
                retreat_shortfall_slack=float(variable[-1]),
            )
        if world_cone_model is not None:
            cone_cost, cone_gradient, cone_half_hessian = world_cone_model
            contact_correction = j_contact @ delta_z
            cone_model_cost = self.config.w_world_retreat_cone * float(
                cone_cost + cone_gradient @ contact_correction
                + contact_correction @ cone_half_hessian @ contact_correction
            )
            objective_positive_total += cone_model_cost
            guided_info.update(
                world_retreat_cone_weight=self.config.w_world_retreat_cone,
                world_retreat_cone_ratio=self.config.world_retreat_cone_ratio,
                objective_term_world_retreat_cone_model=cone_model_cost,
            )
        objective_reconstructed = objective_positive_total + objective_term_retreat_signed

        angular_diagnostics: dict[str, float | int | bool | str] = {
            "angular_regularization_mode": self.config.angular_regularization_mode,
            "angular_regularization_weight": self.config.w_angular_regularization,
            "objective_term_angular_regularization": (
                objective_term_angular_regularization
            ),
            "angular_motion_characteristic_time_s": 1.0,
        }
        if angular_motion_model is not None:
            angular_momentum = (
                angular_motion_model.angular_momentum_matrix
                @ total_delta_model
            )
            spin_angular_momentum = (
                angular_motion_model.spin_angular_momentum_matrix
                @ total_delta_model
            )
            orbital_angular_momentum = (
                angular_motion_model.orbital_angular_momentum_matrix
                @ total_delta_model
            )
            centroidal_angular_velocity = (
                angular_motion_model.centroidal_angular_velocity_matrix
                @ total_delta_model
            )
            torso_angular_velocity = (
                angular_motion_model.torso_angular_velocity_matrix
                @ total_delta_model
            )
            spin_norm = float(np.linalg.norm(spin_angular_momentum))
            orbital_norm = float(np.linalg.norm(orbital_angular_momentum))
            spin_orbital_cosine = (
                float(
                    np.dot(spin_angular_momentum, orbital_angular_momentum)
                    / (spin_norm * orbital_norm)
                )
                if spin_norm > 1.0e-12 and orbital_norm > 1.0e-12
                else 0.0
            )
            translational_kinetic_metric = float(
                0.5
                * total_delta_model
                @ angular_motion_model.translational_inertia
                @ total_delta_model
            )
            rotational_kinetic_metric = float(
                0.5
                * total_delta_model
                @ angular_motion_model.rotational_inertia
                @ total_delta_model
            )
            generalized_kinetic_metric = float(
                0.5
                * total_delta_model
                @ reference_inertia
                @ total_delta_model
            )
            inertia_decomposition_residual = reference_inertia - (
                angular_motion_model.translational_inertia
                + angular_motion_model.rotational_inertia
            )
            inertia_reference_norm = float(np.linalg.norm(reference_inertia))
            momentum_decomposition_residual = (
                angular_motion_model.angular_momentum_matrix
                - angular_motion_model.spin_angular_momentum_matrix
                - angular_motion_model.orbital_angular_momentum_matrix
            )
            momentum_reference_norm = float(
                np.linalg.norm(angular_motion_model.angular_momentum_matrix)
            )
            centroidal_inertia_eigenvalues = np.linalg.eigvalsh(
                angular_motion_model.centroidal_inertia
            )
            angular_diagnostics.update(
                {
                    "generalized_kinetic_metric": generalized_kinetic_metric,
                    "translational_kinetic_metric": translational_kinetic_metric,
                    "rotational_kinetic_metric": rotational_kinetic_metric,
                    "rotational_kinetic_fraction": (
                        rotational_kinetic_metric / generalized_kinetic_metric
                        if generalized_kinetic_metric > 1.0e-14
                        else 0.0
                    ),
                    "inertia_decomposition_relative_error": float(
                        np.linalg.norm(inertia_decomposition_residual)
                        / max(inertia_reference_norm, 1.0e-14)
                    ),
                    "angular_momentum_decomposition_relative_error": float(
                        np.linalg.norm(momentum_decomposition_residual)
                        / max(momentum_reference_norm, 1.0e-14)
                    ),
                    "centroidal_angular_momentum_x": float(angular_momentum[0]),
                    "centroidal_angular_momentum_y": float(angular_momentum[1]),
                    "centroidal_angular_momentum_z": float(angular_momentum[2]),
                    "centroidal_angular_momentum_norm": float(
                        np.linalg.norm(angular_momentum)
                    ),
                    "spin_angular_momentum_norm": spin_norm,
                    "orbital_angular_momentum_norm": orbital_norm,
                    "spin_orbital_angular_momentum_cosine": spin_orbital_cosine,
                    "centroidal_equivalent_angular_velocity_x": float(
                        centroidal_angular_velocity[0]
                    ),
                    "centroidal_equivalent_angular_velocity_y": float(
                        centroidal_angular_velocity[1]
                    ),
                    "centroidal_equivalent_angular_velocity_z": float(
                        centroidal_angular_velocity[2]
                    ),
                    "centroidal_equivalent_angular_velocity_norm": float(
                        np.linalg.norm(centroidal_angular_velocity)
                    ),
                    "torso_angular_velocity_x": float(torso_angular_velocity[0]),
                    "torso_angular_velocity_y": float(torso_angular_velocity[1]),
                    "torso_angular_velocity_z": float(torso_angular_velocity[2]),
                    "torso_angular_velocity_norm": float(
                        np.linalg.norm(torso_angular_velocity)
                    ),
                    "centroidal_inertia_min_eigenvalue": float(
                        np.min(centroidal_inertia_eigenvalues)
                    ),
                    "centroidal_inertia_max_eigenvalue": float(
                        np.max(centroidal_inertia_eigenvalues)
                    ),
                }
            )

        collision_constraint_count = collision_jacobian.shape[0]
        hard_collision_slacks = collision_jacobian_kinematic @ delta_z - collision_lower
        hard_collision_duals = inequality_duals[:collision_constraint_count]
        if support_region is None:
            balance_predicted_margins = np.empty(0, dtype=np.float64)
            balance_linear_max_violation = 0.0
        else:
            balance_predicted_margins = (
                balance_current_margins
                + balance_jacobian_kinematic @ delta_z
            )
            balance_linear_max_violation = float(
                np.max(
                    np.maximum(
                        support_region.required_margins
                        - balance_predicted_margins,
                        0.0,
                    ),
                    initial=0.0,
                )
            )
        solver_info.update(
            {
                "reflex_mode": self.config.reflex_mode,
                "hard_collision_constraint_count": collision_constraint_count,
                "hard_collision_constraints_enabled": (
                    self.config.hard_support_collision_constraints_enabled
                ),
                "hard_collision_linear_max_violation": float(
                    np.max(np.maximum(-hard_collision_slacks, 0.0), initial=0.0)
                ),
                "hard_support_balance_constraint_enabled": (
                    support_region is not None
                ),
                "hard_support_balance_constraint_applied": (
                    support_region is not None
                ),
                "hard_support_balance_margin_m": (
                    0.0
                    if support_region is None
                    else support_region.safety_margin_m
                ),
                "hard_support_balance_vertex_count": (
                    0 if support_region is None else support_region.vertex_count
                ),
                "hard_support_balance_edge_count": (
                    0 if support_region is None else support_region.edge_count
                ),
                "hard_support_balance_reference_min_margin_m": (
                    0.0
                    if support_region is None
                    else float(np.min(support_region.reference_margins))
                ),
                "hard_support_balance_required_min_margin_m": (
                    0.0
                    if support_region is None
                    else float(np.min(support_region.required_margins))
                ),
                "hard_support_balance_current_min_margin_m": (
                    0.0
                    if support_region is None
                    else float(np.min(balance_current_margins))
                ),
                "hard_support_balance_predicted_min_margin_m": (
                    0.0
                    if support_region is None
                    else float(np.min(balance_predicted_margins))
                ),
                "hard_support_balance_linear_max_violation_m": (
                    balance_linear_max_violation
                ),
                "hard_support_balance_row_norm_min": (
                    0.0
                    if balance_row_norms.size == 0
                    else float(np.min(balance_row_norms))
                ),
                "hard_support_balance_row_norm_max": (
                    0.0
                    if balance_row_norms.size == 0
                    else float(np.max(balance_row_norms))
                ),
                "hard_support_balance_linear_lower_min_m": (
                    0.0
                    if balance_lower.size == 0
                    else float(np.min(balance_lower))
                ),
                "hard_support_balance_linear_lower_max_m": (
                    0.0
                    if balance_lower.size == 0
                    else float(np.max(balance_lower))
                ),
                "hard_support_balance_build_time_ms": (
                    0.0 if support_region is None else support_region.build_time_ms
                ),
                "support_point_count": support_count,
                "support_constraints_enabled": (
                    self.config.hard_support_stance_constraints_enabled
                ),
                "support_diagnostic_row_count": int(support_jacobian.shape[0]),
                "support_constraint_row_count": int(support_jacobian.shape[0]),
                "support_constraint_applied_row_count": int(
                    support_basis.shape[0]
                ),
                "support_constraint_rank": support_rank,
                "support_constraint_linear_residual": support_residual,
                "support_constraint_linear_position_residual": support_position_residual,
                "support_constraint_linear_rotation_residual": support_rotation_residual,
                "centroidal_impulse_constraint_enabled": impulse_enabled,
                "centroidal_impulse_residual": momentum_residual,
                "support_impulse_count": support_count if impulse_enabled else 0,
                "support_impulse_norm": impulse_norm,
                "support_impulse_max_norm": impulse_max_norm,
                "implied_minimum_support_impulse_norm": implied_minimum_impulse_norm,
                "support_impulse_dt": self.config.support_impulse_dt,
                "support_impulse_weight": self.config.w_support_impulse,
                "objective_term_retreat_signed": objective_term_retreat_signed,
                "objective_term_retreat_magnitude": abs(objective_term_retreat_signed),
                "objective_term_joint_l2": objective_term_joint_l2,
                "objective_term_generalized_inertia": objective_term_generalized_inertia,
                "objective_term_removed_generalized_inertia": (
                    objective_term_removed_generalized_inertia
                ),
                "objective_term_full_generalized_inertia": (
                    objective_term_full_generalized_inertia
                ),
                "hard_support_body_energy_mode": (
                    self.config.hard_support_body_energy_mode
                ),
                "hard_support_free_world_com_z_body_energy": (
                    self.config.hard_support_free_world_com_z_body_energy
                ),
                "body_energy_transfer_to_joint_enabled": (
                    self.config.hard_support_transfer_removed_body_energy_to_joint
                ),
                "body_energy_transferred_joint_weight": (
                    body_energy_model.transferred_joint_weight
                ),
                "body_energy_transfer_numerator": (
                    body_energy_model.transfer_numerator
                ),
                "body_energy_transfer_denominator": (
                    body_energy_model.transfer_denominator
                ),
                "body_energy_transfer_nullity": (
                    body_energy_model.transfer_nullity
                ),
                "effective_joint_regularization_min": float(
                    np.min(body_energy_model.effective_joint_regularization)
                ),
                "effective_joint_regularization_max": float(
                    np.max(body_energy_model.effective_joint_regularization)
                ),
                "objective_term_world_com": objective_term_world_com,
                "objective_term_numerical_damping": objective_term_numerical_damping,
                "objective_term_support_impulse": objective_term_support_impulse,
                "objective_term_angular_regularization": (
                    objective_term_angular_regularization
                ),
                "static_support_effort_enabled": (
                    static_support_effort_model is not None
                ),
                "static_support_effort_weight": (
                    self.config.w_static_support_effort
                ),
                "objective_term_static_support_effort": (
                    objective_term_static_support_effort
                ),
                "static_support_effort_reference": (
                    0.0
                    if static_support_effort_model is None
                    else static_support_effort_model.reference_effort
                ),
                "static_support_effort_predicted": (
                    predicted_static_support_effort
                ),
                "static_support_reference_actuator_torque_norm": (
                    0.0
                    if static_support_effort_model is None
                    else float(
                        np.linalg.norm(
                            static_support_effort_model.reference_actuator_torque
                        )
                    )
                ),
                "static_support_reference_force_norm": (
                    0.0
                    if static_support_effort_model is None
                    else float(
                        np.linalg.norm(
                            static_support_effort_model.reference_support_force
                        )
                    )
                ),
                "static_support_reference_equilibrium_residual": (
                    0.0
                    if static_support_effort_model is None
                    else static_support_effort_model.reference_equilibrium_residual
                ),
                "static_support_system_rank": (
                    0
                    if static_support_effort_model is None
                    else static_support_effort_model.system_rank
                ),
                "static_support_system_condition_number": (
                    0.0
                    if static_support_effort_model is None
                    else static_support_effort_model.system_condition_number
                ),
                "static_support_model_build_time_ms": (
                    0.0
                    if static_support_effort_model is None
                    else static_support_effort_model.build_time_ms
                ),
                "objective_term_positive_total": objective_positive_total,
                "objective_reconstructed": objective_reconstructed,
                "predicted_world_com_displacement_norm": float(
                    np.linalg.norm(predicted_world_com_delta)
                ),
                "retreat_reference_frame": (
                    self.config.hard_support_retreat_reference_frame
                ),
                "predicted_world_retreat_distance": float(
                    retreat_normal @ predicted_world_contact_delta
                ),
                "predicted_com_relative_retreat_distance": float(
                    predicted_com_relative_retreat
                ),
                "hard_support_qp_round_index": round_index,
                "hard_support_round_joint_correction_max": float(
                    np.max(np.abs(delta_z[6:]), initial=0.0)
                ),
                "hard_support_accumulated_joint_delta_max": float(
                    np.max(np.abs(total_delta_q), initial=0.0)
                ),
                **angular_diagnostics,
                **guided_info,
            }
        )
        if hard_retreat:
            retreat_slack = float(
                predicted_retreat - self.config.min_retreat_distance
            )
            solver_info["retreat_constraint_linear_slack"] = retreat_slack
            solver_info["retreat_constraint_linear_violation"] = max(0.0, -retreat_slack)

        objective_value = objective_reconstructed
        return LinearizedQPSolution(
            q_joint_target=q_joint_target,
            base_delta=delta_z[:6],
            success=optimizer_success,
            message=f"linearized_qp/proxqp/{self.config.reflex_mode}: {message}",
            num_iterations=num_iterations,
            objective_value=objective_value,
            active_collision_pair_indices=active_collision_pair_indices,
            hard_collision_targets=hard_collision_targets,
            hard_collision_slacks=hard_collision_slacks,
            hard_collision_duals=hard_collision_duals,
            support_impulse=support_impulse,
            restoration_regularizer=regularizer_kinematic.copy(),
            support_region=support_region,
            info=solver_info,
        )

    def _linearized_collision_constraints_batched(
        self,
        data: mujoco.MjData,
        optimization_pair_indices: list[tuple[int, int]],
        dof_indices: np.ndarray | None = None,
        target_distances: dict[tuple[int, int], float] | None = None,
    ) -> tuple[np.ndarray, np.ndarray, list[tuple[int, int]], dict[tuple[int, int], float]]:
        (
            distance_values,
            points_a,
            points_b,
        ) = self.self_collision_model.pair_distance_arrays(
            data,
            optimization_pair_indices,
        )
        columns = self.joint_dof_addr if dof_indices is None else dof_indices
        width = len(columns)
        pair_count = len(optimization_pair_indices)
        if pair_count == 0:
            return (
                np.empty((0, width), dtype=np.float64),
                np.empty(0, dtype=np.float64),
                [],
                {},
            )
        primitives = self.self_collision_model.primitives
        bodies = [(primitives[a].body_id, primitives[b].body_id)
                  for a, b in optimization_pair_indices]
        normals = points_a - points_b
        norms = np.linalg.norm(normals, axis=1)
        degenerate = np.flatnonzero(norms < 1e-8)
        for index in degenerate:
            a, b = bodies[index]
            normals[index] = data.xipos[a] - data.xipos[b]
            norms[index] = np.linalg.norm(normals[index])
            if norms[index] < 1e-8:
                raise RuntimeError(
                    "Degenerate collision normal for primitive pair "
                    f"{optimization_pair_indices[index]}"
                )
        normals /= norms[:, None]
        normals[distance_values < 0.0] *= -1.0

        # Keep exact MuJoCo witness-point Jacobians and call order. Batch only
        # the NumPy column selection/contraction; no origin reconstruction,
        # broadphase culling, pair removal or approximate distance is used.
        jac_a = np.empty((pair_count, 3, self.model.nv), dtype=np.float64)
        jac_b = np.empty_like(jac_a)
        for index, (body_a, body_b) in enumerate(bodies):
            mujoco.mj_jac(self.model, data, jac_a[index], None, points_a[index], body_a)
            mujoco.mj_jac(self.model, data, jac_b[index], None, points_b[index], body_b)
        difference = (jac_a - jac_b)[:, :, columns]
        jacobian_rows = np.ascontiguousarray(
            (normals[:, None, :] @ difference)[:, 0, :]
        )
        # First round freezes min(q0 clearance, safe margin); subsequent
        # rounds reuse those exact event-relative targets, including overlap.
        targets = {
            pair: (target_distances[pair]
                   if target_distances is not None and pair in target_distances
                   else min(float(distance), self.config.collision_safe_margin))
            for pair, distance in zip(optimization_pair_indices, distance_values)
        }
        lower_bounds = np.array([targets[pair] for pair in optimization_pair_indices]) - distance_values
        return (
            jacobian_rows,
            lower_bounds,
            list(optimization_pair_indices),
            targets,
        )

    def _linearized_collision_constraints(
        self,
        data: mujoco.MjData,
        optimization_pair_indices: list[tuple[int, int]],
        dof_indices: np.ndarray | None = None,
        target_distances: dict[tuple[int, int], float] | None = None,
    ) -> tuple[np.ndarray, np.ndarray, list[tuple[int, int]], dict[tuple[int, int], float]]:
        if self.config.hard_support_batched_collision_assembly:
            return self._linearized_collision_constraints_batched(
                data, optimization_pair_indices, dof_indices, target_distances,
            )
        (
            distance_values,
            points_a,
            points_b,
        ) = self.self_collision_model.pair_distance_arrays(
            data,
            optimization_pair_indices,
        )
        # MuJoCo overwrites the complete translational Jacobian.  Reuse the
        # two raw output buffers across collision pairs, while preserving the
        # original mj_jac call order and NumPy column-selection operation.
        # This removes hundreds of tiny allocations without replacing the
        # exact point Jacobian with a reconstructed body-origin Jacobian.
        jacp_a_full = np.empty((3, self.model.nv), dtype=np.float64)
        jacp_b_full = np.empty((3, self.model.nv), dtype=np.float64)
        width = (
            len(self.joint_ids)
            if dof_indices is None
            else len(dof_indices)
        )
        pair_count = len(optimization_pair_indices)
        jacobian_rows = np.empty((pair_count, width), dtype=np.float64)
        lower_bounds = np.empty(pair_count, dtype=np.float64)
        pair_indices: list[tuple[int, int]] = []
        targets: dict[tuple[int, int], float] = {}
        for row_index, pair_index in enumerate(optimization_pair_indices):
            primitive_a, primitive_b = pair_index
            body_a = self.self_collision_model.primitives[primitive_a].body_id
            body_b = self.self_collision_model.primitives[primitive_b].body_id
            point_a = points_a[row_index]
            point_b = points_b[row_index]
            distance_value = float(distance_values[row_index])
            normal_vec = point_a - point_b
            normal_norm = float(np.linalg.norm(normal_vec))
            if normal_norm < 1e-8:
                normal_vec = data.xipos[body_a] - data.xipos[body_b]
                normal_norm = float(np.linalg.norm(normal_vec))
            if normal_norm < 1e-8:
                raise RuntimeError(
                    f"Degenerate collision normal for primitive pair {pair_index}"
                )
            normal_vec /= normal_norm
            if distance_value < 0.0:
                normal_vec *= -1.0

            if dof_indices is None:
                jac_a = self._point_jacobian_world(
                    data,
                    body_a,
                    point_a,
                )
                jac_b = self._point_jacobian_world(
                    data,
                    body_b,
                    point_b,
                )
            else:
                mujoco.mj_jac(
                    self.model,
                    data,
                    jacp_a_full,
                    None,
                    point_a,
                    body_a,
                )
                mujoco.mj_jac(
                    self.model,
                    data,
                    jacp_b_full,
                    None,
                    point_b,
                    body_b,
                )
                jac_a = jacp_a_full[:, dof_indices]
                jac_b = jacp_b_full[:, dof_indices]
            jac_distance = normal_vec @ (jac_a - jac_b)
            if target_distances is not None and pair_index in target_distances:
                target_distance = target_distances[pair_index]
            else:
                # Freeze an event-relative target at the measured qpos0
                # clearance.  A no-op must remain feasible even when a valid
                # pose starts closer than the nominal margin or already has a
                # small proxy penetration; the QP may not make that clearance
                # worse.  Later SQP/restoration rounds receive this same target
                # through ``target_distances``.
                target_distance = min(
                    distance_value,
                    self.config.collision_safe_margin,
                )
            jacobian_rows[row_index] = jac_distance
            lower_bounds[row_index] = target_distance - distance_value
            pair_indices.append(pair_index)
            targets[pair_index] = target_distance

        if pair_count == 0:
            return (
                np.empty((0, width), dtype=np.float64),
                np.empty(0, dtype=np.float64),
                [],
                {},
            )
        return (
            jacobian_rows,
            lower_bounds,
            pair_indices,
            targets,
        )

    def _add_linearized_collision_terms(
        self,
        data: mujoco.MjData,
        regularizer: np.ndarray,
        linear_term: np.ndarray,
        optimization_pair_indices: list[tuple[int, int]],
    ) -> list[tuple[int, int]]:
        active = self.self_collision_model.pair_distances(data, optimization_pair_indices)
        if not active:
            return []
        for distance in active:
            normal_vec = distance.point_a - distance.point_b
            normal_norm = float(np.linalg.norm(normal_vec))
            if normal_norm < 1e-8:
                xipos = data.xipos[distance.body_a] - data.xipos[distance.body_b]
                normal_norm = float(np.linalg.norm(xipos))
                if normal_norm < 1e-8:
                    continue
                normal_vec = xipos
            normal_vec /= normal_norm

            jac_a = self._point_jacobian_world(data, distance.body_a, distance.point_a)
            jac_b = self._point_jacobian_world(data, distance.body_b, distance.point_b)
            jac_distance = normal_vec @ (jac_a - jac_b)
            target_distance = self.config.d_safe
            weight = self.config.w_collision
            violation = target_distance - distance.distance
            if violation <= 0.0:
                continue
            regularizer += weight * np.outer(jac_distance, jac_distance)
            linear_term += 2.0 * weight * violation * jac_distance
        return [distance.pair_index for distance in active]

    def _select_linearized_step(
        self,
        q0_joint: np.ndarray,
        q_joint_target: np.ndarray,
        evaluate,
        data: mujoco.MjData,
        active_collision_pair_indices: list[tuple[int, int]],
        collision_reference_distances: dict[tuple[int, int], float],
        contact_body_id: int,
    ) -> np.ndarray:
        delta = q_joint_target - q0_joint
        if not np.any(np.abs(delta) > 1e-12):
            return q_joint_target

        repaired_delta = self._repair_delta_locally(
            q0_joint=q0_joint,
            delta=delta.copy(),
            evaluate=evaluate,
            data=data,
            active_collision_pair_indices=active_collision_pair_indices,
            collision_reference_distances=collision_reference_distances,
            contact_body_id=contact_body_id,
        )
        if repaired_delta is not None:
            segment = self._evaluate_step_segment(
                q0_joint=q0_joint,
                delta=repaired_delta,
                evaluate=evaluate,
                data=data,
                active_collision_pair_indices=active_collision_pair_indices,
                collision_reference_distances=collision_reference_distances,
            )
            if segment["feasible"]:
                return q0_joint + repaired_delta

        feasible_best_q: np.ndarray | None = None
        feasible_best_retreat = -float("inf")
        fallback_q = q0_joint.copy()
        fallback_score = -float("inf")
        line_search_alphas = (1.0, 0.5, 0.25, 0.1, 0.05, 0.02, 0.01, 0.005)
        for alpha in line_search_alphas:
            candidate_delta = alpha * delta
            segment = self._evaluate_step_segment(
                q0_joint=q0_joint,
                delta=candidate_delta,
                evaluate=evaluate,
                data=data,
                active_collision_pair_indices=active_collision_pair_indices,
                collision_reference_distances=collision_reference_distances,
            )
            q = q0_joint + candidate_delta
            retreat = segment["endpoint_retreat"]
            score = (
                retreat
                - 25.0 * max(0.0, -retreat)
                - self.config.w_collision * segment["max_collision_cost"]
                - 8.0 * segment["max_guard_violation"]
                - 0.05 * segment["endpoint_tangent"]
            )
            if segment["feasible"] and retreat > feasible_best_retreat:
                feasible_best_retreat = retreat
                feasible_best_q = q.copy()
                break
            if segment["feasible"]:
                fallback_score = max(fallback_score, score)
                if fallback_score == score:
                    fallback_q = q.copy()

        if feasible_best_q is not None:
            return feasible_best_q
        if fallback_score > -float("inf"):
            return fallback_q
        return q0_joint.copy()

    def _evaluate_step_segment(
        self,
        q0_joint: np.ndarray,
        delta: np.ndarray,
        evaluate,
        data: mujoco.MjData,
        active_collision_pair_indices: list[tuple[int, int]],
        collision_reference_distances: dict[tuple[int, int], float],
    ) -> dict[str, float | bool]:
        step_norm = float(np.max(np.abs(delta))) if delta.size else 0.0
        max_sample_step = max(1e-6, self.config.line_search_path_sample_max_joint_delta)
        sample_limit = max(1, self.config.line_search_path_max_samples)
        sample_count = max(1, int(math.ceil(step_norm / max_sample_step)))
        sample_count = min(sample_count, sample_limit)
        endpoint_retreat = -float("inf")
        endpoint_tangent = float("inf")
        max_collision_cost = 0.0
        max_guard_violation = 0.0

        for sample_index in range(1, sample_count + 1):
            fraction = sample_index / sample_count
            q = q0_joint + fraction * delta
            _, metrics = evaluate(q, include_collision=False)
            if sample_index == sample_count:
                endpoint_retreat = metrics["retreat"]
                endpoint_tangent = metrics["tangent"]

            if active_collision_pair_indices and self.config.w_collision > 0.0:
                collision_result = self.self_collision_model.evaluate_fast(
                    data,
                    d_safe=self.config.d_safe,
                    pair_indices=active_collision_pair_indices,
                    reference_distances=collision_reference_distances,
                )
                collision_cost = max(0.0, collision_result.penalty)
                guard_violation = collision_result.max_guard_violation
                max_collision_cost = max(max_collision_cost, collision_cost)
                max_guard_violation = max(max_guard_violation, guard_violation)
                if guard_violation > self.config.collision_guard_tolerance:
                    return {
                        "feasible": False,
                        "endpoint_retreat": endpoint_retreat,
                        "endpoint_tangent": endpoint_tangent,
                        "max_collision_cost": max_collision_cost,
                        "max_guard_violation": max_guard_violation,
                    }

        feasible = endpoint_retreat > 0.0
        if self.config.w_collision > 0.0:
            feasible = feasible and max_guard_violation <= self.config.collision_guard_tolerance
        return {
            "feasible": feasible,
            "endpoint_retreat": endpoint_retreat,
            "endpoint_tangent": endpoint_tangent,
            "max_collision_cost": max_collision_cost,
            "max_guard_violation": max_guard_violation,
        }

    def _repair_delta_locally(
        self,
        q0_joint: np.ndarray,
        delta: np.ndarray,
        evaluate,
        data: mujoco.MjData,
        active_collision_pair_indices: list[tuple[int, int]],
        collision_reference_distances: dict[tuple[int, int], float],
        contact_body_id: int,
    ) -> np.ndarray | None:
        contact_joint_mask = self._ancestor_joint_mask(contact_body_id)
        non_contact_mask = ~contact_joint_mask
        collision_pair_set = set(active_collision_pair_indices)

        for _ in range(self.config.local_repair_iterations):
            q = q0_joint + delta
            _, metrics = evaluate(q, include_collision=False)
            collision_result = self.self_collision_model.evaluate_fast(
                data,
                d_safe=self.config.d_safe,
                pair_indices=active_collision_pair_indices,
                reference_distances=collision_reference_distances,
            )
            guard_violation = collision_result.max_guard_violation
            retreat = metrics["retreat"]

            if (
                retreat > 0.0
                and guard_violation <= self.config.collision_guard_tolerance
            ):
                return delta

            changed = False
            if guard_violation > self.config.collision_guard_tolerance:
                worst_pair = collision_result.worst_guard_pair or collision_result.min_pair_index
                if worst_pair is not None and worst_pair in collision_pair_set:
                    body_a = self.self_collision_model.primitives[worst_pair[0]].body_id
                    body_b = self.self_collision_model.primitives[worst_pair[1]].body_id
                    collision_mask = (
                        self._ancestor_joint_mask(body_a)
                        | self._ancestor_joint_mask(body_b)
                    )
                    delta[collision_mask & non_contact_mask] *= 0.35
                    delta[collision_mask & contact_joint_mask] *= 0.85
                    changed = True
                elif worst_pair is not None:
                    body_a = self.self_collision_model.primitives[worst_pair[0]].body_id
                    body_b = self.self_collision_model.primitives[worst_pair[1]].body_id
                    collision_mask = (
                        self._ancestor_joint_mask(body_a)
                        | self._ancestor_joint_mask(body_b)
                    )
                    delta[collision_mask & non_contact_mask] *= 0.35
                    delta[collision_mask & contact_joint_mask] *= 0.75
                    changed = True

            if retreat <= 0.0:
                delta[non_contact_mask] *= 0.5
                delta[contact_joint_mask] *= 0.85
                changed = True

            if not changed:
                break

        return None

    def _ancestor_joint_mask(self, body_id: int) -> np.ndarray:
        return self._ancestor_joint_masks[body_id]

    def _build_ancestor_joint_mask(self, body_id: int) -> np.ndarray:
        mask = np.zeros(len(self.joint_ids), dtype=bool)
        current = body_id
        body_jntnum = self.model.body_jntnum
        body_jntadr = self.model.body_jntadr
        while current != 0:
            for offset in range(body_jntnum[current]):
                joint_id = int(body_jntadr[current] + offset)
                index = self._joint_id_to_index.get(joint_id)
                if index is not None:
                    mask[index] = True
            current = int(self.model.body_parentid[current])
        return mask

    def _set_qpos(self, data: mujoco.MjData, qpos: np.ndarray) -> None:
        data.qpos[:] = qpos
        data.qvel[:] = 0.0
        mujoco.mj_forward(self.model, data)

    def _set_qpos_static_support(
        self,
        data: mujoco.MjData,
        qpos: np.ndarray,
    ) -> None:
        """Refresh only fields consumed by the q0 static-support FD model."""

        data.qpos[:] = qpos
        data.qvel[:] = 0.0
        mujoco.mj_kinematics(self.model, data)
        mujoco.mj_comPos(self.model, data)
        mujoco.mj_rne(self.model, data, 0, data.qfrc_bias)

    def _apply_base_reaction_rotation(
        self,
        qpos_target: np.ndarray,
        base_delta: np.ndarray,
    ) -> None:
        tangent = np.zeros(self.model.nv, dtype=np.float64)
        tangent[self.root_dof_addr + 3 : self.root_dof_addr + 6] = base_delta[3:]
        mujoco.mj_integratePos(self.model, qpos_target, tangent, 1.0)

    def _apply_base_increment(
        self,
        qpos_target: np.ndarray,
        base_delta: np.ndarray,
    ) -> None:
        tangent = np.zeros(self.model.nv, dtype=np.float64)
        tangent[self.root_dof_addr : self.root_dof_addr + 6] = base_delta
        mujoco.mj_integratePos(self.model, qpos_target, tangent, 1.0)

    def _point_jacobian(
        self,
        data: mujoco.MjData,
        body_id: int,
        point_local: np.ndarray,
    ) -> np.ndarray:
        jacp = np.zeros((3, self.model.nv), dtype=np.float64)
        jacr = np.zeros((3, self.model.nv), dtype=np.float64)
        point_world = contact_point_world(data, body_id, point_local)
        return self._point_jacobian_world(data, body_id, point_world)

    def _point_jacobian_full(
        self,
        data: mujoco.MjData,
        body_id: int,
        point_local: np.ndarray,
    ) -> np.ndarray:
        point_world = contact_point_world(data, body_id, point_local)
        return self._point_jacobian_world_full(data, body_id, point_world)

    def _point_frame_jacobian_full(
        self,
        data: mujoco.MjData,
        body_id: int,
        point_local: np.ndarray,
    ) -> np.ndarray:
        point_world = contact_point_world(data, body_id, point_local)
        jacp = np.zeros((3, self.model.nv), dtype=np.float64)
        jacr = np.zeros((3, self.model.nv), dtype=np.float64)
        mujoco.mj_jac(self.model, data, jacp, jacr, point_world, body_id)
        return np.vstack((jacp, jacr))

    def _point_jacobian_world(
        self,
        data: mujoco.MjData,
        body_id: int,
        point_world: np.ndarray,
    ) -> np.ndarray:
        jacp = np.zeros((3, self.model.nv), dtype=np.float64)
        jacr = np.zeros((3, self.model.nv), dtype=np.float64)
        mujoco.mj_jac(self.model, data, jacp, jacr, point_world, body_id)
        return jacp[:, self.joint_dof_addr]

    def _point_jacobian_world_full(
        self,
        data: mujoco.MjData,
        body_id: int,
        point_world: np.ndarray,
    ) -> np.ndarray:
        jacp = np.zeros((3, self.model.nv), dtype=np.float64)
        mujoco.mj_jac(self.model, data, jacp, None, point_world, body_id)
        return jacp

    def _body_com_jacobian(self, data: mujoco.MjData, body_id: int) -> np.ndarray:
        jacp = np.zeros((3, self.model.nv), dtype=np.float64)
        mujoco.mj_jacBodyCom(self.model, data, jacp, None, body_id)
        return jacp[:, self.joint_dof_addr]

    def _body_com_jacobians_full(self, data: mujoco.MjData) -> np.ndarray:
        jacobians = np.zeros((self.model.nbody, 3, self.model.nv), dtype=np.float64)
        jacp = np.zeros((3, self.model.nv), dtype=np.float64)
        for body_id in self.robot_body_ids:
            jacp.fill(0.0)
            mujoco.mj_jacBodyCom(self.model, data, jacp, None, int(body_id))
            jacobians[body_id] = jacp
        return jacobians

    def _physical_com_jacobian_full(self, data: mujoco.MjData) -> np.ndarray:
        jacobian = np.zeros((3, self.model.nv), dtype=np.float64)
        mujoco.mj_jacSubtreeCom(self.model, data, jacobian, 0)
        return jacobian

    def evaluate_static_support_effort(
        self,
        data: mujoco.MjData,
        support_points: tuple[ResolvedStancePoint, ...],
    ) -> StaticSupportEffortState:
        """Evaluate exact minimum quasistatic support effort at ``data.qpos``.

        The contact model supplies a free 3D force at every selected stance
        point, while the actuated joints supply generalized joint torques.  No
        target pose, pelvis height, or struck-body information enters this
        calculation.
        """

        kinematic_dofs = self._kinematic_dofs
        # This public evaluator is used after the QP/projection path has
        # already selected its final pose.  Assemble the identical support
        # Jacobian into one contiguous buffer so reporting does not allocate
        # one temporary matrix per stance point plus a vstack result.
        support_jacobian = self._static_support_translational_jacobian(
            data,
            support_points,
            kinematic_dofs,
        )
        return self._minimum_static_support_effort_state(
            data,
            support_points,
            kinematic_dofs,
            support_jacobian=support_jacobian,
        )

    def _static_support_translational_jacobian(
        self,
        data: mujoco.MjData,
        support_points: tuple[ResolvedStancePoint, ...],
        kinematic_dofs: np.ndarray,
    ) -> np.ndarray:
        if not support_points:
            raise ValueError("Static support effort requires at least one stance point")
        # np.vstack of the former per-point fancy-index results is
        # Fortran-contiguous.  Preserve that layout as well as the exact
        # stance-point and mj_jac call order: fresh ProxQP is sensitive to
        # layout changes in ill-conditioned cases even when values match.
        support_jacobian = np.empty(
            (3 * len(support_points), len(kinematic_dofs)),
            dtype=np.float64,
            order="F",
        )
        jacp = np.empty((3, self.model.nv), dtype=np.float64)
        for point_index, point in enumerate(support_points):
            point_world = contact_point_world(
                data,
                point.body_id,
                point.local_position,
            )
            mujoco.mj_jac(
                self.model,
                data,
                jacp,
                None,
                point_world,
                point.body_id,
            )
            row_start = 3 * point_index
            support_jacobian[row_start : row_start + 3] = jacp[
                :, kinematic_dofs
            ]
        return support_jacobian

    def _minimum_static_support_effort_state(
        self,
        data: mujoco.MjData,
        support_points: tuple[ResolvedStancePoint, ...],
        kinematic_dofs: np.ndarray,
        *,
        support_jacobian: np.ndarray | None = None,
    ) -> StaticSupportEffortState:
        """Solve ``min ||tau||^2 + eps ||lambda||^2`` at one pose."""

        n_kinematic = len(kinematic_dofs)
        n_joint = len(self.joint_dof_addr)
        if support_jacobian is None:
            support_jacobian = self._static_support_translational_jacobian(
                data,
                support_points,
                kinematic_dofs,
            )
        actuation = np.zeros((n_kinematic, n_joint), dtype=np.float64)
        actuation[6:, :] = np.eye(n_joint, dtype=np.float64)

        contact_regularization = STATIC_SUPPORT_CONTACT_FORCE_REGULARIZATION
        weighted_system = np.hstack(
            (
                actuation,
                support_jacobian.T / math.sqrt(contact_regularization),
            )
        )
        gram = weighted_system @ weighted_system.T
        gram = 0.5 * (gram + gram.T)
        eigenvalues, eigenvectors = np.linalg.eigh(gram)
        largest = float(np.max(eigenvalues, initial=0.0))
        tolerance = (
            np.finfo(np.float64).eps
            * max(gram.shape)
            * max(largest, 1.0)
        )
        rank = int(np.sum(eigenvalues > tolerance))
        if rank != n_kinematic:
            raise StaticSupportModelRankError(rank, n_kinematic)
        smallest = float(np.min(eigenvalues))
        effort_metric = (
            eigenvectors
            @ np.diag(1.0 / eigenvalues)
            @ eigenvectors.T
        )
        effort_metric = 0.5 * (effort_metric + effort_metric.T)

        generalized_bias = data.qfrc_bias[kinematic_dofs].copy()
        dual = effort_metric @ generalized_bias
        actuator_torque = actuation.T @ dual
        support_force_flat = (
            support_jacobian @ dual / contact_regularization
        )
        support_force = support_force_flat.reshape(len(support_points), 3)
        equilibrium_residual = (
            actuation @ actuator_torque
            + support_jacobian.T @ support_force_flat
            - generalized_bias
        )
        effort = float(
            np.dot(actuator_torque, actuator_torque)
            + contact_regularization
            * np.dot(support_force_flat, support_force_flat)
        )
        return StaticSupportEffortState(
            generalized_bias=generalized_bias,
            effort_metric=effort_metric,
            actuator_torque=actuator_torque,
            support_force=support_force,
            effort=effort,
            equilibrium_residual=float(
                np.max(np.abs(equilibrium_residual), initial=0.0)
            ),
            system_rank=rank,
            system_condition_number=largest / smallest,
        )

    def _build_static_support_effort_model(
        self,
        data: mujoco.MjData,
        qpos0: np.ndarray,
        support_points: tuple[ResolvedStancePoint, ...],
        kinematic_dofs: np.ndarray,
    ) -> StaticSupportEffortModel:
        """Build the q0-frozen support-effort Gauss-Newton objective."""

        build_start = time.perf_counter()
        self._set_qpos_static_support(data, qpos0)
        support_jacobian_0 = self._static_support_translational_jacobian(
            data,
            support_points,
            kinematic_dofs,
        )
        reference = self._minimum_static_support_effort_state(
            data,
            support_points,
            kinematic_dofs,
            support_jacobian=support_jacobian_0,
        )
        support_force_0 = reference.support_force.reshape(-1)
        reference_effective_load = (
            reference.generalized_bias
            - support_jacobian_0.T @ support_force_0
        )

        finite_difference_step = STATIC_SUPPORT_FINITE_DIFFERENCE_STEP
        load_jacobian = np.empty(
            (len(kinematic_dofs), len(kinematic_dofs)),
            dtype=np.float64,
        )
        tangent = np.zeros(self.model.nv, dtype=np.float64)
        qpos = np.empty_like(qpos0)
        try:
            for column, dof_index in enumerate(kinematic_dofs):
                tangent.fill(0.0)
                tangent[int(dof_index)] = finite_difference_step
                np.copyto(qpos, qpos0)
                mujoco.mj_integratePos(
                    self.model,
                    qpos,
                    tangent,
                    1.0,
                )
                self._set_qpos_static_support(data, qpos)
                support_jacobian = self._static_support_translational_jacobian(
                    data,
                    support_points,
                    kinematic_dofs,
                )
                effective_load = (
                    data.qfrc_bias[kinematic_dofs]
                    - support_jacobian.T @ support_force_0
                )
                load_jacobian[:, column] = (
                    effective_load - reference_effective_load
                ) / finite_difference_step
        finally:
            self._set_qpos_static_support(data, qpos0)

        weight = self.config.w_static_support_effort
        objective_regularizer = weight * (
            load_jacobian.T @ reference.effort_metric @ load_jacobian
        )
        objective_regularizer = 0.5 * (
            objective_regularizer + objective_regularizer.T
        )
        objective_linear_offset = 2.0 * weight * (
            load_jacobian.T
            @ reference.effort_metric
            @ reference.generalized_bias
        )
        return StaticSupportEffortModel(
            reference_bias=reference.generalized_bias,
            load_jacobian=load_jacobian,
            effort_metric=reference.effort_metric,
            objective_regularizer=objective_regularizer,
            objective_linear_offset=objective_linear_offset,
            reference_actuator_torque=reference.actuator_torque,
            reference_support_force=reference.support_force,
            reference_effort=reference.effort,
            reference_equilibrium_residual=reference.equilibrium_residual,
            system_rank=reference.system_rank,
            system_condition_number=reference.system_condition_number,
            build_time_ms=(time.perf_counter() - build_start) * 1000.0,
        )

    def _build_hard_support_body_energy_model(
        self,
        data: mujoco.MjData,
        kinematic_dofs: np.ndarray,
        reference_inertia: np.ndarray,
        angular_motion_model: AngularMotionModel | None,
        selected_stance_points: tuple[ResolvedStancePoint, ...],
    ) -> HardSupportBodyEnergyModel:
        """Select body-energy curvature and optionally transfer what was removed.

        The transfer matches average quadratic curvature in the q0
        stance-feasible nullspace.  It is deliberately isotropic in actuated
        joint coordinates, so an ablation cannot inherit a hidden
        configuration-dependent full-body metric under another name.
        """

        mode = self.config.hard_support_body_energy_mode
        if mode == HARD_SUPPORT_BODY_ENERGY_FULL:
            active_inertia = reference_inertia.copy()
            removed_inertia = np.zeros_like(reference_inertia)
        elif mode == HARD_SUPPORT_BODY_ENERGY_TRANSLATIONAL:
            if angular_motion_model is None:
                raise RuntimeError(
                    "Translational-only body energy requires inertia decomposition"
                )
            active_inertia = angular_motion_model.translational_inertia.copy()
            removed_inertia = angular_motion_model.rotational_inertia.copy()
        elif mode == HARD_SUPPORT_BODY_ENERGY_NONE:
            active_inertia = np.zeros_like(reference_inertia)
            removed_inertia = reference_inertia.copy()
        else:  # guarded during optimizer construction
            raise AssertionError(f"Unhandled body-energy mode {mode!r}")

        if self.config.hard_support_free_world_com_z_body_energy:
            physical_com_jacobian = self._physical_com_jacobian_full(data)[
                :, kinematic_dofs
            ]
            total_mass = float(
                np.sum(self.model.body_mass[self.robot_body_ids])
            )
            removed_com_z_inertia = total_mass * np.outer(
                physical_com_jacobian[2], physical_com_jacobian[2]
            )
            active_inertia -= removed_com_z_inertia
            removed_inertia += removed_com_z_inertia

        effective_joint_regularization = self.joint_regularization_weights.copy()
        transferred_joint_weight = 0.0
        transfer_numerator = 0.0
        transfer_denominator = 0.0
        transfer_nullity = 0
        if self.config.hard_support_transfer_removed_body_energy_to_joint:
            support_jacobian, _, _ = self._point_support_and_centroidal_matrices(
                data,
                selected_stance_points,
                kinematic_dofs,
            )
            feasible_basis = orthonormal_null_space(support_jacobian)
            transfer_nullity = int(feasible_basis.shape[1])
            if transfer_nullity == 0:
                raise ValueError(
                    "Stance constraints leave no motion space for energy transfer"
                )
            removed_regularizer = (
                0.5 * self.config.w_body * removed_inertia
            )
            transfer_numerator = float(
                np.sum(feasible_basis * (removed_regularizer @ feasible_basis))
            )
            joint_feasible_basis = feasible_basis[6:, :]
            transfer_denominator = float(
                np.sum(joint_feasible_basis * joint_feasible_basis)
            )
            if transfer_denominator <= 1.0e-12:
                raise ValueError(
                    "Stance-feasible motion has no actuated-joint component"
                )
            transferred_joint_weight = max(
                0.0,
                transfer_numerator / transfer_denominator,
            )
            effective_joint_regularization += transferred_joint_weight

        return HardSupportBodyEnergyModel(
            active_inertia=0.5 * (active_inertia + active_inertia.T),
            removed_inertia=0.5 * (removed_inertia + removed_inertia.T),
            effective_joint_regularization=effective_joint_regularization,
            transferred_joint_weight=transferred_joint_weight,
            transfer_numerator=transfer_numerator,
            transfer_denominator=transfer_denominator,
            transfer_nullity=transfer_nullity,
        )

    def _build_angular_motion_model(
        self,
        data: mujoco.MjData,
        dof_indices: np.ndarray,
    ) -> AngularMotionModel:
        """Build q0-frozen angular maps and an optional QP regularizer.

        MuJoCo's angular-momentum matrix is about the whole-system CoM.  The
        explicit per-body construction below separates it into spin and
        orbital components and decomposes the generalized inertia into
        translational and rotational kinetic-energy matrices.  All matrices
        use the same floating-base-plus-actuated-DoF ordering as the QP.
        """

        n_kinematic = len(dof_indices)
        physical_com = compute_weighted_com(
            data.xipos,
            self.model.body_mass,
            self.robot_body_ids,
        )
        angular_momentum_full = np.zeros(
            (3, self.model.nv), dtype=np.float64
        )
        mujoco.mj_angmomMat(self.model, data, angular_momentum_full, 0)
        angular_momentum = angular_momentum_full[:, dof_indices]

        spin_angular_momentum = np.zeros(
            (3, n_kinematic), dtype=np.float64
        )
        orbital_angular_momentum = np.zeros_like(spin_angular_momentum)
        translational_inertia = np.zeros(
            (n_kinematic, n_kinematic), dtype=np.float64
        )
        rotational_inertia = np.zeros_like(translational_inertia)
        centroidal_inertia = np.zeros((3, 3), dtype=np.float64)
        jacp_full = np.zeros((3, self.model.nv), dtype=np.float64)
        jacr_full = np.zeros((3, self.model.nv), dtype=np.float64)

        for body_id_value in self.robot_body_ids:
            body_id = int(body_id_value)
            mass = float(self.model.body_mass[body_id])
            if mass <= 0.0:
                continue
            jacp_full.fill(0.0)
            jacr_full.fill(0.0)
            mujoco.mj_jacBodyCom(
                self.model,
                data,
                jacp_full,
                jacr_full,
                body_id,
            )
            jacp = jacp_full[:, dof_indices]
            jacr = jacr_full[:, dof_indices]
            inertia_rotation = data.ximat[body_id].reshape(3, 3)
            inertia_world = (
                inertia_rotation
                @ np.diag(self.model.body_inertia[body_id])
                @ inertia_rotation.T
            )
            offset = data.xipos[body_id] - physical_com
            offset_cross = skew_symmetric(offset)

            translational_inertia += mass * (jacp.T @ jacp)
            rotational_inertia += jacr.T @ inertia_world @ jacr
            spin_angular_momentum += inertia_world @ jacr
            orbital_angular_momentum += offset_cross @ (mass * jacp)
            centroidal_inertia += inertia_world + mass * (
                np.dot(offset, offset) * np.eye(3) - np.outer(offset, offset)
            )

        # The locked centroidal inertia is symmetric positive definite for a
        # non-degenerate floating-base robot.  Eigenvalue flooring is only a
        # numerical safeguard for diagnostic/experimental inverse metrics.
        centroidal_inertia = 0.5 * (
            centroidal_inertia + centroidal_inertia.T
        )
        eigenvalues, eigenvectors = np.linalg.eigh(centroidal_inertia)
        eigenvalue_floor = max(1.0e-12, 1.0e-10 * float(np.max(eigenvalues)))
        centroidal_inertia_inverse = (
            eigenvectors
            @ np.diag(1.0 / np.maximum(eigenvalues, eigenvalue_floor))
            @ eigenvectors.T
        )
        centroidal_angular_velocity = (
            centroidal_inertia_inverse @ angular_momentum
        )

        torso_body_id = mujoco.mj_name2id(
            self.model,
            mujoco.mjtObj.mjOBJ_BODY,
            "torso_link",
        )
        if torso_body_id < 0:
            raise ValueError(
                "Angular-motion diagnostics require a body named 'torso_link'"
            )
        jacp_full.fill(0.0)
        jacr_full.fill(0.0)
        mujoco.mj_jacBodyCom(
            self.model,
            data,
            jacp_full,
            jacr_full,
            torso_body_id,
        )
        torso_angular_velocity = jacr_full[:, dof_indices].copy()

        mode = self.config.angular_regularization_mode
        if mode == ANGULAR_REGULARIZATION_NONE:
            objective_metric = np.zeros(
                (n_kinematic, n_kinematic), dtype=np.float64
            )
        elif mode == ANGULAR_REGULARIZATION_CENTROIDAL_MOMENTUM:
            objective_metric = angular_momentum.T @ angular_momentum
        elif mode == ANGULAR_REGULARIZATION_CENTROIDAL_ROTATIONAL_ENERGY:
            objective_metric = (
                angular_momentum.T
                @ centroidal_inertia_inverse
                @ angular_momentum
            )
        elif mode == ANGULAR_REGULARIZATION_CENTROIDAL_ANGULAR_VELOCITY:
            objective_metric = (
                centroidal_angular_velocity.T
                @ centroidal_angular_velocity
            )
        elif mode == ANGULAR_REGULARIZATION_TORSO_ANGULAR_VELOCITY:
            objective_metric = (
                torso_angular_velocity.T @ torso_angular_velocity
            )
        else:  # guarded by _validate_config
            raise AssertionError(f"Unhandled angular regularization mode {mode!r}")
        objective_regularizer = 0.5 * self.config.w_angular_regularization * (
            0.5 * (objective_metric + objective_metric.T)
        )

        return AngularMotionModel(
            angular_momentum_matrix=angular_momentum,
            spin_angular_momentum_matrix=spin_angular_momentum,
            orbital_angular_momentum_matrix=orbital_angular_momentum,
            centroidal_inertia=centroidal_inertia,
            centroidal_inertia_inverse=centroidal_inertia_inverse,
            centroidal_angular_velocity_matrix=centroidal_angular_velocity,
            torso_angular_velocity_matrix=torso_angular_velocity,
            translational_inertia=0.5
            * (translational_inertia + translational_inertia.T),
            rotational_inertia=0.5
            * (rotational_inertia + rotational_inertia.T),
            objective_regularizer=objective_regularizer,
        )

    def _point_support_and_centroidal_matrices(
        self,
        data: mujoco.MjData,
        support_points: tuple[ResolvedStancePoint, ...],
        dof_indices: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        support_positions_world: list[np.ndarray] = []
        for point in support_points:
            point_world = contact_point_world(data, point.body_id, point.local_position)
            support_positions_world.append(point_world)
        support_jacobian = self._point_support_jacobian(
            data,
            support_points,
            dof_indices,
        )

        com_jacobian = np.zeros((3, self.model.nv), dtype=np.float64)
        angular_momentum_matrix = np.zeros((3, self.model.nv), dtype=np.float64)
        mujoco.mj_jacSubtreeCom(self.model, data, com_jacobian, 0)
        mujoco.mj_angmomMat(self.model, data, angular_momentum_matrix, 0)
        total_mass = float(np.sum(self.model.body_mass[self.robot_body_ids]))
        centroidal_matrix_full = np.vstack(
            (total_mass * com_jacobian, angular_momentum_matrix)
        )
        centroidal_matrix = centroidal_matrix_full[:, dof_indices]

        physical_com = compute_weighted_com(
            data.xipos,
            self.model.body_mass,
            self.robot_body_ids,
        )
        grasp_blocks: list[np.ndarray] = []
        for point_world in support_positions_world:
            grasp = np.zeros((6, 3), dtype=np.float64)
            grasp[:3, :] = np.eye(3)
            grasp[3:, :] = skew_symmetric(point_world - physical_com)
            grasp_blocks.append(grasp)
        support_grasp = np.hstack(grasp_blocks)
        return support_jacobian, support_grasp, centroidal_matrix

    def _point_support_jacobian(
        self,
        data: mujoco.MjData,
        support_points: tuple[ResolvedStancePoint, ...],
        dof_indices: np.ndarray,
    ) -> np.ndarray:
        """Return only the selected attached-frame Jacobian.

        The ordinary hard-support solver and nonlinear stance projection do
        not consume centroidal momentum or support-impulse matrices.  Keeping
        this narrow path avoids computing those diagnostic quantities in each
        sequential QP round while preserving the exact constraint matrix.
        """

        return np.vstack(
            [
                self._point_frame_jacobian_full(
                    data,
                    point.body_id,
                    point.local_position,
                )[:, dof_indices]
                for point in support_points
            ]
        )

    def _weighted_com_jacobian(
        self,
        data: mujoco.MjData,
        effective_mass: np.ndarray,
    ) -> np.ndarray:
        total_mass = float(np.sum(effective_mass[self.robot_body_ids]))
        jac = np.zeros((3, len(self.joint_ids)), dtype=np.float64)
        for body_id in self.robot_body_ids:
            jac += effective_mass[body_id] * self._body_com_jacobian(data, int(body_id))
        return jac / total_mass

    def _weighted_com_jacobian_from_cache(
        self,
        body_com_jacobians: np.ndarray,
        effective_mass: np.ndarray,
    ) -> np.ndarray:
        total_mass = float(np.sum(effective_mass[self.robot_body_ids]))
        return (
            np.sum(
                body_com_jacobians[self.robot_body_ids] * effective_mass[self.robot_body_ids, None, None],
                axis=0,
            )
            / total_mass
        )

    def _joint_regularization_weights(self) -> np.ndarray:
        weights = np.full(len(self.joint_ids), self.config.w_joint, dtype=np.float64)
        joint_index_by_name = {name: i for i, name in enumerate(self.joint_names)}
        for joint_name, weight in self.config.joint_regularization.items():
            index = joint_index_by_name.get(joint_name)
            if index is None:
                raise ValueError(f"Unknown joint regularization name {joint_name!r}")
            if weight < 0.0:
                raise ValueError(f"Joint regularization weight must be non-negative for {joint_name!r}")
            weights[index] = float(weight)
        return weights

    def _reduced_generalized_inertia(
        self, data: mujoco.MjData, stance_body_ids: list[int]
    ) -> tuple[np.ndarray, np.ndarray, float]:
        inertia = np.empty((self.model.nv, self.model.nv), dtype=np.float64)
        mujoco.mj_fullM(self.model, data, inertia)
        if stance_body_ids:
            virtual_mass = self.config.stance_extra_mass_total / len(stance_body_ids)
            for body_id in stance_body_ids:
                jacp = np.zeros((3, self.model.nv), dtype=np.float64)
                jacr = np.zeros((3, self.model.nv), dtype=np.float64)
                mujoco.mj_jacBodyCom(self.model, data, jacp, jacr, body_id)
                inertia += virtual_mass * (jacp.T @ jacp)
                body_mass = self.model.body_mass[body_id]
                if body_mass > 0.0:
                    rotation = data.ximat[body_id].reshape(3, 3)
                    rotational = rotation @ np.diag(
                        self.model.body_inertia[body_id] * virtual_mass / body_mass
                    ) @ rotation.T
                    inertia += jacr.T @ rotational @ jacr

        base = np.arange(self.root_dof_addr, self.root_dof_addr + 6)
        a = inertia[np.ix_(base, base)]
        b = inertia[np.ix_(base, self.joint_dof_addr)]
        c = inertia[np.ix_(self.joint_dof_addr, self.joint_dof_addr)]
        solve_a_b = np.linalg.solve(a, b)
        connection = -solve_a_b
        reduced = c - b.T @ solve_a_b
        residual = float(np.max(np.abs(a @ connection + b), initial=0.0))
        return 0.5 * (reduced + reduced.T), connection, residual

    def _effective_body_mass(self, stance_foot_body_ids: list[int]) -> np.ndarray:
        effective_mass = self.model.body_mass.copy()
        if stance_foot_body_ids:
            extra_mass = self.config.stance_extra_mass_total / len(stance_foot_body_ids)
            for body_id in stance_foot_body_ids:
                effective_mass[body_id] += extra_mass
        return effective_mass

    def _physical_joint_target_bounds(
        self, q0_joint: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray]:
        lower = np.full_like(q0_joint, -np.inf, dtype=np.float64)
        upper = np.full_like(q0_joint, np.inf, dtype=np.float64)

        for i, joint_id in enumerate(self.joint_ids):
            if self.model.jnt_limited[joint_id]:
                joint_lower, joint_upper = self.model.jnt_range[joint_id]
                if joint_upper - joint_lower > 2.0 * self.config.joint_limit_margin:
                    joint_lower += self.config.joint_limit_margin
                    joint_upper -= self.config.joint_limit_margin
                lower[i] = joint_lower
                upper[i] = joint_upper

        # qpos0 is a measurement, not a target.  If it already lies outside the
        # inset target interval, keep zero delta feasible and permit only motion
        # back toward the safe interval.  Never rewrite the measured state.
        lower = np.minimum(lower, q0_joint)
        upper = np.maximum(upper, q0_joint)
        return lower, upper

    def _joint_bounds(self, q0_joint: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        lower, upper = self._physical_joint_target_bounds(q0_joint)

        lower = np.maximum(lower, q0_joint - self.config.max_joint_delta)
        upper = np.minimum(upper, q0_joint + self.config.max_joint_delta)
        if self.waist_joint_indices.size:
            lower[self.waist_joint_indices] = np.maximum(
                lower[self.waist_joint_indices],
                q0_joint[self.waist_joint_indices] - self.config.waist_max_joint_delta,
            )
            upper[self.waist_joint_indices] = np.minimum(
                upper[self.waist_joint_indices],
                q0_joint[self.waist_joint_indices] + self.config.waist_max_joint_delta,
            )

        invalid = lower > upper
        if np.any(invalid):
            names = [self.joint_names[index] for index in np.flatnonzero(invalid)]
            raise RuntimeError(f"invalid reflex joint bounds for: {', '.join(names)}")
        return lower, upper

    def _joint_bound_activity(
        self,
        q0_joint: np.ndarray,
        q_joint_target: np.ndarray,
        *,
        tolerance: float = 1.0e-6,
    ) -> dict[str, float | int | bool | str]:
        physical_lower, physical_upper = self._physical_joint_target_bounds(q0_joint)
        if (
            self.config.reflex_mode != REFLEX_MODE_VIRTUAL_MASS_MOMENTUM
            and self.config.hard_support_qp_rounds > 1
        ):
            total_trust_region = (
                self.config.hard_support_qp_rounds
                * self.config.hard_support_joint_trust_region
            )
            effective_lower = np.maximum(
                physical_lower,
                q0_joint - total_trust_region,
            )
            effective_upper = np.minimum(
                physical_upper,
                q0_joint + total_trust_region,
            )
        else:
            total_trust_region = self.config.max_joint_delta
            effective_lower, effective_upper = self._joint_bounds(q0_joint)
        delta = q_joint_target - q0_joint

        physical_active = (
            (np.isfinite(physical_lower) & (np.abs(q_joint_target - physical_lower) <= tolerance))
            | (np.isfinite(physical_upper) & (np.abs(q_joint_target - physical_upper) <= tolerance))
        )
        optimization_active = (
            (np.isfinite(effective_lower) & (np.abs(q_joint_target - effective_lower) <= tolerance))
            | (np.isfinite(effective_upper) & (np.abs(q_joint_target - effective_upper) <= tolerance))
        )

        generic_delta_active = (
            np.abs(np.abs(delta) - total_trust_region) <= tolerance
        )
        waist_delta_active = np.zeros_like(generic_delta_active)
        if (
            self.config.hard_support_qp_rounds == 1
            and self.waist_joint_indices.size
            and self.config.waist_max_joint_delta < self.config.max_joint_delta - tolerance
        ):
            waist_delta_active[self.waist_joint_indices] = (
                np.abs(
                    np.abs(delta[self.waist_joint_indices])
                    - self.config.waist_max_joint_delta
                )
                <= tolerance
            )
            generic_delta_active[self.waist_joint_indices] = False

        def names(mask: np.ndarray) -> str:
            return ", ".join(
                name for name, active in zip(self.joint_names, mask, strict=True) if active
            )

        return {
            "optimization_bound_active_count": int(np.count_nonzero(optimization_active)),
            "optimization_bound_active_joint_names": names(optimization_active),
            "physical_joint_bound_active_count": int(np.count_nonzero(physical_active)),
            "physical_joint_bound_active_joint_names": names(physical_active),
            "delta_bound_active_count": int(np.count_nonzero(generic_delta_active)),
            "delta_bound_active_joint_names": names(generic_delta_active),
            "waist_delta_bound_active_count": int(np.count_nonzero(waist_delta_active)),
            "waist_delta_bound_active_joint_names": names(waist_delta_active),
            "joint_bound_activity_tolerance": tolerance,
        }


def skew_symmetric(vector: np.ndarray) -> np.ndarray:
    x, y, z = np.asarray(vector, dtype=np.float64)
    return np.array(
        (
            (0.0, -z, y),
            (z, 0.0, -x),
            (-y, x, 0.0),
        ),
        dtype=np.float64,
    )


def independent_row_space(matrix: np.ndarray) -> tuple[np.ndarray, int]:
    matrix = np.asarray(matrix, dtype=np.float64)
    if matrix.ndim != 2:
        raise ValueError("Expected a two-dimensional equality matrix")
    if matrix.shape[0] == 0:
        return np.empty((0, matrix.shape[1]), dtype=np.float64), 0
    _, singular_values, vh = np.linalg.svd(matrix, full_matrices=False)
    tolerance = (
        np.finfo(np.float64).eps * max(matrix.shape) * float(singular_values[0])
    )
    rank = int(np.sum(singular_values > tolerance))
    return np.ascontiguousarray(vh[:rank]), rank


def orthonormal_null_space(matrix: np.ndarray) -> np.ndarray:
    """Return an orthonormal basis for the right nullspace of ``matrix``."""

    matrix = np.asarray(matrix, dtype=np.float64)
    if matrix.ndim != 2:
        raise ValueError("Expected a two-dimensional matrix")
    if matrix.shape[0] == 0:
        return np.eye(matrix.shape[1], dtype=np.float64)
    _, singular_values, vh = np.linalg.svd(matrix, full_matrices=True)
    tolerance = (
        np.finfo(np.float64).eps
        * max(matrix.shape)
        * float(singular_values[0])
    )
    rank = int(np.sum(singular_values > tolerance))
    return np.ascontiguousarray(vh[rank:].T)


def independent_equality_system(
    matrix: np.ndarray,
    target: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, int]:
    """Compress ``matrix @ x = target`` without losing its nonzero target."""

    matrix = np.asarray(matrix, dtype=np.float64)
    target = np.asarray(target, dtype=np.float64)
    if matrix.ndim != 2 or target.shape != (matrix.shape[0],):
        raise ValueError("Expected a matrix and matching equality target")
    if matrix.shape[0] == 0:
        return (
            np.empty((0, matrix.shape[1]), dtype=np.float64),
            np.empty(0, dtype=np.float64),
            0,
        )
    u, singular_values, vh = np.linalg.svd(matrix, full_matrices=False)
    tolerance = (
        np.finfo(np.float64).eps * max(matrix.shape) * float(singular_values[0])
    )
    rank = int(np.sum(singular_values > tolerance))
    compressed_target = (u[:, :rank].T @ target) / singular_values[:rank]
    return (
        np.ascontiguousarray(vh[:rank]),
        np.ascontiguousarray(compressed_target),
        rank,
    )


def rotation_residual_world(
    current_rotation: np.ndarray,
    reference_rotation: np.ndarray,
) -> np.ndarray:
    """Return the world-frame rotation vector from reference to current."""

    rotation_error = np.asarray(current_rotation) @ np.asarray(reference_rotation).T
    quaternion = np.empty(4, dtype=np.float64)
    mujoco.mju_mat2Quat(quaternion, rotation_error.reshape(-1))
    if quaternion[0] < 0.0:
        quaternion *= -1.0
    residual = np.empty(3, dtype=np.float64)
    mujoco.mju_quat2Vel(residual, quaternion, 1.0)
    return residual


def stance_frame_residual_vector(
    data: mujoco.MjData,
    stance_points: tuple[ResolvedStancePoint, ...],
    reference_positions: dict[str, np.ndarray],
    reference_rotations: dict[str, np.ndarray],
) -> np.ndarray:
    """Return position/rotation residuals for the q0-selected stance frames."""

    residuals: list[np.ndarray] = []
    for point in stance_points:
        residuals.append(
            np.concatenate(
                (
                    contact_point_world(data, point.body_id, point.local_position)
                    - reference_positions[point.name],
                    rotation_residual_world(
                        data.xmat[point.body_id].reshape(3, 3),
                        reference_rotations[point.name],
                    ),
                )
            )
        )
    return np.concatenate(residuals) if residuals else np.empty(0, dtype=np.float64)


def compute_weighted_com(
    xipos: np.ndarray,
    effective_mass: np.ndarray,
    body_ids: np.ndarray,
) -> np.ndarray:
    masses = effective_mass[body_ids]
    total_mass = float(np.sum(masses))
    if total_mass <= 0.0:
        raise ValueError("total effective body mass must be positive")
    return np.sum(xipos[body_ids] * masses[:, None], axis=0) / total_mass


def contact_point_world(
    data: mujoco.MjData,
    body_id: int,
    contact_point_local: np.ndarray,
) -> np.ndarray:
    body_pos = data.xpos[body_id]
    body_rot = data.xmat[body_id].reshape(3, 3)
    return body_pos + body_rot @ contact_point_local


def foot_position_cost(
    data: mujoco.MjData,
    foot_xipos_0: dict[int, np.ndarray],
) -> float:
    total = 0.0
    for body_id, xipos_0 in foot_xipos_0.items():
        diff = data.xipos[body_id] - xipos_0
        total += float(np.dot(diff, diff))
    return total


def max_foot_displacement(
    data: mujoco.MjData,
    foot_xipos_0: dict[int, np.ndarray],
) -> float:
    if not foot_xipos_0:
        return 0.0
    return max(float(np.linalg.norm(data.xipos[body_id] - xipos_0)) for body_id, xipos_0 in foot_xipos_0.items())


def max_stance_point_displacement(
    data: mujoco.MjData,
    stance_points: tuple[ResolvedStancePoint, ...],
    positions_0: dict[str, np.ndarray],
) -> float:
    if not stance_points:
        return 0.0
    return max(
        float(
            np.linalg.norm(
                contact_point_world(data, point.body_id, point.local_position)
                - positions_0[point.name]
            )
        )
        for point in stance_points
    )


def max_stance_frame_rotation(
    data: mujoco.MjData,
    stance_points: tuple[ResolvedStancePoint, ...],
    rotations_0: dict[str, np.ndarray],
) -> float:
    """Return the largest nonlinear attached-frame rotation in radians."""

    if not stance_points:
        return 0.0
    max_angle = 0.0
    for point in stance_points:
        rotation = data.xmat[point.body_id].reshape(3, 3)
        rotation_error = rotation @ rotations_0[point.name].T
        cosine = 0.5 * (float(np.trace(rotation_error)) - 1.0)
        angle = float(np.arccos(np.clip(cosine, -1.0, 1.0)))
        max_angle = max(max_angle, angle)
    return max_angle


def solve_box_qp_active_set(
    regularizer: np.ndarray,
    linear_term: np.ndarray,
    lower: np.ndarray,
    upper: np.ndarray,
    max_iterations: int,
) -> np.ndarray:
    """Minimize x'Rx - l'x with simple bound constraints."""
    n = linear_term.shape[0]
    delta = np.zeros(n, dtype=np.float64)
    free = np.ones(n, dtype=bool)

    for _ in range(max_iterations):
        free_idx = np.flatnonzero(free)
        fixed_idx = np.flatnonzero(~free)
        if free_idx.size:
            rhs = 0.5 * linear_term[free_idx]
            if fixed_idx.size:
                rhs -= regularizer[np.ix_(free_idx, fixed_idx)] @ delta[fixed_idx]
            try:
                delta[free_idx] = np.linalg.solve(regularizer[np.ix_(free_idx, free_idx)], rhs)
            except np.linalg.LinAlgError:
                delta[free_idx] = np.linalg.lstsq(
                    regularizer[np.ix_(free_idx, free_idx)],
                    rhs,
                    rcond=None,
                )[0]

        clipped = np.clip(delta, lower, upper)
        violating = np.abs(clipped - delta) > 1e-10
        delta = clipped
        newly_fixed = violating & free
        if not np.any(newly_fixed):
            break
        free[newly_fixed] = False

    return np.clip(delta, lower, upper)


def solve_box_collision_qp_proxqp(
    regularizer: np.ndarray,
    linear_term: np.ndarray,
    lower: np.ndarray,
    upper: np.ndarray,
    collision_jacobian: np.ndarray,
    collision_lower: np.ndarray,
    eps_abs: float,
    eps_rel: float,
    max_iterations: int,
    equality_jacobian: np.ndarray | None = None,
    equality_target: np.ndarray | None = None,
) -> tuple[np.ndarray, bool, str, int, dict[str, float | int | bool | str], np.ndarray]:
    try:
        from proxsuite import proxqp
    except ImportError as exc:
        raise ImportError(
            "ProxQP solver requires proxsuite; install it with "
            "`conda run -n reflex_rollout python -m pip install proxsuite`."
        ) from exc

    n = linear_term.shape[0]
    hessian = np.ascontiguousarray(2.0 * regularizer, dtype=np.float64)
    hessian = 0.5 * (hessian + hessian.T)
    gradient = np.ascontiguousarray(-linear_term, dtype=np.float64)
    identity = np.eye(n, dtype=np.float64)
    constraint_matrix = np.ascontiguousarray(
        np.vstack((collision_jacobian, identity)),
        dtype=np.float64,
    )
    constraint_lower = np.ascontiguousarray(
        np.concatenate((collision_lower, lower)),
        dtype=np.float64,
    )
    constraint_upper = np.ascontiguousarray(
        np.concatenate((np.full(collision_lower.shape, np.inf), upper)),
        dtype=np.float64,
    )
    if equality_jacobian is None:
        if equality_target is not None:
            raise ValueError("equality_target requires equality_jacobian")
        equality_matrix = None
        equality_vector = None
        equality_count = 0
    else:
        if equality_target is None:
            raise ValueError("equality_jacobian requires equality_target")
        equality_matrix = np.ascontiguousarray(equality_jacobian, dtype=np.float64)
        equality_vector = np.ascontiguousarray(equality_target, dtype=np.float64)
        if equality_matrix.ndim != 2 or equality_matrix.shape[1] != n:
            raise ValueError("equality_jacobian has an incompatible shape")
        if equality_vector.shape != (equality_matrix.shape[0],):
            raise ValueError("equality_target has an incompatible shape")
        equality_count = equality_matrix.shape[0]

    solve_start = time.perf_counter()
    result = proxqp.dense.solve(
        hessian,
        gradient,
        equality_matrix,
        equality_vector,
        constraint_matrix,
        constraint_lower,
        constraint_upper,
        eps_abs=eps_abs,
        eps_rel=eps_rel,
        max_iter=max_iterations,
    )
    solve_time_ms = (time.perf_counter() - solve_start) * 1000.0
    delta = np.asarray(result.x, dtype=np.float64)
    finite = bool(delta.shape == (n,) and np.all(np.isfinite(delta)))
    if not finite:
        delta = np.zeros(n, dtype=np.float64)

    constraint_value = constraint_matrix @ delta
    lower_violation = float(
        np.max(np.maximum(constraint_lower - constraint_value, 0.0))
    )
    finite_upper = np.isfinite(constraint_upper)
    upper_violation = float(
        np.max(
            np.maximum(
                constraint_value[finite_upper] - constraint_upper[finite_upper],
                0.0,
            )
        )
    )
    max_linear_violation = max(lower_violation, upper_violation)
    equality_violation = (
        0.0
        if equality_matrix is None
        else float(np.max(np.abs(equality_matrix @ delta - equality_vector), initial=0.0))
    )
    max_linear_violation = max(max_linear_violation, equality_violation)
    status = str(result.info.status)
    status_solved = status.endswith("PROXQP_SOLVED")
    success = bool(finite and status_solved and max_linear_violation <= max(10.0 * eps_abs, 1e-7))
    message = status if success else f"{status}, max linear violation {max_linear_violation:.3e}"
    if not success:
        delta = np.zeros(n, dtype=np.float64)
    return (
        delta,
        success,
        message,
        int(result.info.iter),
        {
            "hard_collision_constraint_count": int(collision_jacobian.shape[0]),
            "hard_collision_linear_max_violation": max_linear_violation,
            "equality_constraint_count": equality_count,
            "equality_linear_max_violation": equality_violation,
            "proxqp_solve_time_ms": solve_time_ms,
            "proxqp_status": status,
        },
        np.asarray(result.z[: collision_jacobian.shape[0]], dtype=np.float64).copy(),
    )


def solve_box_qp_lbfgsb(
    regularizer: np.ndarray,
    linear_term: np.ndarray,
    lower: np.ndarray,
    upper: np.ndarray,
    max_iterations: int,
    ftol: float,
    gtol: float,
) -> tuple[np.ndarray, bool, str, int]:
    """Minimize x'Rx - l'x with box constraints using SciPy L-BFGS-B."""

    def objective(delta: np.ndarray) -> float:
        return float(delta @ regularizer @ delta - linear_term @ delta)

    def gradient(delta: np.ndarray) -> np.ndarray:
        return 2.0 * (regularizer @ delta) - linear_term

    result = minimize(
        objective,
        x0=np.clip(np.zeros_like(linear_term, dtype=np.float64), lower, upper),
        jac=gradient,
        method="L-BFGS-B",
        bounds=list(zip(lower, upper)),
        options={
            "maxiter": max_iterations,
            "ftol": ftol,
            "gtol": gtol,
        },
    )
    finite = bool(np.all(np.isfinite(result.x)))
    delta = np.clip(result.x, lower, upper) if finite else np.zeros_like(linear_term, dtype=np.float64)
    return delta, bool(result.success and finite), str(result.message), int(getattr(result, "nit", 0))


def merge_pair_indices(
    first: list[tuple[int, int]],
    second: list[tuple[int, int]],
) -> list[tuple[int, int]]:
    seen: set[tuple[int, int]] = set()
    merged: list[tuple[int, int]] = []
    for pair in first + second:
        if pair not in seen:
            seen.add(pair)
            merged.append(pair)
    return merged


def max_pair_distance_regression(
    distances,
    reference_distances: dict[tuple[int, int], float],
) -> float:
    regression = 0.0
    for distance in distances:
        reference = reference_distances.get(distance.pair_index)
        if reference is not None:
            regression = max(regression, reference - distance.distance)
    return regression
