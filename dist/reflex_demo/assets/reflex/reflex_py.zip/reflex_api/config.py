from __future__ import annotations

from dataclasses import dataclass, field


REFLEX_MODE_VIRTUAL_MASS_MOMENTUM = "virtual_mass_momentum"
REFLEX_MODE_HARD_SUPPORT = "hard_support"
REFLEX_MODE_HARD_SUPPORT_MIN_IMPULSE = "hard_support_min_impulse"
REFLEX_MODES = (
    REFLEX_MODE_VIRTUAL_MASS_MOMENTUM,
    REFLEX_MODE_HARD_SUPPORT,
    REFLEX_MODE_HARD_SUPPORT_MIN_IMPULSE,
)

RETREAT_REFERENCE_CONTACT_RELATIVE_TO_PHYSICAL_COM = (
    "contact_relative_to_physical_com"
)
RETREAT_REFERENCE_CONTACT_WORLD = "contact_world"
RETREAT_REFERENCE_FRAMES = (
    RETREAT_REFERENCE_CONTACT_RELATIVE_TO_PHYSICAL_COM,
    RETREAT_REFERENCE_CONTACT_WORLD,
)

ANGULAR_REGULARIZATION_NONE = "none"
ANGULAR_REGULARIZATION_CENTROIDAL_MOMENTUM = "centroidal_momentum"
ANGULAR_REGULARIZATION_CENTROIDAL_ROTATIONAL_ENERGY = (
    "centroidal_rotational_energy"
)
ANGULAR_REGULARIZATION_CENTROIDAL_ANGULAR_VELOCITY = (
    "centroidal_angular_velocity"
)
ANGULAR_REGULARIZATION_TORSO_ANGULAR_VELOCITY = "torso_angular_velocity"
ANGULAR_REGULARIZATION_MODES = (
    ANGULAR_REGULARIZATION_NONE,
    ANGULAR_REGULARIZATION_CENTROIDAL_MOMENTUM,
    ANGULAR_REGULARIZATION_CENTROIDAL_ROTATIONAL_ENERGY,
    ANGULAR_REGULARIZATION_CENTROIDAL_ANGULAR_VELOCITY,
    ANGULAR_REGULARIZATION_TORSO_ANGULAR_VELOCITY,
)

HARD_SUPPORT_BODY_ENERGY_FULL = "full"
HARD_SUPPORT_BODY_ENERGY_TRANSLATIONAL = "translational"
HARD_SUPPORT_BODY_ENERGY_NONE = "none"
HARD_SUPPORT_BODY_ENERGY_MODES = (
    HARD_SUPPORT_BODY_ENERGY_FULL,
    HARD_SUPPORT_BODY_ENERGY_TRANSLATIONAL,
    HARD_SUPPORT_BODY_ENERGY_NONE,
)


def _default_joint_regularization() -> dict[str, float]:
    """Prefer arm motion over unnecessary pelvis and lower-body motion."""
    lower_body_weight = 0.15
    return {
        joint_name: lower_body_weight
        for joint_name in (
            # Pelvis orientation is controlled through the waist and hip joints.
            "waist_yaw_joint",
            "waist_roll_joint",
            "waist_pitch_joint",
            "left_hip_pitch_joint",
            "left_hip_roll_joint",
            "left_hip_yaw_joint",
            "right_hip_pitch_joint",
            "right_hip_roll_joint",
            "right_hip_yaw_joint",
            # Knee and ankle joints control the legs and feet.
            "left_knee_joint",
            "right_knee_joint",
            "left_ankle_pitch_joint",
            "left_ankle_roll_joint",
            "right_ankle_pitch_joint",
            "right_ankle_roll_joint",
        )
    }


@dataclass(frozen=True)
class ReflexConfig:
    reflex_mode: str = REFLEX_MODE_VIRTUAL_MASS_MOMENTUM
    optimizer: str = "linearized_qp"
    linearized_qp_solver: str = "proxqp"
    w_retreat: float = 1.0
    # Hard-support retreat normally measures struck-point motion relative to
    # the physical whole-body CoM.  ``contact_world`` is an explicit ablation
    # that rewards the struck point's displacement in world coordinates.
    hard_support_retreat_reference_frame: str = (
        RETREAT_REFERENCE_CONTACT_RELATIVE_TO_PHYSICAL_COM
    )
    min_retreat_distance: float | None = None
    # Opt-in guided objective: a nonnegative shortfall epigraph, not a hard
    # retreat floor or world-displacement cap. Zero weight preserves setting1.
    preferred_retreat_distance: float | None = None
    w_retreat_shortfall: float = 0.0
    w_world_retreat_cone: float = 0.0
    world_retreat_cone_ratio: float = 0.9
    hard_support_contact_joint_regularization: dict[str, dict[str, float]] = field(
        default_factory=dict
    )
    hard_support_contact_retreat_distances: dict[str, float] = field(
        default_factory=dict
    )
    # Same witness-point Jacobians/targets; batch NumPy assembly only. Opt-in
    # for guided to retain the exact historical default assembly path.
    hard_support_batched_collision_assembly: bool = False
    w_body: float = 0.3
    w_joint: float = 0.01
    # Optional world-frame CoM displacement penalty.  Production stays at
    # zero; the candidate-point hard-support demo enables it explicitly.
    w_world_com: float = 0.0
    # Optional q0-frozen quasistatic support-effort objective for hard-support
    # modes.  Zero preserves the historical QP exactly.
    w_static_support_effort: float = 0.0
    # Optional q0-frozen angular-motion regularizer used only by the
    # floating-base hard-support QP.  ``none`` preserves the historical
    # objective exactly; experimental modes must be enabled explicitly.
    angular_regularization_mode: str = ANGULAR_REGULARIZATION_NONE
    w_angular_regularization: float = 0.0
    joint_regularization: dict[str, float] = field(
        default_factory=_default_joint_regularization
    )
    d_safe: float = 0.02
    w_collision: float = 250.0
    collision_safe_margin: float = 0.01
    collision_report_margin: float = 0.04
    w_collision_barrier: float = 0.0
    non_contact_joint_scale: float = 1.0
    joint_limit_margin: float = 0.03
    max_joint_delta: float = 0.3
    waist_max_joint_delta: float = 0.4
    stance_extra_mass_total: float = 0.0
    stance_height_tolerance: float = 0.05
    support_impulse_dt: float = 0.05
    w_support_impulse: float = 1e-4
    use_foot_position_penalty: bool = False
    w_foot: float = 100.0
    max_iter: int = 50
    ftol: float = 1e-4
    finite_difference_step: float = 1e-3
    linearized_damping: float = 1e-5
    linearized_active_set_iterations: int = 8
    linearized_lbfgsb_max_iter: int = 300
    linearized_lbfgsb_ftol: float = 1e-12
    linearized_lbfgsb_gtol: float = 1e-5
    proxqp_eps_abs: float = 1e-8
    proxqp_eps_rel: float = 1e-8
    proxqp_max_iter: int = 20
    hard_support_qp_rounds: int = 1
    hard_support_joint_trust_region: float = 0.3
    # Optional nonlinear Newton projection onto the already-defined 6D stance
    # manifold after the sequential hard-support QPs.  Zero preserves the
    # historical output exactly.
    hard_support_stance_projection_iterations: int = 0
    # Experimental final-pose feasibility restoration for the two-round
    # ordinary hard-support solver.  The task QPs keep their existing
    # objective; a third update of the same event-local ProxQP workspace only
    # restores the nonlinear stance manifold while preserving the achieved
    # world- and CoM-relative hit retreat.  Disabled by default.
    hard_support_joint_hit_restoration_enabled: bool = False
    # Optional qpos0-frozen support-polygon constraint for hard-support modes.
    # Disabled preserves the historical QP exactly.  When enabled, every SQP
    # round keeps the physical CoM at least as far inside each support edge as
    # min(qpos0 margin, hard_support_balance_margin).
    hard_support_balance_constraint_enabled: bool = False
    hard_support_balance_margin: float = 0.02
    # Default-preserving, hard-support-only component ablations.  These are
    # intentionally not exposed through ReflexAPI or training config.
    hard_support_collision_constraints_enabled: bool = True
    hard_support_stance_constraints_enabled: bool = True
    hard_support_body_energy_mode: str = HARD_SUPPORT_BODY_ENERGY_FULL
    # Remove only the q0-frozen global physical-CoM Z translational inertia.
    # Generic configs default off; the formal setting1 hard-support profile
    # enables it. Relative body translation, global CoM XY translation, and
    # body rotation remain in the full-body metric.
    hard_support_free_world_com_z_body_energy: bool = False
    hard_support_transfer_removed_body_energy_to_joint: bool = False
    line_search_path_sample_max_joint_delta: float = 0.05
    line_search_path_max_samples: int = 16
    collision_guard_tolerance: float = 0.005
    local_repair_iterations: int = 0
    collect_diagnostics: bool = False

    def __post_init__(self) -> None:
        joint_regularization = _default_joint_regularization()
        joint_regularization.update(self.joint_regularization)
        object.__setattr__(self, "joint_regularization", joint_regularization)
