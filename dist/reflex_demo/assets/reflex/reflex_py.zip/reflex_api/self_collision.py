from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path

import mujoco
import numpy as np

from .collision_pair_allowlist import OPTIMIZATION_PAIR_NAMES, REPORTING_PAIR_NAMES


BOX_VERTEX_SIGNS = np.array(
    [
        [-1.0, -1.0, -1.0],
        [-1.0, -1.0, 1.0],
        [-1.0, 1.0, -1.0],
        [-1.0, 1.0, 1.0],
        [1.0, -1.0, -1.0],
        [1.0, -1.0, 1.0],
        [1.0, 1.0, -1.0],
        [1.0, 1.0, 1.0],
    ],
    dtype=np.float64,
)


# Human-reviewed symmetric OBB for the canonical hip-roll and hip-yaw visual
# meshes, expressed in the hip-roll frame.  This is intentionally an aggressive
# visual proxy rather than a conservative swept-volume cover at arbitrary
# hip-yaw angles.
MERGED_HIP_COLLISION_LOCAL_POS = (0.006, 0.0, -0.15193300656735897)
MERGED_HIP_COLLISION_LOCAL_ROTATION = (
    (0.9727758782093966, 0.0, 0.23174790349415733),
    (0.0, 1.0, 0.0),
    (-0.23174790349415733, 0.0, 0.9727758782093966),
)
MERGED_HIP_COLLISION_HALF_SIZE = (
    0.0605,
    0.04911654815077782,
    0.1984177786833048,
)


@dataclass(frozen=True)
class BodyPrimitive:
    body_id: int
    body_name: str
    kind: str
    local_a: np.ndarray | None = None
    local_b: np.ndarray | None = None
    radius: float = 0.0
    local_pos: np.ndarray | None = None
    local_rot: np.ndarray | None = None
    half_size: np.ndarray | None = None
    broadphase_radius: float = 0.0


@dataclass(frozen=True)
class PrimitiveState:
    primitive: BodyPrimitive
    body_pos: np.ndarray
    body_rot: np.ndarray
    a: np.ndarray | None = None
    b: np.ndarray | None = None
    radius: float = 0.0
    center: np.ndarray | None = None
    half_size: np.ndarray | None = None
    vertices: np.ndarray | None = None
    broadphase_center: np.ndarray | None = None


@dataclass(frozen=True)
class PrimitiveDistance:
    distance: float
    body_a: int
    body_b: int
    point_a: np.ndarray
    point_b: np.ndarray
    pair_index: tuple[int, int]


@dataclass(frozen=True)
class SelfCollisionResult:
    penalty: float
    min_distance: float
    min_pair: tuple[str, str] | None
    distances: list[PrimitiveDistance]


@dataclass(frozen=True)
class SelfCollisionBatchResult:
    penalty: float
    min_distance: float
    min_pair: tuple[str, str] | None
    min_pair_index: tuple[int, int] | None
    max_regression: float = 0.0
    worst_regression_pair: tuple[int, int] | None = None
    max_guard_violation: float = 0.0
    worst_guard_pair: tuple[int, int] | None = None


class PrimitiveSelfCollisionModel:
    def __init__(
        self,
        model: mujoco.MjModel,
        *,
        collision_model_path: Path | None = None,
        require_compiled_collision: bool = False,
    ) -> None:
        self.model = model
        self.primitives = build_g1_body_primitives(model)
        self.reporting_pairs = build_reporting_pairs(model, self.primitives)
        self.optimization_pairs = build_optimization_pairs(model, self.primitives)
        self.pairs = self.reporting_pairs
        self.collision_model: mujoco.MjModel | None = None
        self.collision_data: mujoco.MjData | None = None
        self.primitive_geom_ids: list[int] = []
        self._distance_fromto = np.zeros(6, dtype=np.float64)
        self.collision_compile_error: str | None = None
        self._try_build_mujoco_collision_model(collision_model_path)
        if require_compiled_collision and self.collision_model is None:
            detail = self.collision_compile_error or "no collision model path was provided"
            raise RuntimeError(
                "The production reflex requires compiled MuJoCo self-collision, "
                f"but the collision model could not be built: {detail}"
            )

    def _try_build_mujoco_collision_model(self, xml_path: Path | None) -> None:
        if xml_path is None:
            return
        xml_path = Path(xml_path).expanduser().resolve()
        if not xml_path.is_file():
            self.collision_compile_error = f"model file does not exist: {xml_path}"
            return
        try:
            spec = mujoco.MjSpec.from_file(str(xml_path))
            for index, primitive in enumerate(self.primitives):
                body = spec.worldbody.find_child(primitive.body_name)
                if body is None:
                    raise KeyError(primitive.body_name)
                geom_name = f"_reflex_self_collision_{index}"
                if primitive.kind == "box":
                    assert primitive.local_pos is not None and primitive.half_size is not None
                    orientation_kwargs: dict[str, list[float]] = {}
                    if primitive.local_rot is not None:
                        quat = np.empty(4, dtype=np.float64)
                        mujoco.mju_mat2Quat(quat, primitive.local_rot.reshape(-1))
                        orientation_kwargs["quat"] = quat.tolist()
                    body.add_geom(
                        name=geom_name,
                        type=mujoco.mjtGeom.mjGEOM_BOX,
                        pos=primitive.local_pos.tolist(),
                        size=primitive.half_size.tolist(),
                        contype=0,
                        conaffinity=0,
                        group=5,
                        density=0,
                        rgba=[1.0, 0.0, 0.0, 0.0],
                        **orientation_kwargs,
                    )
                elif primitive.kind == "capsule":
                    assert primitive.local_a is not None and primitive.local_b is not None
                    body.add_geom(
                        name=geom_name,
                        type=mujoco.mjtGeom.mjGEOM_CAPSULE,
                        fromto=[
                            float(primitive.local_a[0]),
                            float(primitive.local_a[1]),
                            float(primitive.local_a[2]),
                            float(primitive.local_b[0]),
                            float(primitive.local_b[1]),
                            float(primitive.local_b[2]),
                        ],
                        size=[primitive.radius],
                        contype=0,
                        conaffinity=0,
                        group=5,
                        density=0,
                        rgba=[1.0, 0.0, 0.0, 0.0],
                    )
                else:
                    raise ValueError(f"Unknown primitive kind {primitive.kind!r}")

            collision_model = spec.compile()
            if collision_model.nq != self.model.nq or collision_model.nv != self.model.nv:
                raise ValueError(
                    "collision model generalized dimensions do not match the solver model: "
                    f"collision (nq={collision_model.nq}, nv={collision_model.nv}), "
                    f"solver (nq={self.model.nq}, nv={self.model.nv})"
                )
            geom_ids = []
            for index in range(len(self.primitives)):
                geom_id = mujoco.mj_name2id(
                    collision_model,
                    mujoco.mjtObj.mjOBJ_GEOM,
                    f"_reflex_self_collision_{index}",
                )
                if geom_id < 0:
                    raise RuntimeError(f"compiled collision geom {index} is missing")
                geom_ids.append(geom_id)

            self.collision_model = collision_model
            self.collision_data = mujoco.MjData(collision_model)
            self.primitive_geom_ids = geom_ids
        except Exception as exc:
            self.collision_model = None
            self.collision_data = None
            self.primitive_geom_ids = []
            self.collision_compile_error = f"{type(exc).__name__}: {exc}"

    def _sync_collision_data(self, data: mujoco.MjData) -> mujoco.MjData | None:
        if self.collision_model is None or self.collision_data is None:
            return None
        self.collision_data.qpos[:] = data.qpos
        self.collision_data.qvel[:] = 0.0
        # Collision queries consume only qpos-dependent body/geom transforms.
        # The remaining position-stage computations (inertia, tendons and
        # transmissions) cannot affect ``mj_geomDistance`` and are omitted.
        mujoco.mj_kinematics(self.collision_model, self.collision_data)
        return self.collision_data

    def evaluate(
        self,
        data: mujoco.MjData,
        d_safe: float,
        return_distances: bool = False,
        broadphase_margin: float = 0.12,
        pair_indices: list[tuple[int, int]] | None = None,
    ) -> SelfCollisionResult:
        if not return_distances:
            result = self.evaluate_fast(
                data=data,
                d_safe=d_safe,
                broadphase_margin=broadphase_margin,
                pair_indices=pair_indices,
            )
            return SelfCollisionResult(
                penalty=result.penalty,
                min_distance=result.min_distance,
                min_pair=result.min_pair,
                distances=[],
            )

        states = [primitive_state(data, primitive) for primitive in self.primitives]
        penalty = 0.0
        min_distance = float("inf")
        min_pair: tuple[str, str] | None = None
        distances: list[PrimitiveDistance] = []

        pairs = self.pairs if pair_indices is None else pair_indices
        for ia, ib in pairs:
            if pair_indices is None and not broadphase_maybe_close(states[ia], states[ib], broadphase_margin):
                continue
            distance = primitive_distance(states[ia], states[ib], (ia, ib))
            if return_distances:
                distances.append(distance)
            if distance.distance < min_distance:
                min_distance = distance.distance
                min_pair = (
                    self.primitives[ia].body_name,
                    self.primitives[ib].body_name,
                )
            violation = max(0.0, d_safe - distance.distance)
            penalty += violation * violation

        if not self.pairs:
            min_distance = float("nan")
        return SelfCollisionResult(
            penalty=penalty,
            min_distance=min_distance,
            min_pair=min_pair,
            distances=distances,
        )

    def evaluate_fast(
        self,
        data: mujoco.MjData,
        d_safe: float,
        broadphase_margin: float = 0.12,
        pair_indices: list[tuple[int, int]] | None = None,
        reference_distances: dict[tuple[int, int], float] | None = None,
    ) -> SelfCollisionBatchResult:
        collision_data = self._sync_collision_data(data)
        if collision_data is not None:
            return self._evaluate_mujoco_fast(
                collision_data=collision_data,
                d_safe=d_safe,
                broadphase_margin=broadphase_margin,
                pair_indices=pair_indices,
                reference_distances=reference_distances,
            )

        states = [primitive_state(data, primitive) for primitive in self.primitives]
        penalty = 0.0
        min_distance = float("inf")
        min_pair: tuple[str, str] | None = None
        min_pair_index: tuple[int, int] | None = None
        max_regression = 0.0
        worst_regression_pair: tuple[int, int] | None = None
        max_guard_violation = 0.0
        worst_guard_pair: tuple[int, int] | None = None

        pairs = self.pairs if pair_indices is None else pair_indices
        for pair in pairs:
            ia, ib = pair
            if pair_indices is None and not broadphase_maybe_close(states[ia], states[ib], broadphase_margin):
                continue
            distance = primitive_distance_value(states[ia], states[ib])
            if distance < min_distance:
                min_distance = distance
                min_pair = (
                    self.primitives[ia].body_name,
                    self.primitives[ib].body_name,
                )
                min_pair_index = pair
            violation = d_safe - distance
            if violation > 0.0:
                penalty += violation * violation
            if reference_distances is not None:
                reference = reference_distances.get(pair)
                if reference is not None:
                    regression = reference - distance
                    if regression > max_regression:
                        max_regression = regression
                        worst_regression_pair = pair
                    guard_violation = negative_distance_guard_violation(reference, distance)
                    if guard_violation > max_guard_violation:
                        max_guard_violation = guard_violation
                        worst_guard_pair = pair

        if not pairs:
            min_distance = float("nan")
        return SelfCollisionBatchResult(
            penalty=penalty,
            min_distance=min_distance,
            min_pair=min_pair,
            min_pair_index=min_pair_index,
            max_regression=max_regression,
            worst_regression_pair=worst_regression_pair,
            max_guard_violation=max_guard_violation,
            worst_guard_pair=worst_guard_pair,
        )

    def _evaluate_mujoco_fast(
        self,
        collision_data: mujoco.MjData,
        d_safe: float,
        broadphase_margin: float,
        pair_indices: list[tuple[int, int]] | None,
        reference_distances: dict[tuple[int, int], float] | None,
    ) -> SelfCollisionBatchResult:
        assert self.collision_model is not None
        penalty = 0.0
        min_distance = float("inf")
        min_pair: tuple[str, str] | None = None
        min_pair_index: tuple[int, int] | None = None
        max_regression = 0.0
        worst_regression_pair: tuple[int, int] | None = None
        max_guard_violation = 0.0
        worst_guard_pair: tuple[int, int] | None = None

        pairs = self.pairs if pair_indices is None else pair_indices
        for pair in pairs:
            ia, ib = pair
            distance = float(
                mujoco.mj_geomDistance(
                    self.collision_model,
                    collision_data,
                    self.primitive_geom_ids[ia],
                    self.primitive_geom_ids[ib],
                    10.0,
                    None,
                )
            )
            if distance < min_distance:
                min_distance = distance
                min_pair = (
                    self.primitives[ia].body_name,
                    self.primitives[ib].body_name,
                )
                min_pair_index = pair
            violation = d_safe - distance
            if violation > 0.0:
                penalty += violation * violation
            if reference_distances is not None:
                reference = reference_distances.get(pair)
                if reference is not None:
                    regression = reference - distance
                    if regression > max_regression:
                        max_regression = regression
                        worst_regression_pair = pair
                    guard_violation = negative_distance_guard_violation(reference, distance)
                    if guard_violation > max_guard_violation:
                        max_guard_violation = guard_violation
                        worst_guard_pair = pair

        if not pairs:
            min_distance = float("nan")
        return SelfCollisionBatchResult(
            penalty=penalty,
            min_distance=min_distance,
            min_pair=min_pair,
            min_pair_index=min_pair_index,
            max_regression=max_regression,
            worst_regression_pair=worst_regression_pair,
            max_guard_violation=max_guard_violation,
            worst_guard_pair=worst_guard_pair,
        )

    def distance_map(
        self,
        data: mujoco.MjData,
        broadphase_margin: float | None = None,
        pair_indices: list[tuple[int, int]] | None = None,
    ) -> dict[tuple[int, int], float]:
        collision_data = self._sync_collision_data(data)
        if collision_data is not None:
            assert self.collision_model is not None
            distances: dict[tuple[int, int], float] = {}
            pairs = self.pairs if pair_indices is None else pair_indices
            for pair in pairs:
                ia, ib = pair
                if broadphase_margin is not None:
                    center_a = collision_data.geom_xpos[self.primitive_geom_ids[ia]]
                    center_b = collision_data.geom_xpos[self.primitive_geom_ids[ib]]
                    diff = center_a - center_b
                    limit = (
                        self.primitives[ia].broadphase_radius
                        + self.primitives[ib].broadphase_radius
                        + broadphase_margin
                    )
                    if float(np.dot(diff, diff)) > limit * limit:
                        continue
                distances[pair] = float(
                    mujoco.mj_geomDistance(
                        self.collision_model,
                        collision_data,
                        self.primitive_geom_ids[ia],
                        self.primitive_geom_ids[ib],
                        10.0,
                        None,
                    )
                )
            return distances

        states = [primitive_state(data, primitive) for primitive in self.primitives]
        distances: dict[tuple[int, int], float] = {}
        pairs = self.pairs if pair_indices is None else pair_indices
        for pair in pairs:
            ia, ib = pair
            if broadphase_margin is not None and not broadphase_maybe_close(states[ia], states[ib], broadphase_margin):
                continue
            distances[pair] = primitive_distance_value(states[ia], states[ib])
        return distances

    def deterministic_distance_map(
        self,
        data: mujoco.MjData,
        pair_indices: list[tuple[int, int]],
    ) -> dict[tuple[int, int], float]:
        states = [primitive_state(data, primitive) for primitive in self.primitives]
        return {
            pair: primitive_distance_value(states[pair[0]], states[pair[1]])
            for pair in pair_indices
        }

    def pair_distances(
        self,
        data: mujoco.MjData,
        pair_indices: list[tuple[int, int]],
    ) -> list[PrimitiveDistance]:
        collision_data = self._sync_collision_data(data)
        if collision_data is None:
            states = [primitive_state(data, primitive) for primitive in self.primitives]
            return [primitive_distance(states[ia], states[ib], (ia, ib)) for ia, ib in pair_indices]

        assert self.collision_model is not None
        distances: list[PrimitiveDistance] = []
        fromto = self._distance_fromto
        for pair in pair_indices:
            ia, ib = pair
            distance = float(
                mujoco.mj_geomDistance(
                    self.collision_model,
                    collision_data,
                    self.primitive_geom_ids[ia],
                    self.primitive_geom_ids[ib],
                    10.0,
                    fromto,
                )
            )
            distances.append(
                PrimitiveDistance(
                    distance=distance,
                    body_a=self.primitives[ia].body_id,
                    body_b=self.primitives[ib].body_id,
                    point_a=fromto[:3].copy(),
                    point_b=fromto[3:].copy(),
                    pair_index=pair,
                )
            )
        return distances

    def pair_distance_arrays(
        self,
        data: mujoco.MjData,
        pair_indices: list[tuple[int, int]],
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Return distance and witness-point arrays in the requested pair order.

        This is the allocation-light equivalent of :meth:`pair_distances` for
        the hot SQP path.  It calls the same MuJoCo distance routine with the
        same reusable ``fromto`` buffer and preserves every pair's ordering;
        only the Python dataclass and per-point array objects are omitted.
        """

        collision_data = self._sync_collision_data(data)
        if collision_data is None:
            records = self.pair_distances(data, pair_indices)
            return (
                np.asarray([record.distance for record in records], dtype=np.float64),
                np.asarray([record.point_a for record in records], dtype=np.float64),
                np.asarray([record.point_b for record in records], dtype=np.float64),
            )

        assert self.collision_model is not None
        count = len(pair_indices)
        distances = np.empty(count, dtype=np.float64)
        points_a = np.empty((count, 3), dtype=np.float64)
        points_b = np.empty((count, 3), dtype=np.float64)
        fromto = self._distance_fromto
        for row_index, (ia, ib) in enumerate(pair_indices):
            distances[row_index] = mujoco.mj_geomDistance(
                self.collision_model,
                collision_data,
                self.primitive_geom_ids[ia],
                self.primitive_geom_ids[ib],
                10.0,
                fromto,
            )
            points_a[row_index] = fromto[:3]
            points_b[row_index] = fromto[3:]
        return distances, points_a, points_b

def broadphase_maybe_close(
    a: PrimitiveState,
    b: PrimitiveState,
    margin: float,
) -> bool:
    assert a.broadphase_center is not None and b.broadphase_center is not None
    diff = a.broadphase_center - b.broadphase_center
    limit = a.primitive.broadphase_radius + b.primitive.broadphase_radius + margin
    return float(np.dot(diff, diff)) <= limit * limit


def build_g1_body_primitives(model: mujoco.MjModel) -> list[BodyPrimitive]:
    primitives: list[BodyPrimitive] = []

    def body_id(name: str) -> int:
        bid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, name)
        if bid < 0:
            raise KeyError(f"Body {name!r} not found")
        return bid

    def add_box(
        name: str,
        local_pos: tuple[float, float, float],
        half_size: tuple[float, float, float],
        local_rot: tuple[tuple[float, float, float], ...] | None = None,
    ) -> None:
        primitives.append(
            BodyPrimitive(
                body_id=body_id(name),
                body_name=name,
                kind="box",
                local_pos=np.array(local_pos, dtype=np.float64),
                local_rot=(
                    None if local_rot is None else np.array(local_rot, dtype=np.float64)
                ),
                half_size=np.array(half_size, dtype=np.float64),
                broadphase_radius=float(np.linalg.norm(np.array(half_size, dtype=np.float64))),
            )
        )

    def add_capsule_segment(
        name: str,
        end: np.ndarray | tuple[float, float, float],
        radius: float,
        start: tuple[float, float, float] = (0.0, 0.0, 0.0),
        end_trim: float | None = None,
    ) -> None:
        local_a = np.array(start, dtype=np.float64)
        local_b = np.asarray(end, dtype=np.float64).copy()
        axis = local_b - local_a
        length = float(np.linalg.norm(axis))
        if length > 1e-9:
            trim = radius if end_trim is None else end_trim
            trim = min(trim, 0.35 * length)
            direction = axis / length
            local_a = local_a + trim * direction
            local_b = local_b - trim * direction
        primitives.append(
            BodyPrimitive(
                body_id=body_id(name),
                body_name=name,
                kind="capsule",
                local_a=local_a,
                local_b=local_b,
                radius=radius,
                broadphase_radius=0.5 * float(np.linalg.norm(local_b - local_a)) + radius,
            )
        )

    def add_capsule(
        name: str,
        child_name: str,
        radius: float,
        start: tuple[float, float, float] = (0.0, 0.0, 0.0),
        end_trim: float | None = None,
    ) -> None:
        add_capsule_segment(name, model.body_pos[body_id(child_name)], radius, start, end_trim)

    add_box("pelvis", (0.0, 0.0, -0.085), (0.080, 0.075, 0.060))

    for side in ("left", "right"):
        sign = 1.0 if side == "left" else -1.0
        add_box(
            f"{side}_hip_roll_link",
            MERGED_HIP_COLLISION_LOCAL_POS,
            MERGED_HIP_COLLISION_HALF_SIZE,
            MERGED_HIP_COLLISION_LOCAL_ROTATION,
        )
        add_capsule(f"{side}_knee_link", f"{side}_ankle_pitch_link", 0.031)
        add_capsule(f"{side}_ankle_pitch_link", f"{side}_ankle_roll_link", 0.018)
        add_box(f"{side}_ankle_roll_link", (0.050, 0.0, -0.025), (0.090, 0.037, 0.018))

        add_capsule_segment(
            f"{side}_shoulder_roll_link",
            (0.015783, 0.00624 * sign, -0.183718),
            0.032,
            end_trim=0.0,
        )
        add_capsule_segment(
            f"{side}_elbow_link",
            (0.138, 0.00188791 * sign, -0.010),
            0.025,
        )
        # One box covers the wrist-yaw housing and the rubber hand attached to it.
        # Keep the source planner aligned with the standalone ReflexAPI's
        # reviewed boxing-glove proxy.
        add_box(f"{side}_wrist_yaw_link", (0.115, 0.0, 0.0), (0.130, 0.0675, 0.065))

    add_box("torso_link", (0.004, 0.0, 0.233), (0.090, 0.109, 0.245))
    return primitives


def build_reporting_pairs(
    model: mujoco.MjModel,
    primitives: list[BodyPrimitive],
) -> list[tuple[int, int]]:
    return build_named_primitive_pairs(primitives, REPORTING_PAIR_NAMES)


def build_optimization_pairs(
    model: mujoco.MjModel,
    primitives: list[BodyPrimitive],
) -> list[tuple[int, int]]:
    return build_named_primitive_pairs(primitives, OPTIMIZATION_PAIR_NAMES)


def build_named_primitive_pairs(
    primitives: list[BodyPrimitive],
    pair_names: frozenset[tuple[str, str]],
) -> list[tuple[int, int]]:
    primitive_index = {primitive.body_name: index for index, primitive in enumerate(primitives)}
    missing = sorted({name for pair in pair_names for name in pair if name not in primitive_index})
    if missing:
        raise KeyError(f"Collision pair allowlist references unknown primitives: {missing}")
    pairs = [
        (ia, ib)
        for ia in range(len(primitives))
        for ib in range(ia + 1, len(primitives))
        if (primitives[ia].body_name, primitives[ib].body_name) in pair_names
    ]
    if len(pairs) != len(pair_names):
        raise ValueError("Collision pair allowlist contains reversed or duplicate pairs")
    return pairs


def build_primitive_pairs(
    model: mujoco.MjModel,
    primitives: list[BodyPrimitive],
    skip_predicate=None,
) -> list[tuple[int, int]]:
    if skip_predicate is None:
        skip_predicate = lambda _model, _body_a, _body_b: False
    pairs: list[tuple[int, int]] = []
    for ia in range(len(primitives)):
        for ib in range(ia + 1, len(primitives)):
            body_a = primitives[ia].body_id
            body_b = primitives[ib].body_id
            if skip_predicate(model, body_a, body_b):
                continue
            pairs.append((ia, ib))
    return pairs


def is_ancestor(model: mujoco.MjModel, ancestor: int, body_id: int) -> bool:
    current = body_id
    while current != 0:
        current = int(model.body_parentid[current])
        if current == ancestor:
            return True
    return ancestor == 0


def primitive_state(data: mujoco.MjData, primitive: BodyPrimitive) -> PrimitiveState:
    body_pos = data.xpos[primitive.body_id].copy()
    body_rot = data.xmat[primitive.body_id].reshape(3, 3).copy()
    if primitive.kind == "capsule":
        assert primitive.local_a is not None and primitive.local_b is not None
        a = body_pos + body_rot @ primitive.local_a
        b = body_pos + body_rot @ primitive.local_b
        return PrimitiveState(
            primitive=primitive,
            body_pos=body_pos,
            body_rot=body_rot,
            a=a,
            b=b,
            radius=primitive.radius,
            broadphase_center=0.5 * (a + b),
        )
    if primitive.kind == "box":
        assert primitive.local_pos is not None and primitive.half_size is not None
        center = body_pos + body_rot @ primitive.local_pos
        box_rot = body_rot
        if primitive.local_rot is not None:
            box_rot = body_rot @ primitive.local_rot
        return PrimitiveState(
            primitive=primitive,
            body_pos=body_pos,
            body_rot=box_rot,
            center=center,
            half_size=primitive.half_size,
            vertices=box_vertices_array(center, box_rot, primitive.half_size),
            broadphase_center=center,
        )
    raise ValueError(f"Unknown primitive kind {primitive.kind!r}")


def negative_distance_guard_violation(reference: float, distance: float) -> float:
    if reference >= 0.0 and distance >= 0.0:
        return 0.0
    target = min(reference, 0.0)
    return max(0.0, target - distance)


def primitive_distance(
    a: PrimitiveState,
    b: PrimitiveState,
    pair_index: tuple[int, int],
) -> PrimitiveDistance:
    if a.primitive.kind == "capsule" and b.primitive.kind == "capsule":
        distance, pa, pb = capsule_capsule_distance(a, b)
    elif a.primitive.kind == "box" and b.primitive.kind == "box":
        distance, pa, pb = box_box_distance(a, b)
    elif a.primitive.kind == "capsule" and b.primitive.kind == "box":
        distance, pa, pb = capsule_box_distance(a, b)
    elif a.primitive.kind == "box" and b.primitive.kind == "capsule":
        distance, pb, pa = capsule_box_distance(b, a)
    else:
        raise ValueError("Unsupported primitive pair")
    return PrimitiveDistance(
        distance=distance,
        body_a=a.primitive.body_id,
        body_b=b.primitive.body_id,
        point_a=pa,
        point_b=pb,
        pair_index=pair_index,
    )


def primitive_distance_value(a: PrimitiveState, b: PrimitiveState) -> float:
    if a.primitive.kind == "capsule" and b.primitive.kind == "capsule":
        return capsule_capsule_distance_value(a, b)
    if a.primitive.kind == "box" and b.primitive.kind == "box":
        return box_box_distance_value(a, b)
    if a.primitive.kind == "capsule" and b.primitive.kind == "box":
        return capsule_box_distance_value(a, b)
    if a.primitive.kind == "box" and b.primitive.kind == "capsule":
        return capsule_box_distance_value(b, a)
    raise ValueError("Unsupported primitive pair")


def primitive_broadphase_center(state: PrimitiveState) -> np.ndarray:
    if state.broadphase_center is not None:
        return state.broadphase_center
    if state.primitive.kind == "capsule":
        assert state.a is not None and state.b is not None
        return 0.5 * (state.a + state.b)
    assert state.center is not None
    return state.center


def capsule_capsule_distance(a: PrimitiveState, b: PrimitiveState) -> tuple[float, np.ndarray, np.ndarray]:
    assert a.a is not None and a.b is not None and b.a is not None and b.b is not None
    pa, pb = closest_segment_segment(a.a, a.b, b.a, b.b)
    return float(np.linalg.norm(pb - pa) - a.radius - b.radius), pa, pb


def capsule_capsule_distance_value(a: PrimitiveState, b: PrimitiveState) -> float:
    assert a.a is not None and a.b is not None and b.a is not None and b.b is not None
    dist_sq = segment_segment_distance_squared(a.a, a.b, b.a, b.b)
    return math.sqrt(max(0.0, dist_sq)) - a.radius - b.radius


def capsule_box_distance(capsule: PrimitiveState, box: PrimitiveState) -> tuple[float, np.ndarray, np.ndarray]:
    assert capsule.a is not None and capsule.b is not None
    assert box.center is not None and box.half_size is not None
    best_distance = float("inf")
    best_capsule_point = capsule.a
    best_box_point = box.center

    for t in (0.0, 0.5, 1.0):
        point = capsule.a + t * (capsule.b - capsule.a)
        signed, closest = point_obb_signed_distance(point, box.center, box.body_rot, box.half_size)
        distance = signed - capsule.radius
        if distance < best_distance:
            best_distance = distance
            best_capsule_point = point
            best_box_point = closest

    vertices = box.vertices if box.vertices is not None else box_vertices_array(box.center, box.body_rot, box.half_size)
    for vertex in vertices:
        closest = closest_point_on_segment(vertex, capsule.a, capsule.b)
        distance = float(np.linalg.norm(vertex - closest) - capsule.radius)
        if distance < best_distance:
            best_distance = distance
            best_capsule_point = closest
            best_box_point = vertex

    return best_distance, best_capsule_point, best_box_point


def capsule_box_distance_value(capsule: PrimitiveState, box: PrimitiveState) -> float:
    assert capsule.a is not None and capsule.b is not None
    assert box.center is not None and box.half_size is not None
    best_distance = float("inf")

    axis = capsule.b - capsule.a
    for t in (0.0, 0.5, 1.0):
        point = capsule.a + t * axis
        signed = point_obb_signed_distance_value(point, box.center, box.body_rot, box.half_size)
        distance = signed - capsule.radius
        if distance < best_distance:
            best_distance = distance

    vertices = box.vertices if box.vertices is not None else box_vertices_array(box.center, box.body_rot, box.half_size)
    for vertex in vertices:
        distance_sq = point_segment_distance_squared(vertex, capsule.a, capsule.b)
        distance = math.sqrt(max(0.0, distance_sq)) - capsule.radius
        if distance < best_distance:
            best_distance = distance

    return best_distance


def box_box_distance(a: PrimitiveState, b: PrimitiveState) -> tuple[float, np.ndarray, np.ndarray]:
    assert a.center is not None and a.half_size is not None
    assert b.center is not None and b.half_size is not None
    best_distance = float("inf")
    best_a = a.center
    best_b = b.center

    a_vertices = a.vertices if a.vertices is not None else box_vertices_array(a.center, a.body_rot, a.half_size)
    b_vertices = b.vertices if b.vertices is not None else box_vertices_array(b.center, b.body_rot, b.half_size)

    for vertex in a_vertices:
        signed, closest = point_obb_signed_distance(vertex, b.center, b.body_rot, b.half_size)
        if signed < best_distance:
            best_distance = signed
            best_a = vertex
            best_b = closest

    for vertex in b_vertices:
        signed, closest = point_obb_signed_distance(vertex, a.center, a.body_rot, a.half_size)
        if signed < best_distance:
            best_distance = signed
            best_a = closest
            best_b = vertex

    return best_distance, best_a, best_b


def box_box_distance_value(a: PrimitiveState, b: PrimitiveState) -> float:
    assert a.center is not None and a.half_size is not None
    assert b.center is not None and b.half_size is not None
    best_distance = float("inf")

    a_vertices = a.vertices if a.vertices is not None else box_vertices_array(a.center, a.body_rot, a.half_size)
    b_vertices = b.vertices if b.vertices is not None else box_vertices_array(b.center, b.body_rot, b.half_size)

    for vertex in a_vertices:
        signed = point_obb_signed_distance_value(vertex, b.center, b.body_rot, b.half_size)
        if signed < best_distance:
            best_distance = signed

    for vertex in b_vertices:
        signed = point_obb_signed_distance_value(vertex, a.center, a.body_rot, a.half_size)
        if signed < best_distance:
            best_distance = signed

    return best_distance


def point_obb_signed_distance(
    point: np.ndarray,
    center: np.ndarray,
    rot: np.ndarray,
    half_size: np.ndarray,
) -> tuple[float, np.ndarray]:
    local = rot.T @ (point - center)
    delta = np.abs(local) - half_size
    outside = np.maximum(delta, 0.0)
    outside_distance = float(np.linalg.norm(outside))
    clamped = np.clip(local, -half_size, half_size)
    closest = center + rot @ clamped
    if outside_distance > 0.0:
        return outside_distance, closest

    axis = int(np.argmin(half_size - np.abs(local)))
    face_local = local.copy()
    face_local[axis] = half_size[axis] if local[axis] >= 0.0 else -half_size[axis]
    closest = center + rot @ face_local
    inside_distance = -float(half_size[axis] - abs(local[axis]))
    return inside_distance, closest


def point_obb_signed_distance_value(
    point: np.ndarray,
    center: np.ndarray,
    rot: np.ndarray,
    half_size: np.ndarray,
) -> float:
    local = rot.T @ (point - center)
    delta = np.abs(local) - half_size
    outside = np.maximum(delta, 0.0)
    outside_sq = float(np.dot(outside, outside))
    if outside_sq > 0.0:
        return math.sqrt(outside_sq)
    return -float(np.min(half_size - np.abs(local)))


def box_vertices_array(center: np.ndarray, rot: np.ndarray, half_size: np.ndarray) -> np.ndarray:
    return center + (BOX_VERTEX_SIGNS * half_size) @ rot.T


def box_vertices(center: np.ndarray, rot: np.ndarray, half_size: np.ndarray) -> list[np.ndarray]:
    return [vertex for vertex in box_vertices_array(center, rot, half_size)]


def closest_point_on_segment(point: np.ndarray, a: np.ndarray, b: np.ndarray) -> np.ndarray:
    ab = b - a
    denom = float(np.dot(ab, ab))
    if denom < 1e-12:
        return a.copy()
    t = float(np.clip(np.dot(point - a, ab) / denom, 0.0, 1.0))
    return a + t * ab


def closest_segment_segment(
    p1: np.ndarray,
    q1: np.ndarray,
    p2: np.ndarray,
    q2: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    d1 = q1 - p1
    d2 = q2 - p2
    r = p1 - p2
    a = float(np.dot(d1, d1))
    e = float(np.dot(d2, d2))
    f = float(np.dot(d2, r))

    if a <= 1e-12 and e <= 1e-12:
        return p1.copy(), p2.copy()
    if a <= 1e-12:
        s = 0.0
        t = np.clip(f / e, 0.0, 1.0)
    else:
        c = float(np.dot(d1, r))
        if e <= 1e-12:
            t = 0.0
            s = np.clip(-c / a, 0.0, 1.0)
        else:
            b = float(np.dot(d1, d2))
            denom = a * e - b * b
            if denom != 0.0:
                s = np.clip((b * f - c * e) / denom, 0.0, 1.0)
            else:
                s = 0.0
            tnom = b * s + f
            if tnom < 0.0:
                t = 0.0
                s = np.clip(-c / a, 0.0, 1.0)
            elif tnom > e:
                t = 1.0
                s = np.clip((b - c) / a, 0.0, 1.0)
            else:
                t = tnom / e

    return p1 + s * d1, p2 + t * d2


def point_segment_distance_squared(point: np.ndarray, a: np.ndarray, b: np.ndarray) -> float:
    ab = b - a
    denom = float(np.dot(ab, ab))
    if denom < 1e-12:
        diff = point - a
        return float(np.dot(diff, diff))
    t = float(np.clip(np.dot(point - a, ab) / denom, 0.0, 1.0))
    closest = a + t * ab
    diff = point - closest
    return float(np.dot(diff, diff))


def segment_segment_distance_squared(
    p1: np.ndarray,
    q1: np.ndarray,
    p2: np.ndarray,
    q2: np.ndarray,
) -> float:
    d1 = q1 - p1
    d2 = q2 - p2
    r = p1 - p2
    a = float(np.dot(d1, d1))
    e = float(np.dot(d2, d2))
    f = float(np.dot(d2, r))

    if a <= 1e-12 and e <= 1e-12:
        diff = p1 - p2
        return float(np.dot(diff, diff))
    if a <= 1e-12:
        s = 0.0
        t = float(np.clip(f / e, 0.0, 1.0))
    else:
        c = float(np.dot(d1, r))
        if e <= 1e-12:
            t = 0.0
            s = float(np.clip(-c / a, 0.0, 1.0))
        else:
            b = float(np.dot(d1, d2))
            denom = a * e - b * b
            if abs(denom) > 1e-12:
                s = float(np.clip((b * f - c * e) / denom, 0.0, 1.0))
            else:
                s = 0.0
            tnom = b * s + f
            if tnom < 0.0:
                t = 0.0
                s = float(np.clip(-c / a, 0.0, 1.0))
            elif tnom > e:
                t = 1.0
                s = float(np.clip((b - c) / a, 0.0, 1.0))
            else:
                t = float(tnom / e)

    closest_1 = p1 + s * d1
    closest_2 = p2 + t * d2
    diff = closest_1 - closest_2
    return float(np.dot(diff, diff))
