"""Canonical visual-surface candidate points for standalone hard support.

The local offsets below were sampled from the full-resolution G1 visual meshes
used by :mod:`main` (including the reviewed large boxing-glove overlay).  The
offsets are frozen in this standalone package and require no visual assets at
runtime.
"""

from __future__ import annotations

from dataclasses import dataclass

import mujoco
import numpy as np


DEFAULT_STANCE_HEIGHT_TOLERANCE = 0.05


@dataclass(frozen=True)
class CandidateStancePoint:
    """One fixed point expressed in its attached MuJoCo body frame."""

    name: str
    body_name: str
    local_position: tuple[float, float, float]


@dataclass(frozen=True)
class ResolvedStancePoint:
    """A candidate point resolved against one concrete MuJoCo model."""

    name: str
    body_name: str
    body_id: int
    local_position: np.ndarray


@dataclass(frozen=True)
class StancePointSelection:
    """Candidate positions and the subset selected as first-order support."""

    down_direction_world: np.ndarray
    candidate_points: tuple[ResolvedStancePoint, ...]
    candidate_positions_world: np.ndarray
    downward_projections: np.ndarray
    selected_indices: tuple[int, ...]
    height_tolerance: float

    @property
    def selected_points(self) -> tuple[ResolvedStancePoint, ...]:
        return tuple(self.candidate_points[index] for index in self.selected_indices)

    @property
    def selected_positions_world(self) -> np.ndarray:
        return self.candidate_positions_world[np.asarray(self.selected_indices, dtype=np.int32)]


# Geometry provenance (full visual mesh, converted to ReflexAPI body-local metres):
# - head_top: maximum torso/head visual-mesh z;
# - *_glove_tip: maximum reviewed glove visual-mesh x;
# - *_elbow: rear elbow-shell apex (minimum elbow-link x, not the distal wrist joint);
# - pelvis_rear: rear pelvis-shell apex (minimum pelvis x);
# - *_knee: front knee-shell apex (maximum knee-link x);
# - foot toe/heel: x-extrema within 1 mm of the visual sole's minimum z.
CANDIDATE_STANCE_POINTS: tuple[CandidateStancePoint, ...] = (
    # The full viewer torso origin is 1 cm below the ReflexAPI truth-holder
    # torso origin.  0.48657 m in the visual frame is therefore 0.47657 m in
    # the API frame; both denote the same physical head-top surface point.
    CandidateStancePoint("head_top", "torso_link", (0.00497, 0.00002, 0.47657)),
    CandidateStancePoint("left_glove_tip", "left_wrist_yaw_link", (0.25500, 0.00712, 0.00234)),
    CandidateStancePoint("right_glove_tip", "right_wrist_yaw_link", (0.25500, -0.00712, 0.00234)),
    CandidateStancePoint("left_elbow", "left_elbow_link", (-0.02978, 0.02271, 0.00164)),
    CandidateStancePoint("right_elbow", "right_elbow_link", (-0.02978, -0.02271, 0.00164)),
    CandidateStancePoint("pelvis_rear", "pelvis", (-0.05813, 0.00002, -0.07816)),
    CandidateStancePoint("left_knee", "left_knee_link", (0.06392, 0.00004, 0.01656)),
    CandidateStancePoint("right_knee", "right_knee_link", (0.06392, -0.00004, 0.01656)),
    CandidateStancePoint("left_toe", "left_ankle_roll_link", (0.14236, 0.00005, -0.03459)),
    CandidateStancePoint("left_heel", "left_ankle_roll_link", (-0.06584, 0.00005, -0.03462)),
    CandidateStancePoint("right_toe", "right_ankle_roll_link", (0.14236, -0.00005, -0.03459)),
    CandidateStancePoint("right_heel", "right_ankle_roll_link", (-0.06584, -0.00005, -0.03462)),
)


def normalize_down_direction(down_direction_world: np.ndarray) -> np.ndarray:
    direction = np.asarray(down_direction_world, dtype=np.float64)
    if direction.shape != (3,):
        raise ValueError(f"down_direction_world must have shape (3,), got {direction.shape}")
    if not np.all(np.isfinite(direction)):
        raise ValueError("down_direction_world must be finite")
    norm = float(np.linalg.norm(direction))
    if norm < 1e-9:
        raise ValueError("down_direction_world must be non-zero")
    return direction / norm


def resolve_candidate_stance_points(
    model: mujoco.MjModel,
    candidates: tuple[CandidateStancePoint, ...] = CANDIDATE_STANCE_POINTS,
) -> tuple[ResolvedStancePoint, ...]:
    resolved: list[ResolvedStancePoint] = []
    names: set[str] = set()
    for candidate in candidates:
        if candidate.name in names:
            raise ValueError(f"Duplicate candidate stance-point name {candidate.name!r}")
        names.add(candidate.name)
        body_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, candidate.body_name)
        if body_id <= 0:
            raise KeyError(
                f"Candidate stance point {candidate.name!r} references missing body "
                f"{candidate.body_name!r}"
            )
        local_position = np.asarray(candidate.local_position, dtype=np.float64)
        if local_position.shape != (3,) or not np.all(np.isfinite(local_position)):
            raise ValueError(f"Invalid local position for candidate stance point {candidate.name!r}")
        resolved.append(
            ResolvedStancePoint(
                name=candidate.name,
                body_name=candidate.body_name,
                body_id=int(body_id),
                local_position=local_position.copy(),
            )
        )
    if not resolved:
        raise ValueError("At least one candidate stance point is required")
    return tuple(resolved)


def candidate_positions_world(
    data: mujoco.MjData,
    candidates: tuple[ResolvedStancePoint, ...],
) -> np.ndarray:
    positions = np.empty((len(candidates), 3), dtype=np.float64)
    for index, candidate in enumerate(candidates):
        rotation = data.xmat[candidate.body_id].reshape(3, 3)
        positions[index] = data.xpos[candidate.body_id] + rotation @ candidate.local_position
    return positions


def select_stance_points(
    data: mujoco.MjData,
    candidates: tuple[ResolvedStancePoint, ...],
    down_direction_world: np.ndarray,
    *,
    height_tolerance: float = DEFAULT_STANCE_HEIGHT_TOLERANCE,
) -> StancePointSelection:
    if not np.isfinite(height_tolerance) or height_tolerance < 0.0:
        raise ValueError("height_tolerance must be finite and non-negative")
    down = normalize_down_direction(down_direction_world)
    positions = candidate_positions_world(data, candidates)
    projections = positions @ down
    lowest_projection = float(np.max(projections))
    height_above_lowest = lowest_projection - projections
    selected = tuple(
        int(index)
        for index in np.flatnonzero(height_above_lowest <= height_tolerance + 1e-12)
    )
    if not selected:
        raise RuntimeError("Stance-point selection unexpectedly produced an empty set")
    return StancePointSelection(
        down_direction_world=down,
        candidate_points=candidates,
        candidate_positions_world=positions,
        downward_projections=projections,
        selected_indices=selected,
        height_tolerance=float(height_tolerance),
    )
