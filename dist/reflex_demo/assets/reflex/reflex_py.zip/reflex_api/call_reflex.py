from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict
from pathlib import Path

import numpy as np

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from reflex_api.config import (
        RETREAT_REFERENCE_CONTACT_RELATIVE_TO_PHYSICAL_COM,
        RETREAT_REFERENCE_FRAMES,
    )
    from reflex_api.core import ReflexComposition, ReflexCore, ReflexResult
    from reflex_api.hard_support import HardSupportCore
    from reflex_api.velocity_conditioning import VelocityConditioner
    from reflex_api.profiles import (
        HARD_SUPPORT_W_BODY,
        HARD_SUPPORT_W_RETREAT,
        PROFILE_HARD_SUPPORT,
        PROFILE_HARD_SUPPORT_HAND_LOCAL,
        hard_support_hand_local_config,
        PROFILES,
        normalize_profile,
    )
else:
    from .config import (
        RETREAT_REFERENCE_CONTACT_RELATIVE_TO_PHYSICAL_COM,
        RETREAT_REFERENCE_FRAMES,
    )
    from .core import ReflexComposition, ReflexCore, ReflexResult
    from .hard_support import HardSupportCore
    from .velocity_conditioning import VelocityConditioner
    from .profiles import (
        HARD_SUPPORT_W_BODY,
        HARD_SUPPORT_W_RETREAT,
        PROFILE_HARD_SUPPORT,
        PROFILE_HARD_SUPPORT_HAND_LOCAL,
        hard_support_hand_local_config,
        PROFILES,
        normalize_profile,
    )


class ReflexAPI:
    """Initialized, stateful wrapper; one instance should be reused across calls."""

    def __init__(
        self,
        *,
        profile: str = PROFILE_HARD_SUPPORT,
        w_retreat: float | None = None,
        retreat_reference_frame: str | None = None,
        w_body: float | None = None,
        max_joint_delta: float | None = None,
        waist_max_joint_delta: float | None = None,
        stance_enabled: bool = False,
    ) -> None:
        self._profile = normalize_profile(profile)
        guided = self._profile == PROFILE_HARD_SUPPORT_HAND_LOCAL
        if guided and w_retreat is not None and float(w_retreat) != 0.0:
            raise ValueError("Guided uses a soft shortfall, not a linear w_retreat override")
        if guided and retreat_reference_frame not in (None, RETREAT_REFERENCE_CONTACT_RELATIVE_TO_PHYSICAL_COM):
            raise ValueError("Guided requires contact-relative-to-physical-CoM retreat")
        if self._profile in (PROFILE_HARD_SUPPORT, PROFILE_HARD_SUPPORT_HAND_LOCAL):
            resolved_w_retreat = (
                (0.0 if guided else HARD_SUPPORT_W_RETREAT)
                if w_retreat is None else float(w_retreat)
            )
            if not np.isfinite(resolved_w_retreat) or resolved_w_retreat < 0.0:
                raise ValueError("w_retreat must be finite and nonnegative")
            resolved_retreat_reference_frame = (
                RETREAT_REFERENCE_CONTACT_RELATIVE_TO_PHYSICAL_COM
                if retreat_reference_frame is None
                else str(retreat_reference_frame)
            )
            if resolved_retreat_reference_frame not in RETREAT_REFERENCE_FRAMES:
                raise ValueError(
                    "retreat_reference_frame must be one of "
                    f"{RETREAT_REFERENCE_FRAMES}, got "
                    f"{resolved_retreat_reference_frame!r}"
                )
            resolved_w_body = (
                HARD_SUPPORT_W_BODY if w_body is None else float(w_body)
            )
            resolved_max_joint_delta = (
                1.0 if max_joint_delta is None else float(max_joint_delta)
            )
            resolved_waist_max_joint_delta = (
                1.0
                if waist_max_joint_delta is None
                else float(waist_max_joint_delta)
            )
        else:
            if w_retreat is not None and float(w_retreat) != 1.0:
                raise ValueError(
                    "w_retreat overrides are supported only by the hard_support profile"
                )
            resolved_w_retreat = 1.0
            if (
                retreat_reference_frame is not None
                and str(retreat_reference_frame)
                != RETREAT_REFERENCE_CONTACT_RELATIVE_TO_PHYSICAL_COM
            ):
                raise ValueError(
                    "retreat_reference_frame overrides are supported only by "
                    "the hard_support profile"
                )
            resolved_retreat_reference_frame = (
                RETREAT_REFERENCE_CONTACT_RELATIVE_TO_PHYSICAL_COM
            )
            resolved_w_body = 0.3 if w_body is None else float(w_body)
            resolved_max_joint_delta = (
                0.3 if max_joint_delta is None else float(max_joint_delta)
            )
            resolved_waist_max_joint_delta = (
                0.4
                if waist_max_joint_delta is None
                else float(waist_max_joint_delta)
            )
        self._core = ReflexCore(
            w_body=resolved_w_body,
            max_joint_delta=resolved_max_joint_delta,
            waist_max_joint_delta=resolved_waist_max_joint_delta,
            stance_enabled=stance_enabled,
        )
        self._hard_support_core = (
            HardSupportCore(
                self._core.model,
                w_retreat=resolved_w_retreat,
                retreat_reference_frame=resolved_retreat_reference_frame,
                w_body=resolved_w_body,
                max_joint_delta=resolved_max_joint_delta,
                waist_max_joint_delta=resolved_waist_max_joint_delta,
                config=(hard_support_hand_local_config(
                    self._core.model, w_body=resolved_w_body,
                    max_joint_delta=resolved_max_joint_delta,
                    waist_max_joint_delta=resolved_waist_max_joint_delta,
                ) if guided else None),
            )
            if self._profile in (PROFILE_HARD_SUPPORT, PROFILE_HARD_SUPPORT_HAND_LOCAL)
            else None
        )
        self._velocity_conditioner = VelocityConditioner(self._core.model) if guided else None

    @property
    def profile(self) -> str:
        return self._profile

    @property
    def nq(self) -> int:
        return self._core.model.nq

    @property
    def nv(self) -> int:
        return self._core.model.nv

    @property
    def joint_names(self) -> tuple[str, ...]:
        return tuple(self._core.joint_names)

    @property
    def joint_qpos_addresses(self) -> np.ndarray:
        return self._core.joint_qpos_addr.copy()

    @property
    def joint_dof_addresses(self) -> np.ndarray:
        return self._core.joint_dof_addr.copy()

    def body_com_local(self, body: str | int) -> np.ndarray:
        return self._core.body_com_local(body)

    def contact_point_local(
        self,
        qpos: np.ndarray,
        contact_body: str | int,
        contact_point_world: np.ndarray,
    ) -> np.ndarray:
        """Convert a measured world contact point into the solver body's local frame."""

        return self._core.contact_point_local(qpos, contact_body, contact_point_world)

    def surface_contact_point_local(
        self,
        qpos: np.ndarray,
        contact_body: str | int,
        retreat_normal_world: np.ndarray,
    ) -> np.ndarray:
        """Return the struck-side surface point for a synthetic point force."""

        return self._core.surface_contact_point_local(qpos, contact_body, retreat_normal_world)

    def detect_stance(self, qRef: np.ndarray) -> tuple[int, ...]:
        return self._core.detect_stance(qRef)

    def compose_reflex(
        self,
        qRef: np.ndarray,
        dqReflex: np.ndarray,
        stance_body_ids: tuple[int, ...] | list[int],
    ) -> ReflexComposition:
        return self._core.compose_reflex(qRef, dqReflex, stance_body_ids)

    def call_reflex(
        self,
        qRef: np.ndarray,
        qpos0: np.ndarray,
        contact_body: str | int,
        contact_point_local: np.ndarray,
        retreat_normal_world: np.ndarray,
        *,
        qvel0: np.ndarray | None = None,
        velocity_qpos0: np.ndarray | None = None,
        projected_gravity: np.ndarray | None = None,
        down_direction_world: np.ndarray | None = None,
    ) -> ReflexResult:
        """One planning pose to one endpoint; guided optionally uses qvel0.

        qvel0 keeps MuJoCo nv layout: root linear entries are ignored (fill zero),
        followed by root-local angular and joint velocities. No root linear
        velocity measurement is required. None preserves the fixed preference;
        explicit zero activates the guided rest cap. It is not a trajectory.

        velocity_qpos0 optionally supplies the current measured pose for the
        velocity Jacobian. qpos0 remains the QP start (which can be a previous
        planned target). Omitting it evaluates velocity at qpos0 as before.
        """
        down_direction = _select_down_direction(
            projected_gravity=projected_gravity,
            down_direction_world=down_direction_world,
        )
        if velocity_qpos0 is not None and qvel0 is None:
            raise ValueError("velocity_qpos0 requires qvel0")
        if qvel0 is not None:
            if self._velocity_conditioner is None:
                raise ValueError("qvel0 velocity conditioning requires profile='hard_support_hand_local'")
            return self._velocity_conditioner.solve(
                self._hard_support_core, qvel0=qvel0, velocity_qpos0=velocity_qpos0,
                qref=qRef, qpos0=qpos0,
                contact_body=contact_body, contact_point_local=contact_point_local,
                retreat_normal_world=retreat_normal_world, down_direction_world=down_direction,
            )
        if self._hard_support_core is not None:
            assert self._hard_support_core is not None
            return self._hard_support_core.solve(
                qref=qRef,
                qpos0=qpos0,
                contact_body=contact_body,
                contact_point_local=contact_point_local,
                retreat_normal_world=retreat_normal_world,
                down_direction_world=down_direction,
            )
        return self._core.solve(
            qref=qRef,
            qpos0=qpos0,
            contact_body=contact_body,
            contact_point_local=contact_point_local,
            retreat_normal_world=retreat_normal_world,
        )


_DEFAULT_API: ReflexAPI | None = None


def initialize() -> ReflexAPI:
    global _DEFAULT_API
    if _DEFAULT_API is None:
        _DEFAULT_API = ReflexAPI()
    return _DEFAULT_API


def _select_down_direction(
    *,
    projected_gravity: np.ndarray | None,
    down_direction_world: np.ndarray | None,
) -> np.ndarray | None:
    """Select the public down-vector input without changing its coordinates.

    ``HardSupportCore`` validates and normalizes the selected vector. In
    particular, ``projected_gravity`` is interpreted directly in the solver
    coordinate system; no local-to-world rotation is estimated or applied.
    """

    if projected_gravity is not None and down_direction_world is not None:
        raise ValueError(
            "projected_gravity and down_direction_world are mutually exclusive"
        )
    return projected_gravity if projected_gravity is not None else down_direction_world


def call_reflex(
    qRef: np.ndarray,
    qpos0: np.ndarray,
    contact_body: str | int,
    contact_point_local: np.ndarray,
    retreat_normal_world: np.ndarray,
    *,
    projected_gravity: np.ndarray | None = None,
    down_direction_world: np.ndarray | None = None,
) -> ReflexResult:
    """Run the cached default hard-support API.

    ``projected_gravity`` is the preferred real-robot input. Its components are
    interpreted directly in the solver coordinate system and normalized as the
    downward direction; no coordinate rotation is applied. For an explicit
    hard-support call, that direction also drives MuJoCo gravity and the
    q0-frozen static-support effort calculation while preserving the bundled
    gravity magnitude. The prior model gravity is restored before the call
    exits. The historical ``down_direction_world`` name remains a
    mutually-exclusive compatibility alias. If neither is supplied, the model
    gravity direction is used without rewriting it.
    """

    return initialize().call_reflex(
        qRef=qRef,
        qpos0=qpos0,
        contact_body=contact_body,
        contact_point_local=contact_point_local,
        retreat_normal_world=retreat_normal_world,
        projected_gravity=projected_gravity,
        down_direction_world=down_direction_world,
    )


def _load_array(path: Path, preferred_key: str) -> np.ndarray:
    value = np.load(path, allow_pickle=False)
    if isinstance(value, np.lib.npyio.NpzFile):
        with value:
            if preferred_key in value.files:
                return np.asarray(value[preferred_key], dtype=np.float64)
            if len(value.files) == 1:
                return np.asarray(value[value.files[0]], dtype=np.float64)
            raise KeyError(f"{path} must contain {preferred_key!r} or exactly one array")
    return np.asarray(value, dtype=np.float64)


def _json_payload(result: ReflexResult) -> dict:
    payload = asdict(result)
    for key, value in list(payload.items()):
        if isinstance(value, np.ndarray):
            payload[key] = value.tolist()
    return payload


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Standalone whole-body reflex API")
    parser.add_argument(
        "--profile",
        choices=PROFILES,
        default=PROFILE_HARD_SUPPORT,
        help="Planner profile (default: accepted strong hard-support profile)",
    )
    parser.add_argument(
        "--w-retreat",
        type=float,
        default=None,
        help=(
            "Override the hard-support CoM-relative retreat weight "
            f"(default: {HARD_SUPPORT_W_RETREAT:g})"
        ),
    )
    parser.add_argument(
        "--retreat-reference-frame",
        choices=RETREAT_REFERENCE_FRAMES,
        default=None,
        help=(
            "Hard-support retreat coordinate frame; default preserves "
            "contact-relative-to-physical-CoM semantics"
        ),
    )
    parser.add_argument("--qref", type=Path, required=True, help="Full MuJoCo qRef .npy/.npz")
    parser.add_argument("--qpos0", type=Path, required=True, help="Full MuJoCo qpos0 .npy/.npz")
    parser.add_argument("--qvel0", type=Path, default=None,
                        help="MuJoCo nv velocity (.npy/.npz); root linear entries ignored (fill zero), angular/joint velocities retained")
    parser.add_argument("--contact-body", required=True, help="MuJoCo contact body name")
    parser.add_argument(
        "--contact-point-local",
        nargs=3,
        type=float,
        required=True,
        metavar=("X", "Y", "Z"),
        help="Contact point in the contact body local frame",
    )
    parser.add_argument(
        "--retreat-normal-world",
        nargs=3,
        type=float,
        required=True,
        metavar=("NX", "NY", "NZ"),
        help="World-frame retreat direction",
    )
    gravity_group = parser.add_mutually_exclusive_group()
    gravity_group.add_argument(
        "--projected-gravity",
        nargs=3,
        type=float,
        default=None,
        metavar=("GX", "GY", "GZ"),
        help=(
            "Projected-gravity/down vector interpreted directly in solver "
            "coordinates and normalized; no rotation is applied"
        ),
    )
    gravity_group.add_argument(
        "--down-direction-world",
        nargs=3,
        type=float,
        default=None,
        metavar=("DX", "DY", "DZ"),
        help="Compatibility alias for --projected-gravity",
    )
    parser.add_argument("--output", type=Path, default=None, help="Optional result .npz path")
    parser.add_argument("--quiet", action="store_true", help="Save output without JSON stdout; requires --output")
    args = parser.parse_args()
    if args.quiet and args.output is None:
        parser.error("--quiet requires --output")
    return args


def main() -> None:
    args = parse_args()
    api = ReflexAPI(
        profile=args.profile,
        w_retreat=args.w_retreat,
        retreat_reference_frame=args.retreat_reference_frame,
    )
    result = api.call_reflex(
        qRef=_load_array(args.qref, "qRef"),
        qpos0=_load_array(args.qpos0, "qpos0"),
        qvel0=None if args.qvel0 is None else _load_array(args.qvel0, "qvel0"),
        contact_body=args.contact_body,
        contact_point_local=np.asarray(args.contact_point_local, dtype=np.float64),
        retreat_normal_world=np.asarray(args.retreat_normal_world, dtype=np.float64),
        projected_gravity=(
            None
            if args.projected_gravity is None
            else np.asarray(args.projected_gravity, dtype=np.float64)
        ),
        down_direction_world=(
            None
            if args.down_direction_world is None
            else np.asarray(args.down_direction_world, dtype=np.float64)
        ),
    )
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        np.savez(args.output, **asdict(result))
    if not args.quiet:
        print(json.dumps(_json_payload(result), indent=2))


if __name__ == "__main__":
    main()
