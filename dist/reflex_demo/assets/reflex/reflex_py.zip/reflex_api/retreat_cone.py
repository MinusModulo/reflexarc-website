"""Small PSD local model of world-displacement distance to a retreat cone."""
from __future__ import annotations

import numpy as np


def retreat_cone_model(displacement: np.ndarray, normal: np.ndarray, ratio: float):
    """Return cost, gradient and half Hessian of squared distance to K.

    K = {d: r=n.d >= 0, ||d-r*n|| <= ratio*r}, with unit n and ratio>0.
    The QP uses c + g.dp + dp.T R dp, where dp=J_contact*dq. The residual
    displacement is always measured from event qpos0, never the last iterate
    or CoM. This exact displacement-space derivative is composed with first-
    order FK; it omits second derivatives of FK to keep the QP PSD.

    The three cases are cone interior, polar cone, and the projection onto
    the cone surface, not motion/body special cases. At the origin/boundary,
    select the interior zero curvature; finite steps can leave the cone and
    a later SQP round then sees a nonzero cost. Three rounds do not guarantee
    terminal feasibility or convergence.
    """
    r = float(normal @ displacement)
    tangent = displacement - r * normal
    t = float(np.linalg.norm(tangent))
    if t <= ratio * r:
        return 0.0, np.zeros(3), np.zeros((3, 3))
    if r <= -ratio * t:
        return float(displacement @ displacement), 2.0 * displacement, np.eye(3)
    # Here t>0 by the two preceding cases, including on the negative axis.
    u = tangent / t
    excess = t - ratio * r
    scale = 1.0 / (1.0 + ratio * ratio)
    direction = u - ratio * normal
    tangent_curvature = np.eye(3) - np.outer(normal, normal) - np.outer(u, u)
    half_hessian = scale * (np.outer(direction, direction) + (excess / t) * tangent_curvature)
    return scale * excess**2, 2.0 * scale * excess * direction, half_hessian
