from __future__ import annotations

from pathlib import Path

import mujoco
import numpy as np


ASSET_PATH = Path(__file__).resolve().parent / "assets/g1_reflex.xml"
STANCE_HEIGHT_M = 0.05
STANCE_BODY_EXACT_NAMES = frozenset(
    {
        "pelvis",
        "torso_link",
        "left_wrist_yaw_link",
        "right_wrist_yaw_link",
    }
)
STANCE_BODY_SUFFIXES = (
    "_ankle_roll_link",
    "_elbow_link",
)


def load_model() -> mujoco.MjModel:
    return mujoco.MjModel.from_xml_path(str(ASSET_PATH))


def is_allowed_stance_body(model: mujoco.MjModel, body_id: int) -> bool:
    body_name = mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_BODY, body_id)
    return body_name is not None and (
        body_name in STANCE_BODY_EXACT_NAMES
        or body_name.endswith(STANCE_BODY_SUFFIXES)
    )


def stance_body_ids(
    model: mujoco.MjModel,
    data: mujoco.MjData,
    qref: np.ndarray,
) -> list[int]:
    data.qpos[:] = qref
    data.qvel[:] = 0.0
    mujoco.mj_forward(model, data)
    result: list[int] = []
    for body_id in range(1, model.nbody):
        if not is_allowed_stance_body(model, body_id):
            continue
        geom_start = int(model.body_geomadr[body_id])
        geom_end = geom_start + int(model.body_geomnum[body_id])
        for geom_id in range(geom_start, geom_end):
            rotation_z = data.geom_xmat[geom_id].reshape(3, 3)[2]
            lowest_z = float(
                data.geom_xpos[geom_id, 2]
                + rotation_z @ model.geom_aabb[geom_id, :3]
                - np.abs(rotation_z) @ model.geom_aabb[geom_id, 3:]
            )
            if lowest_z < STANCE_HEIGHT_M:
                result.append(body_id)
                break
    return result
