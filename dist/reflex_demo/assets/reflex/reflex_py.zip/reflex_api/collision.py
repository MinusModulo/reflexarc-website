from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import mujoco
import numpy as np


OPTIMIZATION_PAIRS: tuple[tuple[int, int], ...] = (
    (0, 6), (0, 7), (0, 13), (0, 14),
    (1, 6), (1, 7), (1, 8), (1, 9), (1, 10), (1, 11), (1, 13), (1, 14),
    (2, 7), (2, 8), (2, 9), (2, 10), (2, 11), (2, 14),
    (3, 7), (3, 8), (3, 9), (3, 10), (3, 11), (3, 14),
    (4, 7), (4, 8), (4, 9), (4, 10), (4, 11), (4, 14),
    (5, 7), (5, 14),
    (6, 8), (6, 13), (6, 14), (6, 15),
    (7, 8), (7, 9), (7, 10), (7, 11), (7, 12), (7, 13), (7, 14), (7, 15),
    (8, 13), (8, 14),
    (9, 14), (10, 14), (11, 14), (12, 14), (13, 15), (14, 15),
)


# Human-reviewed symmetric oriented box for the canonical hip-roll and
# hip-yaw visual meshes, expressed in the hip-roll frame.
MERGED_HIP_COLLISION_LOCAL_POS = (0.006, 0.0, -0.15193300656735897)
MERGED_HIP_COLLISION_LOCAL_ROTATION = (
    (0.9727758782093966, 0.0, 0.23174790349415733),
    (0.0, 1.0, 0.0),
    (-0.23174790349415733, 0.0, 0.9727758782093966),
)
MERGED_HIP_COLLISION_HALF_SIZE = (
    0.0605,
    0.04911654815077782,
    0.1984177786833048,
)


@dataclass(frozen=True)
class BodyPrimitive:
    body_id: int
    body_name: str
    kind: str
    local_a: np.ndarray | None = None
    local_b: np.ndarray | None = None
    radius: float = 0.0
    local_pos: np.ndarray | None = None
    local_rot: np.ndarray | None = None
    half_size: np.ndarray | None = None


@dataclass(frozen=True)
class PrimitiveDistance:
    distance: float
    body_a: int
    body_b: int
    point_a: np.ndarray
    point_b: np.ndarray
    pair_index: tuple[int, int]


class CollisionModel:
    def __init__(self, model: mujoco.MjModel, model_path: Path) -> None:
        self.primitives = build_g1_body_primitives(model)
        if max(max(pair) for pair in OPTIMIZATION_PAIRS) >= len(self.primitives):
            raise RuntimeError("Frozen collision-pair indices do not match the primitive list")

        spec = mujoco.MjSpec.from_file(str(model_path))
        for index, primitive in enumerate(self.primitives):
            body = spec.worldbody.find_child(primitive.body_name)
            if body is None:
                raise KeyError(primitive.body_name)
            geom_name = f"_reflex_collision_{index}"
            if primitive.kind == "box":
                assert primitive.local_pos is not None and primitive.half_size is not None
                orientation_kwargs: dict[str, list[float]] = {}
                if primitive.local_rot is not None:
                    quat = np.empty(4, dtype=np.float64)
                    mujoco.mju_mat2Quat(quat, primitive.local_rot.reshape(-1))
                    orientation_kwargs["quat"] = quat.tolist()
                body.add_geom(
                    name=geom_name,
                    type=mujoco.mjtGeom.mjGEOM_BOX,
                    pos=primitive.local_pos.tolist(),
                    size=primitive.half_size.tolist(),
                    contype=0,
                    conaffinity=0,
                    group=5,
                    density=0,
                    rgba=[0.0, 0.0, 0.0, 0.0],
                    **orientation_kwargs,
                )
            else:
                assert primitive.local_a is not None and primitive.local_b is not None
                body.add_geom(
                    name=geom_name,
                    type=mujoco.mjtGeom.mjGEOM_CAPSULE,
                    fromto=[*primitive.local_a.tolist(), *primitive.local_b.tolist()],
                    size=[primitive.radius],
                    contype=0,
                    conaffinity=0,
                    group=5,
                    density=0,
                    rgba=[0.0, 0.0, 0.0, 0.0],
                )

        self.model = spec.compile()
        self.data = mujoco.MjData(self.model)
        self.geom_ids = [
            mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_GEOM, f"_reflex_collision_{index}")
            for index in range(len(self.primitives))
        ]
        if any(geom_id < 0 for geom_id in self.geom_ids):
            raise RuntimeError("Failed to compile reflex collision geoms")
        self._fromto = np.zeros(6, dtype=np.float64)

    def pair_distances(self, qpos: np.ndarray) -> list[PrimitiveDistance]:
        self.data.qpos[:] = qpos
        self.data.qvel[:] = 0.0
        mujoco.mj_forward(self.model, self.data)

        distances: list[PrimitiveDistance] = []
        for pair in OPTIMIZATION_PAIRS:
            ia, ib = pair
            distance = float(
                mujoco.mj_geomDistance(
                    self.model,
                    self.data,
                    self.geom_ids[ia],
                    self.geom_ids[ib],
                    10.0,
                    self._fromto,
                )
            )
            distances.append(
                PrimitiveDistance(
                    distance=distance,
                    body_a=self.primitives[ia].body_id,
                    body_b=self.primitives[ib].body_id,
                    point_a=self._fromto[:3].copy(),
                    point_b=self._fromto[3:].copy(),
                    pair_index=pair,
                )
            )
        return distances


def build_g1_body_primitives(model: mujoco.MjModel) -> list[BodyPrimitive]:
    primitives: list[BodyPrimitive] = []

    def body_id(name: str) -> int:
        value = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, name)
        if value < 0:
            raise KeyError(name)
        return int(value)

    def add_box(
        name: str,
        pos: tuple[float, float, float],
        half_size: tuple[float, float, float],
        local_rot: tuple[tuple[float, float, float], ...] | None = None,
    ) -> None:
        primitives.append(
            BodyPrimitive(
                body_id=body_id(name),
                body_name=name,
                kind="box",
                local_pos=np.asarray(pos, dtype=np.float64),
                local_rot=(
                    None if local_rot is None else np.asarray(local_rot, dtype=np.float64)
                ),
                half_size=np.asarray(half_size, dtype=np.float64),
            )
        )

    def add_capsule_segment(
        name: str,
        end: np.ndarray | tuple[float, float, float],
        radius: float,
        start: tuple[float, float, float] = (0.0, 0.0, 0.0),
        end_trim: float | None = None,
    ) -> None:
        local_a = np.asarray(start, dtype=np.float64)
        local_b = np.asarray(end, dtype=np.float64).copy()
        axis = local_b - local_a
        length = float(np.linalg.norm(axis))
        if length > 1.0e-9:
            trim = radius if end_trim is None else end_trim
            trim = min(trim, 0.35 * length)
            direction = axis / length
            local_a = local_a + trim * direction
            local_b = local_b - trim * direction
        primitives.append(
            BodyPrimitive(
                body_id=body_id(name),
                body_name=name,
                kind="capsule",
                local_a=local_a,
                local_b=local_b,
                radius=radius,
            )
        )

    def add_capsule(name: str, child_name: str, radius: float) -> None:
        add_capsule_segment(name, model.body_pos[body_id(child_name)], radius)

    add_box("pelvis", (0.0, 0.0, -0.085), (0.080, 0.075, 0.060))
    for side in ("left", "right"):
        sign = 1.0 if side == "left" else -1.0
        add_box(
            f"{side}_hip_roll_link",
            MERGED_HIP_COLLISION_LOCAL_POS,
            MERGED_HIP_COLLISION_HALF_SIZE,
            MERGED_HIP_COLLISION_LOCAL_ROTATION,
        )
        add_capsule(f"{side}_knee_link", f"{side}_ankle_pitch_link", 0.031)
        add_capsule(f"{side}_ankle_pitch_link", f"{side}_ankle_roll_link", 0.018)
        add_box(f"{side}_ankle_roll_link", (0.050, 0.0, -0.025), (0.090, 0.037, 0.018))
        add_capsule_segment(
            f"{side}_shoulder_roll_link",
            (0.015783, 0.00624 * sign, -0.183718),
            0.032,
            end_trim=0.0,
        )
        add_capsule_segment(f"{side}_elbow_link", (0.138, 0.00188791 * sign, -0.010), 0.025)
        # Slightly aggressive boxing-glove proxy: the full physical mesh is
        # 280 x 150 x 140 mm, while this box covers the load-bearing bulk and
        # lets the rounded padding protrude by 5--10 mm.
        add_box(f"{side}_wrist_yaw_link", (0.115, 0.0, 0.0), (0.130, 0.0675, 0.065))
    add_box("torso_link", (0.004, 0.0, 0.233), (0.090, 0.109, 0.245))
    return primitives
