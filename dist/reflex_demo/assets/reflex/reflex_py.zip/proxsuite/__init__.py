"""Browser stand-in for proxsuite (see proxqp/__init__.py)."""
