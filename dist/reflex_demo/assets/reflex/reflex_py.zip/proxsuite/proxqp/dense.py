"""``proxqp.dense`` subset: the one-shot ``solve`` used by ReflexAPI."""


def solve(H, g, A, b, C, l, u, *, eps_abs=1e-8, eps_rel=0.0, max_iter=None, **_):
    from . import _solve
    return _solve(H, g, A, b, C, l, u, eps_abs=eps_abs, eps_rel=eps_rel, max_iter=max_iter)


class QP:
    """The reusable workspace only serves the default-off restoration path."""

    def __init__(self, *args, **kwargs):
        raise NotImplementedError("proxqp.dense.QP is not available in the browser build")
