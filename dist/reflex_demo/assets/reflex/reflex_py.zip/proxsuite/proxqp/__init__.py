"""NumPy stand-in for the subset of ``proxsuite.proxqp`` that ReflexAPI uses.

Only ``proxqp.dense.solve`` is on the hard-support path.  It is solved here by
a dense primal-dual interior-point method (Mehrotra predictor-corrector).  The
ReflexAPI QPs are strictly convex (positive-definite Hessian), so the optimum
is unique and this solver returns the same point as ProxQP to solver
tolerance; tools/reflex_web/test_qp.py checks that on recorded problems.

Sign conventions follow ProxQP:  H x + g + A^T y + C^T z = 0, with z < 0 on an
active lower bound and z > 0 on an active upper bound.
"""
from __future__ import annotations

import enum
from types import SimpleNamespace

import numpy as np

from . import dense  # noqa: F401  (re-exported subpackage)


class InitialGuess(enum.Enum):
    NO_INITIAL_GUESS = 0
    WARM_START_WITH_PREVIOUS_RESULT = 1


class QPSolverOutput(enum.Enum):
    PROXQP_SOLVED = 0
    PROXQP_MAX_ITER_REACHED = 1


def _solve(H, g, A, b, C, l, u, *, eps_abs=1e-8, eps_rel=0.0, max_iter=None):
    H = np.asarray(H, dtype=np.float64)
    g = np.asarray(g, dtype=np.float64)
    n = g.shape[0]
    A = np.zeros((0, n)) if A is None else np.asarray(A, dtype=np.float64).reshape(-1, n)
    b = np.zeros(0) if b is None else np.asarray(b, dtype=np.float64).reshape(-1)
    C = np.zeros((0, n)) if C is None else np.asarray(C, dtype=np.float64).reshape(-1, n)
    l = np.full(C.shape[0], -np.inf) if l is None else np.asarray(l, dtype=np.float64)
    u = np.full(C.shape[0], np.inf) if u is None else np.asarray(u, dtype=np.float64)
    m_eq, m_in = A.shape[0], C.shape[0]

    lo = np.flatnonzero(np.isfinite(l))
    up = np.flatnonzero(np.isfinite(u))
    G = np.vstack((C[lo], -C[up]))
    h = np.concatenate((l[lo], -u[up]))
    m = G.shape[0]

    # Start from the equality-constrained minimiser, slacks pushed interior.
    K0 = np.block([[H + 1e-9 * np.eye(n), A.T], [A, -1e-12 * np.eye(m_eq)]]) if m_eq else H + 1e-9 * np.eye(n)
    sol = np.linalg.solve(K0, np.concatenate((-g, b)))
    x = sol[:n]
    y = sol[n:]
    s = np.maximum(G @ x - h, 1.0)
    lam = np.ones(m)

    tol = max(float(eps_abs), 1e-10) * 1e-2
    scale = 1.0 + max(np.abs(g).max(initial=0), np.abs(h).max(initial=0), np.abs(b).max(initial=0))
    status = QPSolverOutput.PROXQP_MAX_ITER_REACHED
    it = 0
    for it in range(1, 101):
        rd = H @ x + g + A.T @ y - G.T @ lam
        rp = A @ x - b
        rs = G @ x - s - h
        mu = float(s @ lam) / m if m else 0.0
        if max(np.abs(rd).max(initial=0), np.abs(rp).max(initial=0), np.abs(rs).max(initial=0)) <= tol * scale \
                and mu <= tol * 1e-2:
            status = QPSolverOutput.PROXQP_SOLVED
            break
        W = lam / s
        K = np.zeros((n + m_eq, n + m_eq))
        K[:n, :n] = H + G.T @ (W[:, None] * G)
        K[:n, n:] = A.T
        K[n:, :n] = A
        if m_eq:
            K[n:, n:] -= 1e-14 * np.eye(m_eq)

        def direction(rc):
            rhs = np.concatenate((-rd + G.T @ ((-rc - lam * rs) / s), -rp))
            d = np.linalg.solve(K, rhs)
            dx, dy = d[:n], d[n:]
            ds = G @ dx + rs
            dl = (-rc - lam * ds) / s
            return dx, dy, ds, dl

        def step(v, dv):
            neg = dv < 0
            return min(1.0, float(np.min(-v[neg] / dv[neg]))) if np.any(neg) else 1.0

        dx, dy, ds, dl = direction(s * lam)
        a_aff = min(step(s, ds), step(lam, dl))
        mu_aff = float((s + a_aff * ds) @ (lam + a_aff * dl)) / m if m else 0.0
        sigma = (mu_aff / mu) ** 3 if mu > 0 else 0.0
        dx, dy, ds, dl = direction(s * lam + ds * dl - sigma * mu)
        alpha = 0.995 * min(step(s, ds), step(lam, dl))
        x += alpha * dx
        y += alpha * dy
        s += alpha * ds
        lam += alpha * dl

    z = np.zeros(m_in)
    z[lo] -= lam[: lo.size]
    z[up] += lam[lo.size:]
    info = SimpleNamespace(status=status, iter=it)
    return SimpleNamespace(x=x, y=y, z=z, info=info)
