"""Pyodide stand-in for the ``mujoco`` Python bindings, backed by MuJoCo WASM.

Covers exactly the API surface ReflexAPI uses.  The host registers the
``@mujoco/mujoco`` module object as the JS module ``_mujoco_js``.

Semantics kept from the real bindings:
* ``data.<field>`` are NumPy arrays that the code may hold on to; inputs
  (qpos, qvel) are pushed before every call and outputs are refreshed in place
  after every call that recomputes them.
* Out-parameters are written in place into the NumPy arrays passed in.
* ``model.opt.gravity[:] = ...`` takes effect on the next call.
WASM out-parameters must live on the WASM heap, so they go through cached
``DoubleBuffer`` scratch memory and are copied back.
"""
from __future__ import annotations

import enum
import xml.etree.ElementTree as ET

import numpy as np
from pyodide.ffi import to_js

from _mujoco_js import mj as _mj


class mjtObj(enum.IntEnum):
    mjOBJ_UNKNOWN = 0
    mjOBJ_BODY = 1
    mjOBJ_XBODY = 2
    mjOBJ_JOINT = 3
    mjOBJ_DOF = 4
    mjOBJ_GEOM = 5
    mjOBJ_SITE = 6


class mjtJoint(enum.IntEnum):
    mjJNT_FREE = 0
    mjJNT_BALL = 1
    mjJNT_SLIDE = 2
    mjJNT_HINGE = 3


class mjtGeom(enum.IntEnum):
    mjGEOM_PLANE = 0
    mjGEOM_HFIELD = 1
    mjGEOM_SPHERE = 2
    mjGEOM_CAPSULE = 3
    mjGEOM_ELLIPSOID = 4
    mjGEOM_CYLINDER = 5
    mjGEOM_BOX = 6
    mjGEOM_MESH = 7


_GEOM_TYPE_NAMES = {int(v): k[len("mjGEOM_"):].lower() for k, v in mjtGeom.__members__.items()}

# ---------------------------------------------------------------- scratch
_scratch: dict[tuple[int, int], object] = {}


def _buffer(size: int, slot: int):
    """One heap buffer per (size, argument slot): two outputs of one call never alias."""
    buf = _scratch.get((size, slot))
    if buf is None:
        buf = _mj.DoubleBuffer.new(size)
        _scratch[(size, slot)] = buf
    return buf


def _arr(values) -> object:
    """Plain JS Array for ``number[]`` parameters."""
    return to_js(np.asarray(values, dtype=np.float64).ravel().tolist())


class _Out:
    """Heap scratch for one out-parameter, copied back into ``target``."""

    def __init__(self, target, size: int, slot: int = 0):
        self.target = target
        self.size = size
        self.buf = None if target is None else _buffer(size, slot)

    def view(self, preload: bool = False):
        if self.buf is None:
            return None
        view = self.buf.GetView()
        if preload:
            view.assign(np.ascontiguousarray(self.target, dtype=np.float64).ravel())
        return view

    def commit(self) -> None:
        if self.buf is None:
            return
        tmp = np.empty(self.size, dtype=np.float64)
        self.buf.GetView().assign_to(tmp)
        self.target[...] = tmp.reshape(self.target.shape)


# ------------------------------------------------------------------ model
_MODEL_PREFIX = (("body_", "nbody"), ("jnt_", "njnt"), ("geom_", "ngeom"), ("dof_", "nv"),
                 ("site_", "nsite"), ("actuator_", "nu"), ("cam_", "ncam"), ("light_", "nlight"),
                 ("mesh_", "nmesh"), ("mat_", "nmat"), ("tex_", "ntex"), ("key_", "nkey"))


class _Option:
    def __init__(self, handle):
        self._handle = handle
        self.gravity = np.array(handle.gravity, dtype=np.float64)
        self._pushed = self.gravity.copy()
        self.timestep = float(handle.timestep)

    def _sync(self) -> None:
        if not np.array_equal(self.gravity, self._pushed):
            self._handle.gravity.assign(np.ascontiguousarray(self.gravity))
            self._pushed = self.gravity.copy()


class MjModel:
    def __init__(self, handle):
        object.__setattr__(self, "_h", handle)
        object.__setattr__(self, "_cache", {})
        object.__setattr__(self, "opt", _Option(handle.opt))

    @staticmethod
    def from_xml_string(xml: str, assets=None) -> "MjModel":
        return MjModel(_mj.MjModel.from_xml_string(xml))

    @staticmethod
    def from_xml_path(path: str) -> "MjModel":
        with open(path, encoding="utf-8") as stream:
            return MjModel.from_xml_string(stream.read())

    def __getattr__(self, name):
        cache = self._cache
        if name in cache:
            return cache[name]
        value = getattr(self._h, name)
        if isinstance(value, (int, float, bool, str)) or value is None:
            cache[name] = value
            return value
        array = np.asarray(value.to_py()).copy()
        for prefix, count in _MODEL_PREFIX:
            if name.startswith(prefix):
                n = int(getattr(self._h, count))
                if n and array.size % n == 0 and array.size // n > 1:
                    array = array.reshape(n, array.size // n)
                break
        if name == "qpos0":
            array = array.reshape(-1)
        cache[name] = array
        return array

    def __setattr__(self, name, value):
        raise AttributeError(f"MjModel.{name} is read-only in the browser shim")


# ------------------------------------------------------------------- data
_DATA_INPUTS = ("qpos", "qvel")
_DATA_SHAPES = {
    "xpos": ("nbody", 3), "xquat": ("nbody", 4), "xmat": ("nbody", 9), "xipos": ("nbody", 3),
    "ximat": ("nbody", 9), "subtree_com": ("nbody", 3), "xfrc_applied": ("nbody", 6),
    "geom_xpos": ("ngeom", 3), "geom_xmat": ("ngeom", 9),
    "site_xpos": ("nsite", 3), "site_xmat": ("nsite", 9),
    "cinert": ("nbody", 10), "cdof": ("nv", 6),
}


class MjData:
    def __init__(self, model: MjModel):
        object.__setattr__(self, "_m", model)
        object.__setattr__(self, "_h", _mj.MjData.new(model._h))
        object.__setattr__(self, "_fields", {})
        for name in _DATA_INPUTS:
            self._fields[name] = np.array(getattr(self._h, name).to_py(), dtype=np.float64)

    def _shape(self, name: str, size: int):
        spec = _DATA_SHAPES.get(name)
        if spec is None:
            return (size,)
        n = int(getattr(self._m._h, spec[0]))
        return (n, spec[1])

    def __getattr__(self, name):
        fields = self._fields
        if name not in fields:
            raw = np.asarray(getattr(self._h, name).to_py(), dtype=np.float64)
            fields[name] = raw.reshape(self._shape(name, raw.size)).copy()
        return fields[name]

    def __setattr__(self, name, value):
        target = self.__getattr__(name)
        target[...] = value

    # Called around every binding call that takes this data.
    def _push(self) -> None:
        self._m.opt._sync()
        for name in _DATA_INPUTS:
            getattr(self._h, name).assign(np.ascontiguousarray(self._fields[name]))

    def _pull(self) -> None:
        for name, array in self._fields.items():
            if name in _DATA_INPUTS:
                continue
            flat = np.empty(array.size, dtype=np.float64)
            getattr(self._h, name).assign_to(flat)
            array[...] = flat.reshape(array.shape)


def _with_data(m: MjModel, d: MjData, recompute: bool, call):
    d._push()
    result = call()
    if recompute:
        d._pull()
    return result


# -------------------------------------------------------------- pipeline
def mj_forward(m, d):
    _with_data(m, d, True, lambda: _mj.mj_forward(m._h, d._h))


def mj_fwdPosition(m, d):
    _with_data(m, d, True, lambda: _mj.mj_fwdPosition(m._h, d._h))


def mj_kinematics(m, d):
    _with_data(m, d, True, lambda: _mj.mj_kinematics(m._h, d._h))


def mj_comPos(m, d):
    _with_data(m, d, True, lambda: _mj.mj_comPos(m._h, d._h))


def mj_rne(m, d, flg_acc, result):
    out = _Out(result, m.nv)
    _with_data(m, d, True, lambda: _mj.mj_rne(m._h, d._h, int(flg_acc), out.view()))
    out.commit()


# ------------------------------------------------------------- jacobians
def mj_jac(m, d, jacp, jacr, point, body):
    p, r = _Out(jacp, 3 * m.nv, 0), _Out(jacr, 3 * m.nv, 1)
    _with_data(m, d, False, lambda: _mj.mj_jac(m._h, d._h, p.view(), r.view(), _arr(point), int(body)))
    p.commit()
    r.commit()


def mj_jacBodyCom(m, d, jacp, jacr, body):
    p, r = _Out(jacp, 3 * m.nv, 0), _Out(jacr, 3 * m.nv, 1)
    _with_data(m, d, False, lambda: _mj.mj_jacBodyCom(m._h, d._h, p.view(), r.view(), int(body)))
    p.commit()
    r.commit()


def mj_jacSubtreeCom(m, d, jacp, body):
    p = _Out(jacp, 3 * m.nv)
    _with_data(m, d, False, lambda: _mj.mj_jacSubtreeCom(m._h, d._h, p.view(), int(body)))
    p.commit()


def mj_angmomMat(m, d, mat, body):
    p = _Out(mat, 3 * m.nv)
    _with_data(m, d, False, lambda: _mj.mj_angmomMat(m._h, d._h, p.view(), int(body)))
    p.commit()


def mj_fullM(m, d, dst):
    p = _Out(dst, m.nv * m.nv)
    _with_data(m, d, False, lambda: _mj.mj_fullM(m._h, d._h, p.view()))
    p.commit()


def mj_geomDistance(m, d, geom1, geom2, distmax, fromto):
    p = _Out(fromto, 6)
    value = _with_data(m, d, False, lambda: _mj.mj_geomDistance(
        m._h, d._h, int(geom1), int(geom2), float(distmax), p.view()))
    p.commit()
    return float(value)


# ------------------------------------------------------------ qpos maths
def mj_integratePos(m, qpos, qvel, dt):
    p = _Out(qpos, m.nq)
    _mj.mj_integratePos(m._h, p.view(preload=True), _arr(qvel), float(dt))
    p.commit()


def mj_differentiatePos(m, qvel, dt, qpos1, qpos2):
    p = _Out(qvel, m.nv)
    _mj.mj_differentiatePos(m._h, p.view(), float(dt), _arr(qpos1), _arr(qpos2))
    p.commit()


def mj_normalizeQuat(m, qpos):
    p = _Out(qpos, m.nq)
    _mj.mj_normalizeQuat(m._h, p.view(preload=True))
    p.commit()


def mju_mat2Quat(quat, mat):
    p = _Out(quat, 4)
    _mj.mju_mat2Quat(p.view(), _arr(mat))
    p.commit()


def mju_quat2Mat(res, quat):
    p = _Out(res, 9)
    _mj.mju_quat2Mat(p.view(), _arr(quat))
    p.commit()


def mju_quat2Vel(res, quat, dt):
    p = _Out(res, 3)
    _mj.mju_quat2Vel(p.view(), _arr(quat), float(dt))
    p.commit()


def mju_rayGeom(pos, mat, size, pnt, vec, geomtype, normal=None):
    p = _Out(normal, 3)
    value = _mj.mju_rayGeom(_arr(pos), _arr(mat), _arr(size), _arr(pnt), _arr(vec), int(geomtype), p.view())
    p.commit()
    return float(value)


# ------------------------------------------------------------------ names
def mj_name2id(m, objtype, name):
    return int(_mj.mj_name2id(m._h, int(objtype), str(name)))


def mj_id2name(m, objtype, objid):
    value = _mj.mj_id2name(m._h, int(objtype), int(objid))
    return None if value in (None, "") else str(value)


# ----------------------------------------------------------------- MjSpec
def _fmt(value) -> str:
    return " ".join(repr(float(v)) for v in np.asarray(value, dtype=np.float64).ravel())


class _SpecBody:
    def __init__(self, element: ET.Element):
        self._element = element

    def find_child(self, name: str):
        for body in self._element.iter("body"):
            if body is not self._element and body.get("name") == name:
                return _SpecBody(body)
        return None

    def add_geom(self, **attributes):
        geom = ET.SubElement(self._element, "geom")
        for key, value in attributes.items():
            if key == "type":
                geom.set("type", _GEOM_TYPE_NAMES[int(value)])
            elif isinstance(value, str):
                geom.set(key, value)
            elif np.ndim(value) == 0:
                geom.set(key, str(int(value)) if isinstance(value, (int, np.integer)) else repr(float(value)))
            else:
                geom.set(key, _fmt(value))
        return geom


class MjSpec:
    """Only ``from_file`` -> ``worldbody.find_child`` -> ``add_geom`` -> ``compile``."""

    def __init__(self, root: ET.Element):
        self._root = root
        self.worldbody = _SpecBody(root.find("worldbody"))

    @staticmethod
    def from_file(path: str) -> "MjSpec":
        return MjSpec(ET.parse(path).getroot())

    def compile(self) -> MjModel:
        return MjModel.from_xml_string(ET.tostring(self._root, encoding="unicode"))
